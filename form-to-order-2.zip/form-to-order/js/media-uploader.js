jQuery(document).ready(function ($) {
    // Ensure media uploader is available
    if (typeof wp !== 'undefined' && wp.media) {
        var file_frame;

        $('.upload_pdf_button').on('click', function (e) {
            e.preventDefault();

            var button = $(this);
            var targetField = $(button.data('target')); // Field where PDF URL will be set
            var pdfContainer = $(button.data('pdf-container')); // The container where the link will be shown

            // If the media frame already exists, reopen it.
            if (file_frame) {
                file_frame.open();
                return;
            }

            // Create the media frame.
            file_frame = wp.media.frames.file_frame = wp.media({
                title: 'Select or Upload PDF',
                button: {
                    text: 'Use this file',
                },
                multiple: false // Set to false to allow only one file to be selected
            });

            // When a file is selected, run a callback.
            file_frame.on('select', function () {
                var attachment = file_frame.state().get('selection').first().toJSON();
                targetField.val(attachment.url); // Set the URL of the selected file

                // Create a link to view the uploaded PDF and append it to the container
                var pdfLink = '<a href="' + attachment.url + '" target="_blank" style="display:block;margin-top:10px;">View PDF</a>';
                pdfContainer.html(pdfLink); // Dynamically add the PDF link
				//$('#order_status').prop('disabled', false);
				//$('div#order_data .error.notice').hide();
				//$('#order_status option[value="wc-abgeschlossen"]').prop('disabled', false);
				//$('.select2-results .select2-results__option').prop('aria-disabled', false);
				
            });

            // Open the modal
            file_frame.open();
        });
    } else {
        console.error('Media uploader is not available.');
    }
	
	$('.remove_pdf_button').on('click', function (e) {
		e.preventDefault();

		var button = $(this);
		var targetField = $(button.data('target')); 
		var pdfContainer = $(button.data('pdf-container'));
		var pdfContainerLink = $(button.data('target-link'));

		// Clear the hidden field and the PDF link
		targetField.val('');
		pdfContainer.html(''); // Remove the link
		button.remove();
		pdfContainerLink.remove();
	});

});
