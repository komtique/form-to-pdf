<?php
/**
 * @var int $order_id
 * @var WC_Order $order
 */
$discount = 0;
foreach( $order->get_items('fee') as $fee ) {
    if ($fee->get_total() + $fee->get_total_tax() < 0) {
        $discount += abs($fee->get_total()) + abs($fee->get_total_tax());
    }
}
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Rechnung R24-166</title>
	<style>
        body {
            font-family: Arial, sans-serif;
        }

        .logo img {
            max-width: 55%;
            margin-top:-20px;
            margin-bottom:10px;
        }
        .columns>div {
            width: 50%;
            float:left;
        }

        .column-right {
            text-align: right;
            font-size: 14px;
            line-height: 22px;
        }

        .adress {
            margin-bottom: 20px;
        }

        body {
            font-size: 15px;
        }
        h3 {
            clear: both;
            font-size:30px;
        }

        .adress {
            text-decoration: underline;
            font-size: 12px;
        }

        p.bauvorhaben {
            font-weight: bold;
        }

        p.bauvorhaben strong {
            text-decoration: underline;
            font-weight: 400;
        }

        p.i {
            font-style: italic;
            font-size:14px;
        }

        table {
            border-collapse: collapse;
            width: 70%;
            font-size:14px;
        }

        th {
            text-align: left;
        }

        tr th:first-child {
            width: 23px;
        }

        tr:last-child {
            font-weight: bold;
            font-size: 121%;
        }
        td, th {
            padding-bottom: 0;
            vertical-align: top;
            padding-left: 8px;
            padding-right: 8px;
            border: 1px solid gray;
        }
        tr:last-child td {
            padding-top: 50px;
            border-top: 1px solid gray;
            border: 1px solid white;
        }

        tr:last-child td:first-child:before {
            content: "";
            position: absolute;
            width: 100%;
            height: 2px;
            background: black;
            margin-top: -25px;
            margin-left: -10px;
        }

        p.betrieb strong {
            font-weight: 400;
            padding-right: 10%;
            text-decoration: underline;
        }

        .border {
            border: 1px solid black;
            font-style: italic;
            padding-left: 10px;
            padding-right: 10px;
            margin-bottom:10px;
            font-size:13px;
        }

        .border a {
            font-weight: bold;
            text-decoration: none;
            color: red;
        }
        p.betrieb {
            margin-top: 30px;
        }

        .footer-columns {
            border-top: 2px solid #9191915c;
            padding-top: 20px;
        }
        .footer-col{
            padding:0;
            text-align:left;
            font-size:12px;
            width: 33%;
            font-weight:400;
        }
        .footer-col a{
            color:black;
            text-decoration:none;
        }
        tr.footer-columns {
            font-size: 14px;
            font-weight: normal;
        }

        footer table {
            width: 100%;
        }

        td.footer-col:before {
            display: none;
        }

        .footer-col {
            padding-top: 20px!important;
        }
        .image-header img {
            max-width: 100%;
        }
        .column-right a {
            text-decoration: none;
            color: black;
        }
        .page-break {
            page-break-before: always;
        }
        footer {
            position: fixed;
            bottom: 0px;
            left: 0px;
            right: 0px;
            width:100%
        }
	</style>
</head>
<body>
<footer>
	<table>
		<tbody>
		<tr class="footer-columns">
			<td class="footer-col">
				Honovia GmbH<br>
				Salierstraße 51<br>
				75177 Pforzheim<br>
				Deutschland<br>
			</td>
			<td class="footer-col">
				Bank: Sparkasse Pforzheim Calw<br>
				IBAN: DE69 6665 0085 0005 6197 18<br>
				BIC: PZHSDE66XXX<br>
				USt.-IdNr.: DE335933303<br>
			</td>
			<td class="footer-col">
				Tel.: 0721 660 501 20<br>
				E-Mail: <a href="mailto:info@foerderheld.com">info@foerderheld.com</a><br>
				Website: <a href="http://www.förderheld.com">www.förderheld.com</a>
			</td>
		</tr>
		</tbody>
	</table>
</footer>
<div class="page-content">
	<div class="logo">
		<img class="bi x0 y0 w1 h1" alt="" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAkQAAABzCAYAAAB5AB1mAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAAFiUAABYlAUlSJPAAAFKbSURBVHhe7Z0HYBTF/se/l0uFEBJ6711AiiKCKFYQfTzs6FP/wsOG9VmwVyyoKM+GPhsWFAtNRQERpSqiKE167xAgvV2u/Oc7d5Msx11yudu7HMl8YLO3O7u/nZ2dnfnuVItLAI1Go9FoNJpqTIxnrdFoNBqNRlNt0YJIo9FoNBpNtUcLIo1Go9FoNNUeLYg0Go1Go9FUe7Qg0mg0Go1GU+3Rgkij0Wg0Gk21RwsijUaj0Wg01R4tiDQajUaj0VR7tCDSaDQajUZT7dGCSKPRaDQaTbVHCyKNRqPRaDTVHovT6TxuLjOLxQJ/U5z5cwvmHKLtudH2SjlR7UWDH4i250bbKyVS9qLBD0Tbc6PtlVLWOQqfgkij0Wg0Go2mqmMURLrKTKPRaDQaTbVHCyKNRqPRaDTVHi2INBqNRqPRVHt8CiJjnZo3/tyCOYdoe260vVJOVHvR4Aei7bnR9kqJlL1o8APR9txoe6WU5aaIokbV9IbwsFjl5uUiMzND/LTA4nLBZRG/XDFISkpA3Xr13YdrNBqfsCdFIC+/RqM5sQjHu13d0wvjvUeVIHI4HDhyNAOTP/0Ub7z+qhRHNRMTpFTKL7CjX79T8cGkjxAfH+8+RaPRHEdubi7y8/M9W+aQmJiIlJQUz5ZGo6kMRH6Nw4cPe7bMgflpamqqZyt6ycvLk4uZME1LSkrybEWBIKI6tdlsIhHPwfat2zD+5QmYPm2qcHAiOSkeg085GQXFxfhu2SogLgbLly1Hjx49PGdrNBpvPvnkE0yfPt2zZQ4DBw7EXXfd5dnSaDSVQVZWFm644QbPljn06tULjz32mGcrepk6dSo+++wzn2MJBcuDDz6Ivn37erYiKIh4E1zsdjuKhcApKiqSCx/wxk0bMUMk4FOnTkNBQQFqxMWiYa0aOKtXN3Rv0Qh54pzxX85GVoENTz39FB599FGPVbfdI0eOSJsNGjSA1Wr1uGg01ZPXXnsNH330kWfLHC666CI8/fTTni2NRlMZZGRk4LzzzvNsmUO/fv3w+uuve7ail/fffx9vvfWWqYJo/PjxOOecczxbYeplxqovCpus7CxZvLdv3z7s2LED69atw/z58/Hhhx/ioYcewiWXXIL+/fvjsssuw+SPJ8NeVIj6yTVwXq8uGPGPs6UYcsY4pECqn5rCFkbYtHFjSYDwOjt37sTo0aPxz3/+U14jWJRgO5EXjUZTvfCVDpixmIUv22YsGk048FlCxEZG/iMdZYnHTax4nK3YhsKiItg8pT4H9h+QpT4bNm7Ali2bsXvXHuzfvx979+6BzVYsT6UVtmWKscQgNjYWNWKtaNMwDWf27o4mQvzEuWxw0B/iSJcrBu98txibDhzClVdciQ8mvY/CwkLs3LUL99zzHyxcsFDafOmll3DvvffK396UfU+Q/jO7fjKS1K9fH7Vr1/Zs+b9fVk+ylE65MexZh1xeo7rywo8ldFxYxx0TE4O4uDi5+DuvLHvBuEWDvWjwA+HXHj86vAnFf0OGDDmuhCgUe77ctL1SAnU7cOCAbDNmNk2aNEGNGjU8W8cT6D3t2bNHptVm06JFCyQkJFQ4/AINV2+ixd7Ro0d9lhAFa49uvkqIQrHnCzPsGUuIzLBHvEuIgqoy4wkUPtk52cjMyMTatWvx54oVcr1y5UqkHzqEYpHxOpzuo5lBUviIFawxFvHbgnixkRQXi9SUZDSrm4pOrZqhaZ0UxFvEFwDlkmcdI24gR2Tgr077EUdy8zHkoosw7J/DsHz5csz8eiYOp6fDImwxIx48eDC+++47eeOBogL3P//5DxYvXuzZe+LBasRhw4Z5to6HYo/Vk+vXr5cldmx0S8HCasZu3bqhbt26qFmzZoXCjmHOxDgnJ0cI3y2ytI7XoZ3WrVujQ4cOSE5OlglrRexqQkNXmVUfWNI+b948z5Z5TJgwAWeccUbI7y3buzBfMAuVoX3xxRdo166d/F2d0FVm4a0yC1gQyYOERwoK8pCTnY1ff/0Nn035DIuXLMHBgwdhpXgRwsRqjRVLDGKFoLGK7QSrBSlJSUhJronayZ51UiLq1aqJ1OREJMbHwcobFMcrnEI88Vrsah8jdm8Q9t/9bjEcYr8LQmWJfTExVmHbLapq1qyB3elHkJaWht27d5f5ZeMPCqJFixZ5tk482CjOlyBi5GG15TfffIMpU6bIF4qJnDFSUcBcfvnluOqqq2RJE59jebC6kl9/bMD7ww8/+Cxda9asGYYOHSqFauPGjQOyqwkdLYiqDw8//DDmzp3r2TKP//73vxgwYIBnKziYxowYMQJr1qzx7DEHpl8URG3btvXsqT5oQRQlbYjsxcVSbHz++RcYfvW/RAZ6JWZM+xq5RzOQKgRPk7op6NaqMc7t1h5X9OuBEef3x+3DzsN/rhyCGy8+G1cPPBUX9+6CMzu2QLcWDdA4rSZqxFuFB1xwiY8Qp/jFhdVjMUKjWVxOIbGcUojFxyegXkoy6tRIFEsS6iXXQKv6qejfpS1GDOqP83t2ZpkSMjMzZRGyphSK1UceeURGJL5MxBihmLiwtIgZ6JgxY2RJD8VOWfD8v//+G7fddhtmzpx5XBdv2uRCwcTr3n333di6daupEVmj0bjfRb5rZmKWPbP9pdDpiCZcBCSImOEtXbIUVwgRNOrGW2TVUnJCLFrUr4WBJ7fHiMEDcPvQ83Ht2X1xbs/26N66EVrWq4W0RCtinXbEuEQGKyIxq8BcsIo3RVxWvCzubUZuih9mwhRH7uMgjnOKlcviQIu6tXHr0HNw44UDMHroWbjn8gsw+uKBGHJqVzStUxtWmqNHBWzHonEnGmzYPm7cOPz555+evcfD41QCw6LtO+64Axs2bJDbvuCxFJ0skVLi0zuBMtrketu2bXj88cdl/bdGozEX7/evqhMuoaXRlCuI2CCOff8vvfxS/PHHciQIPdNCiJBh/XvhxiFn49yTO6F5nWTECeHCsYNYzcXF5SntsVD8UK5Q6MhqMR7DEiDxUy48zuo+VmzL/QJGeYvLIkURraXGx6F+ajLq1KyJJKGArB5bLvFyZOcWSlM1kmrINjEaEXYiXGbNmoUlS5bIBDOQRJPncAiDF198UTa+9gXtsNSHpT8Vsbt582Z88MEHAR2v0Wg0Gk2kOU4QubMr8Vf8t9ntmPfDPDkgW1ZGFmolJKBXm2a4ftAA9GzdGIlWoVaYwYn/buHDn+5/btwZphT03OU+tGQh0s1DqZv4R9Pin0X84yUcQgDxUCma5MEWOGKcsvRp9+FMeV7rNq2QmuruacVtI2V9VQTjFu32WFL21Vdf+RQg/s5Rx7KkaPXq1fK3Qp1DweTdZqE8/9EuF7ZjCqRHTHn2fBHMOcRMe9HgB6LtudH2SomUvWjwA9H23Gh7pZTlpjhOELlPEWLD6cTKFSsw+rZbUFRYiNo14jG4T3dcMqAP0pLiZSWXRRXnCHxlvIry3Y53LznH6MR94pqsRmPpkdUZA7srBlv37uPd4uQePaHaiHvfemj+O55ot8eGjKyq8kUg9hYsWCDXCrWfJU52IZSNBGKPkZFVr+wdWB6B2PMmmHOImfaiwQ9E23Oj7ZUSKXvR4Aei7bnR9kopy03hs8qMJ+7atQMjR47Evn37kZqUgMvPOBWndWyJOBSLA4QgEcdZZLf6yMJbYnUcrx/DYiRLDGrVSJQCafGixVIION39/as1P//8c0ARwB8cRNMXqsdIIGrbCP3Cc9gYW6PRaDSaaMOnIDp85LDshr5u/UbUjE/A0H69cFLzhsLFBafFKquzYuAQvyuWKZoDZ8C3CD+4ZDVarFBlF/bpiZQEqxBxO3H9//0fdu/ZJTJgz+HVFNWjLFi8e44pQhm8kqKIDb3Vb41Go9FoooXjBBHbeIwdOxazZn0nG1AP6N4B3Vo2kVNoUP7EOjlYoruL/HH1UpHAk486hRhiHzUqn1YN66B/1w6Ij7Fg7Zq1slGw3e67UXB1wTiDbzBwdnNfcHTYipYOGVFjRIViQ6PRaDQasykRROqL/Ysvv8Rbb74FlxA+bRvXw1nd2gvhIeSPk4MkOoUQEQuVkOwV5vsrnw2haVhmecz4lHhx75D/6O6+OHdyj3JW23Kr9JfnANphCRWhMGMvM3bZ79etIxrVriX3c9qCNWuObRRc3Tj11FOl6FDCI1ABoo7jSNO+aN++vYwrwZbwVMfB1DQajUYT/ZQIImaErM5gl2qnED7xVuDMk7sgXh7BTJKySKxlhsk2Ou5BExXeGa6LDYyEEKJ6US6s6nJbciOFDY/hSlpjvzK3uzqmFPdxbnfhKn5IH4iMmXZrCP+e0qUDYoVTQUEhJn/yqRB17nNIWYIgGLdotzdw4EA5crfCKGDKssfj6N6nTx+f53A/5z4zUp7/lDvP69mzp/xd3jn+8OcWDfaiwQ9E23Oj7ZUSKXvR4Aei7bnR9kopy01RIojIL7/8gtUrV0mR0a5pQ7RtWF/8dpfmiB/uv4ZM0ohxP4UOGz7Lc8V+Ork83fJlCY+QMpy4VQosDyxDoiuPd49Q7W4YTavSTZZIuY/35Qda796uBRp7ZsWfNm2anG1f4c/fJBi3aLfHecouu+wyWK1CKQqMkaEsezyuUaNG6N+/v89zWELUq1evY6bhCMR/tNW3b185hQcJ5Bxf+HOLBnvR4Aei7bnR9kqJlL1o8APR9txoe6WU5aYoydU4XQPnr7E77EiKs2Jgz46I5WCLIiOT5TaleWO5cP4xdol38keME8VOB/I5G36xHXbKHWGT1W+cw4yHuEuHxF9xDQ7C6BA/cm0OOOlOYcRri8V93PGwgTUlVO04F87v21NOHLt7zx7M/PprzxHVDwqQ66+/Hl26dJHihZGB+9TijdpXq1Yt3HrrrUhJSZHb3tDWvffeKwfAVOd4rxXc5sJrc/JYTvWh0Wg0Gk00UiKIOFM5u2pzx0ktm6BVvTQhNIQYEZmZu8QncNjgmYvIEoWosWLboRzM/mMDftu8F/sycmCzFTO3PKaEiLgLgCw4mFOAH1esxcHsAnFdllCxtIj+KMMXwh5Ll9o1qY9mwu9kxvTpckb26gobMD/11FOyVIeNrClM1OINhQ5FzujRo+VEnmXRpk0bOakkj4+NjZX2vMUQ4X5Wk/G4e+65p1rOTq3RaDSaE4MSQTRv3jzZ1TrRGoMBJ3eVU2NwCg5qFuoQVV1lhPlqsd0Bu8MphI9nJxG/ZckPF7G5+1A6/tq2A7uzMjFjye9Ysn4Hcgpt4uLsOs8qHdkqSJznhEPsXb1tN37fvBvz/liLfBZSSVssHyrxrhfifI97ghBxnVs1lRY5CGAgIyNXZZo3b45XX30VgwYNksKEJUAUR+wtxoUz3bOtUbdu3fDss8/iiiuu8JzpGyWmWKXGedK6d++OOnXqSDsUP1zYQ43XadiwoWzL9NJLL8nr+xJiGo1Go9FEA6xLkT8WLuTIxBY0b1AHTdKSRc5HiWIUQaz+YJkOy2zc/zILirBy+178vecQ9mXlCZFT5Bkpmr2/WFJkkdVmibGxqJNcE/8b9wAeGH09Nu8/jNnL/0ahwyFs8nhh1SKkkDgpq8iG1Vt2oFfPrjiQkYm/t++DE+6xj3goJRH9QNXF4Rn5j5v0Ka/Hdfsm9eQ6PT1dztBfmfgqOYkkvH79+vXlZKyvvfYa/v3vf2Pw4ME4++yzcd555+HKK6+UE6/+73//k22DysN4PxRDEydOlMM0XHfddbjgggukALrwwgtx8803ywb6zz33HLp27SqPr+yw0Gg0Go3GH7LIhb3KVq5cKX4JQdSwHueZ525uskjALT+kcOHa3QbIBQcW/LUOP/y1HrP/WIuPfliC6UtXYsuBDBTaCoUFdtUXF3BakJNXgKSkBCRZXTj7tG545I7rsGXvAazbdVD2BOMErk5XDPKLHcLeOiTXTMIzd4/CsAsGYOnqv5FZWEyJJW1KScYGvdIPCvrRLZLo5Tq1UxArDqE4Y1UgKSszDsYtkHO4ZokJS2TUwmos43Z5+7kE4qYaT6tSGF/+Y9UZhcujjz4qS4Oefvpp3H777TjzzDNl1VcwsPE2G0uPGjUKTz75JJ5//nlpf/jw4WjZsqXnqOMJJPx84c8tkvb8YbYfyiIYe2b7T9srJZL2/BEN/osGPxCz7QVDJP0X7fZ84a+phaIy/GdxOpyu3PxcNGzQAIUFRbhqYB/0advU7SgMlFRzCFsswaF4YWnNoYwcTJqzGKNvuBKtGtfFzr2H8Oufa7B+6y6xXR8DTuqAtKQ4cNarD75fhBYtm+GNx+8UNmyyh9n4D2bg50W/44bB/REnxEtukR2/bdyNDbv34JHR1+PcPj2QnpWJmx9/BXUSEzHolC5IFJmvWwXxj/vmKIu4uIcEYDWfBUViGTflO2QWFOKdd96RmXV5cGTuRYsWebZCR4XdueeeK6uqwg1LZ1hiU1HYxooz29vtdrmwcT330e/GhfejFkIBRRHGNRcKI2PPs6oC753hwslyuWbYqPBhWLC6MBRoh+Gv7KtrcD/XhOGqFoY1RTbD25+IZUngRx995NkyB7Yro4A2G+/w5aLu3bgmDG8Vx4xxryrGP963Che+k1wYDlxYJc0qavLQQw/hhx9+kL/NguE8YcIEDBgwwLMneG644YaS6X7Mgv774osvwjamGcPa+E4a46H6TegPtTA+qjjJuMh3lPvNhjMQsGTfTPr164fXX3/ds2UeDD8VjipfMYajMV1j2KkmF/7Stffff1/WOvBcsxg/fjzOOeccz5Z4psKDro0bN6Jz586yuGj00HPRpr57xnhvWEVFr9jFzU37dRWSU1Pw6qO3ItYaKxs0u1wW/LpmIyZOnoGcrGxcdHpP5BXY8PGcRXjojhG44vy+wgIjWAyO5hbhytsfR4uG9VBHvNyb9u5HjeQk3C0EVt/u7YSwEYFnicGqzbsw5rm3cFKrpjijUxskxLp7qHEOMzVaNo+lLKIgYtulYosV47+cg4PZubKdy5gxY9w3UAZmCyLCF+Ltt9/GKaec4tlT+TBCFrHHn4ioXLNacdOmTdizZw/27dsnZ7PPzs5GYWFhycLIzJecbY6YGHNhuyN2oW/SpIlcs6E1xYE6xuwEgf6mv8yEPel8ZaJ8gXnfDCO2q2MpIyfK3b9/P44ePSqnL6FbcnIyXnnlFc9ZgcMXmmN+ccnMzATfP16DC58B273xunTnfdOfamnatCk6duwoG6g3a9ZMlg4yc2SCooh2QcT4pOKWMXz37t0r75/hq8KHv3kc45KKe7zn1NRUGfcYHlwYHtyn3P0lqhVFxQGzYHzjc2Qc8H4/+D7ynnm/WVlZsrp/x44dOHjwoIx39AePGTZsGIYOHSrPiXZBNGLECKxebe4gufSfmYJIxUeGLRe+51u2bJFhv2vXLhnudFfPhtt8LxnPVFtMPlO2mWSbzRYtWsj8lPuYDvI4rs0g2gUR3xf17jIMN2zYIMPxwIEDMl3jwndapWtMu5iOMuw6dOgge0WzZsG75oNERBA5nA7XooWLZJsSJiH3Xj4IDWu7vz6Ohb29WFFmwbrdBzFr2V945/kx6NqqkRRJDioRIYhYpZadU4DHJ0zC5u17ECsSgOSUZLwz9l6k1hAiRogV1r45YMWbk6dh2o/L0LJRPZx9em9ceuEApCTEuW9YpBXuRtROLPx9HZ5942P0aNUEvTq3Qa24WLYqkqVC7i78QoxJL5YKope/mosDWTmyDcuDDz5I1zIJhyAibJsTDYKILzIj46FDh+QXGydvXbVqlRRCRCXQgUY2daxxzYTg5JNPRu/eveWaEZ4Rm2IqVCiGWM1nJsxMmIkq+BIzjPgiL1u2DGvXrsX69etlIkmM4cPffIm/++47uV0ePI8L7VN0Ll68GEuWLJHPgAmyOoYYr+MPHlOvnnhvxHvLButMRNiQnUKAiRtHazeTUAUR74fhy8SQGc7vv/+O3377TU72y7ipCOTeifdxTDgpijhCOxv8U6CrRJXHBgsz888++ywgPwUC4xvjnYJ2GSaMF2y2wDTor7/+kh8qyp2o++Waw1dQaJBwCCLCjhDMKEMJO3LjjTeaPqEz/WSGIFLihvGR7yPfRX4c8iOlohjDic+J8bFVq1Y46aSTZDiyHaVKD0MJ02gURBQ3SugwvWQcZvqp4jDv19f7o/Z7u/NDj/fI95h5CgUTP3QiJoi+m/Wd/OJg1dWYK4agbjLnsVIPzX1xoXWkkDmSV4gP5y7GsAvPxp3/uljeDKfwELckjnL/5TorvwD/eWYi9h8+ipcevRtdW9Tz2GCDa2YAFhQVFuOwsFc3NRk1WOIj1AwFTYkdcUFaZlukRas24tnXP0TTtNro16ML6tdgCYT7mry+/EX74libsPXSV3OQnp0rX2yOm1MeVVUQMbLy65KZLzNvlQGrl1JFLn+RNhB8RWxmzmxgzQybPdiYEfgqjQkUCjk21iah+NUIw4ODUDI8Dh8+jAULFuCbb76RJTbe9o33SPib5wYqiPjlxBKQzz//HN9//70UBwp1LaNtXxjv2/ibiS8Tj6uvvlqG9XvvvRdVgojhy+c3f/58zJo1C5s3bz7mXtW9lHf/vvAVJlzzC53V1UzsWIJk/NKsCOx9yw8q43VCwRhnGAf45Tx79mwZJ/jb+xreYcLtcAsiXuOaa66RJZGh8u6775resYX+C0UQMSwpeijIv/32WynO1UeJ8Tl7h70/jOcQtW3cz+fOPJYLP6SCTQujTRAxXWPpLgdCZvqpJhVX969++8MYVgp1PPdRUDJdY/r2JacVi0SVGTOBYZcMk5OjPnDVENQRYsPlipWyxGVhKyCWxziQb3Nh+oLlyLEX47PXnkZaUqxbsIBVWCLzFYpH3SC9vGf/ERw6egQ9u3YWFlgHLi8pFvcNuaMES3nENtUSt2hHuLNhN6vgOMI1q8gcllgsWbEGT0yYhKT4OFzUrxea1a4JS4xVLMKPLnfJE3vC8Xtz3GezkZlfiDfeeEOOraP85Qu63X333T4Fkb/zyrNHN669q8xCsadsGvF1ntqmYmcVBEUhvzrV/kCu5U1Fz1H7uD7ttNPkOESsWuMXktHdF77clCDyd15F7XEfE0N+fTDBZukTi3cVgdjzFkS+zmFCy9ItJroc/oCZnjf+rhWIH4ywJO7+++/H1q1bZeLh7V5Rewq6DRky5DhBVNY5Cn6Bb9++XZ7Lkjfi77xQ/OfLjZkOvzY5FhdLj1TcI4HaU4KImOE/ZoaMd8yQOe4bBQPFuDf+7HG/P0Fkhv+MROocUhF73EdBxGdaUXssFeIHIqsEf/rpJ89eN2b5T+HLjdVCTzzxhKxaY+mltzAqzx797ksQheI/X4KorPMUOTk5UlQy7WQaF8i1vAnkHK7ZSYfVjqopQCj2jHgLIvk04uMT3BpFLBQ1nCaDRS2cNNUihAYdnHYLlm3ciV0ZWbjp6qFIrUHBJA4TbhRFPI9NzRxO8VdcVGgrtGhcF6d07SAEjRBDPFrm5aUe4vHcZpUXRZW0JX5bHC7YnWxtRO+xos4Cq7DRv3c3PPmfkUipnYxZS//ARiG4iu3iKLb05rliRRHldFhkOxDCEZKJv0AiwbgFcg7XjDRUzWphhDZul7efC92YgPp6oL78wZeeQoilEbfccssxYoj4Okfhz62i53Cf8i9fGnbDZybNYlSKhIraU/hzq+g53Me2GXzB2NOOpUL0r8IMPzAOsn0MEwwOZMnrGa+hCNSeEV9uvN4LL7yAhQsX+nSvqD2FP7eyzlElk9OnT8cdd9xRIoZIMPaCcaMfKHbvvPNOTJ06VVZVqmODsRfMOUS5qfeB1TIUMmzf6EsMkbLs+SNU/3kTqXNIuO0xLjCsWRrH+EgxxOdh9jtvxJcbS0d5/U8++USm0XaRfxkJxg/ELP8pynJjWDItY+3HI488UtK2Mxz+U+8M8zJ+SKjnFay98pAlRGxDNPDsgYgT17rn8iFoWDtJChAKEfYIo3JZvzsd3y9fKcTQPzD84rOF4HGXCrGKi1LGZncit6AQ9mI74uNikJAQh1hrHKxCGVmFCpYNn+XNea5sgLdY7HDCJgKa59sKi8SNAwmJ8aiRmIhYqitxnsPCZt2Q1XEfz5yHmbMXok/HNujdrgWSxDUpiFgll1Vkx3Offg2bOIcRn1U35RGuXmaczNTYTiVY+DXBr2zjC+wLNsacM2cOPvjgg5LEVvkl0nhfl9ssAmVpEYcAMH6xl4exyswsWD/NRpPBUlaVGcXJihUr5DOj3yMd/mY/84pUmbHNFYXgm2++iaVLl1Za3CPGa7PY/b777pOlRoFWWRhLiEKFfuJ7zIVikX6r6HPi8ZFoQxTNMAwqUmXGDzCWUr744ovynTSGeUXD3wzUNdnujx9K7B0caKNrfiBXZpWZCkumBWyHGomwU+EVjmfls4Sodoq7VxnHVGSJC9WHLO2xWIUHnNiXmYvv/1iFq/95gRRDPIslMXBQDMUIxejCbqF2d+3Zh2279uCvtRvx++oN2LRtJ7JycoVYssvj5DlecL6ynIIi7Ni7DyvXrhfnrcXG7buwY98hbN+1D/nCjaVPdgaEs1gIHgdSk+JxhxBm9930L/y1dRcWrt2EAuEX98SwQK4QTA5xuEUIKWZalYF6cCydYdF4qAvFGiOEP3g9JrKcj44vvvHLMxKR1hfe1+U2Gyrfdddd+Oqrr+TLXZmEIobKgonGn3/+KTNSfklVRvhX1jOnGGJboZtuuqnSxBDhdb2vTf+wPSFLq7y/zCMB/cMqxEBLqjShw3eRGTc/eCmGiDHMKyP81TX50cD4yHjJtjjRHhf4kcdG0+y1zYbykfKvuk4kricFUaPGjRBjlS2BkFtQIIWFI8ZdVZaV78C3v6xAv1O64sbLB4kvK6esktm29yDWbdsrxyOyFdvQtnkT9OzSDn17dsGAPj3RsW0r2f5nw+bt2LOPmYK7SkwhM3exZOVkY+2mbcjOK0Tzxk3Qr3cP9O/dFb27dkDXTu2REBeLjOxcbJXX24MjOQXClrsh9YUDeuDxu0dgw679WL5ppxBNMULECWGQmyuvlJSYVFJlVtVhVRRVO9uDRTN87qxGZNdwDuJIEVeV4EvLYnGODM6eF9UJJpisruPI5bz3aEzg+XX7wAMPyEyS/tVUXdS7yFI09iSLNpgWsp0nZwr45ZdfpHiLVlhNxo88VveF60MyGpCCqG6dukhIYM8yILugUHZltwp1xAc09/fVSK2bivtvupZD/whxUohp837DqCfHY9TzL+O+F9/ElLm/YsOeIzgqxArbEMVarWiUloqu7VvhlJ5dUbtWshQxIgqIf7wk2wVRfoljhfDq2bktenVpjxaN6iJJCCCOU1RYWIT0Ixn4ecUGPP32p7hx7Mu48bkJePG9z4U4SofNxVInC/qd3AX/GXU1lqxci72ZOdL+kdxCKYhqp6TIRrNVHdUlnV1Hox1jJsmSBIoiJgpVBT4LNuJVVSLVCQ7nQDEU7V+7TNDZruiPP/7w7NFURVhKTrHhq/deNEA/cWGpIdMMivRohYKSfuTHbFVO16Qgio2PRf369eRGTqFdKlc2lV6/9yC27DuIe0YNR0pCDHYeOIoX3vsSEz7/Eq3Oqo+L7uiFjLpZeH3GdNz46HN45cOvsGrLHhzNzkOR3T3CZ6w1BnXSaok15RCtsi2RO0A5qnRKrVpIlPWnLhQ7XcjKK8S2/Ycx4+ffMGb823jojbex8vBG9LqiDc4d1R0/rV+FO5/5L5at3gxbkfjCEwJs0Bk90alda/y2fhvnh0W2J4NNq1OnZAycsqqbgnGLFnvMfFifzm71RqLFf+XZY3UgG94av45CseeLSNhTiRsb7/Kr1DvRiIQfFJVhj4k6B6nkmoRqzxuz7KnnwhIsth/wVYpXmf5TlOXmj2jwXzT4gTBdnDRpkuxxaXwXo8V/3m78kGLPNwoOf0TSf0aYNnMYD7aFLItI+s9sewopiEiz5s2FJIFIIPLZ0hoFxQ4sXr0J/zj/DHRu3QyrNu3Cw6/+Dws2/YkB15+EAdeehMa9a+Gye07HlY/2Q4fBrfDrnr9xz/hXMfb9KZj/+xrsPXQUeTmFcAhbnIXMIRtiu6vOYmTvNeoZO3ILbDh0NBt/btiOt76chdvHTcCrM6cjI7UAF9zZHdc+NRDdL2iKdv3q4rIxp8PRBHhq4iR8u2A5skQCHCvu89rLLsTGXXuRnleE3LwCeS8cuE6NP+KdQRkJxi0a7LEdBOufP/74Y8+eUqLBf6Q8e1xzwC1jl/dQ7PkiUvY4HseUKVOku/fLFyk/kEjbY3H6jBkzZPsCdd+h2PNFOOyxDQd7r9D/RoK15w+z7fkjGvwXDX5gBs7S8pkzZ3r2lBIN/iPebnxvWMLKnltqIFhvIuk/I/zAY+cRHh+sPX9u0WJPUSKIWrduLSQLZPsbuyUGf23ZjRhrLG69ZihWrtuCu158XRwEXP9sf5wyqDFiYosRw1bYsQ406pCIM/7VAv96ti8G3d0DGWlH8MzkD3H7C69h4lffYunqLdh/JB85eXbZfZ/d6vMKC3AwKxfrdx3ClDk/Ycx/38XdE17D7xlr0eua1rhh3EBcPqYXOp7eELE1HOJuRESPcaBBp1gMf+R09BreDi9/9QXe+2q2cLKgX4+OQgClYcnq9Tia7x75lkP7B6IKT1TYQJkTqRoH+TvR4PPhVxEbgqvShRMRPgOOL6IaivPlq8pxzwi7D3M8Hd5vIIlOIBjDLlzhSL/yY0KN1q6pGrBUiNU7/oRFMDAOqnjo/Vut1e9gUO8NP6hYah4tUFxyPlAzwzKaKRFELZu3kOuj2TnItrnw67pNuHrY+aiTEo85C35DvZNqY9BNPZFYLwFOCydqAw5tz0V+RjGKC5xy1npXnBONT6qFs0d0wogXzkH7oQ2xNH0txrz1Fm5/fgLenzEHf27ahg17DuCL+Uvx4Ovv4cYnx+GL5YuQ2NOKK589HUPv7Yn2/dKQVMcpBJAddpsD+TnFyNiVh6JMzqBvhSuhGF3Oq49zbuiOmfMXywlkE+OsOLN3d/y9YzcOZbHYkVMrhH9S1cqCEXTixImygfuJnPmqhIDijuNMmJWhRhoO72AsISEn6r1UBJauUFSY0bZAZSpcWLLLeY444nnt2rVL5j1Sc+QZwzkUKMI5Jox3KZHmxITPkUOOmPVxZYyPHC6B8ZFxkW1TGR85VQ7dGfdDjf/qfFb1RYsAYScE7+YYVZkSQdS8WXO5zszNw8od+2X3+0EDThUPyYoGDerLcYZiYork+EPsPWYpsuLzcb9i+vMrsGbOHqRvKkBBugW2fAccsMGaYkfXs5vi0jG9ccP4s9D2okb4ccdy3PHf1zBq7Ev4eOFsxHcBLn3qdFmydPolbZDWmGKLs39bkJ9lQ9Y+B7b9chTz3t6A9x9ahANb3ANAOWWPNXGt4mI0SEuDlYmjKwan9ewku/CzyoxEYpb5ymL58uWy1X9VgYkKB0k8EXtm8SuKVUYqYaxOcNwrDnbHew8Vhh3tcNwuzoV3+eWXywE9OW4Vu/GrIfzr169v2uStvCb9r+Zd0pzYsPEvS1jMeg8ZzxjfONsA4yPjIbvKc462Sy+9VM6dx9HHzZivUcFhIdgUorJhGDJdM7bvrOqUtiFq1lSu84sdWLL6b5zavTPqptQUoQJ0atMUR3Zkw+WMldVqDChrggsNmtTBrrUZmPPuWkx6eCG+eGYplk/fhcPbC2HLEcJJiCin1YmENAtOOqcurnq4L654rC8G3dcd1z9zFk6/rDXSWiXBFVcsLuNEYb4LOQeKsW7eAcyeuA4fPrIQU19cjrU/74HL4ULT1nWEDGLZD9sFxeLQ9my0bdFUbDPyu3BSh7ZIimcPNnFb4sA6VbTLPb+CzJxw0ggzJLUYKW/bDNhoj4NKRgO+7s9XuBBWGXESUD6PcIQLMV5b/Q7XtSoCx8fi17gZcZH3w3HD2DOIbSnYE4wiiINCcn3rrbfKhtCcjqdHjx6mhQFLWSmKogF1P95rI+F476sKP/74o2xbGWq84PlcKMw5wCgXjp/GOd4YH//1r3/J6Z44oCGnZ+L0RBzss6znVhHY/qmynzOHpWB4RhLvcAs1HCtKiSBqKBIiXpyPICMzG927dBCOLIkRYqlxQ+Sk58JRwMk03Ik+2/Oc1LeF7IpPlZQcl4bijDgsm7YVH49Zip8/2oh9m3JReNQFh80Ou0WsY4uR1iIeTTunwJVYLK4uTrQXoyhbfGnuLsaqb3fio4cX4Yf/rcW+v/JQw1FbXM8qFgtadqsvhRX7qXFSV45rdGR/Lpo1aiD2yGEfkVIzGY3rpwkPibsQ/9ntXlFWwAbjVpn2OLCbGmRMuXm/PKH6QVVZsHiYVRYsKua2r0kyQ70Wof+5cNTdsr5IArVnJFQ3rpnY8d75xciZlznKthppm1OTqPD3l4gF4wfuNy68riqyVzNnc5/xGHWeL/ztJ8G4cT/v3Zd7oPbUb655PywNOvPMM48737jNEYrZvZ8lwAxv72MV/vYToxttsFpAVZuFas+bQO1x2/t++JulDyrOsdrG36jG/q5DgnGL1DnEDHsMO8bHsqiIPZYMcWy3Nm3aePYcD8/hvGRPPvmkHAFdPb+y4iXx56b2c0gI77ahodjzRVluhCVVHLrAeFyw9rzd1DbXjNusglT5DH+rOM5w9IW/a1XED74oEUQcwFAVQzPLa9/a3aaIEqR+nTQkIhaZ6XnUGfSlcHChY99GqNO8pvgdg0svHYrHHnkI559zLhrXa45tv2RhyhNL8e2EP7F63n6giJKFc5zFuC/KajeR/uxdn4+fPtiADx9dKMTULtREXZzauxdGjRyJsc88g8SkBMTWiMGp57aCw+rwTP8hri+WjP15aNakvvAjb9QFqzDcpiWr/uhLIZA8I3ATfwFLgnGrTHvsQaFEgxn2FNzPOFCnTh055Qi/yjkxLr+EOCfaVVddJb+Y0tLSjpn6INhrecMIy54WZQ38VRF7ioq60R/MhPhi8r1gxstMmGFy1llnYfDgwXLWajWVCMWpsuPvpQvGf2o/xQ8nsvzHP/4hi+r5PFhact1118lpaThpLjNKdXx59nwRjBu7Nq9atUr+9r7vQO3xN89lfFL34wt1jlozs+IcdBSp/q7lbz/xduMYMKq61gx7Ripij8+RGQPjHZ8rZ5xndQ3DhSUTrKbp1KmT5+hjiYT/FGaeQ8ywx5I+jqBMQrXHOMnqWlaHlYU6h2ki30umG9zH8wO9lhG1n++Wd5OIUOz5oiw3oj66jQRrz+im3neGGTtznX/++Rgp8nuWCHNaGuY7nE6E8Z8CyTttIf6uFaz/FHIuM/5g7xjO7cRB8pKsFsx8dxzaNkwTssICm8OFf45+FN2ua4VOZ9UHZ593WZghW7H118P45vXVsOfacdutt+O2O+7AgYMH8cOc2Xh5/MvILyxAnVY18e9xZyAm1YJYJzNSBxyWOPHbhXmTN+KPqdvgtLlw9TVX4crhw9Gta3dsWL8Ozz33HJavWI7uFzbFkBEnwxFHQUTvOmDPtuCNG+dh0hMPonenluJunXAKmxMmfYn/fTVXSqLFixah/xlniF/lY/ZcZmbDzJmjABNGHNYxl/fSBYqywy9QCh4WB59++uke12PhVzS/plmlwe6Y3DbDDwr6hYk+R5c1vgjhmMtMoe6fYpDhzIUZETOeLl26SDHEDNgXFKbMqNRUKWY+D2b2/Oq84YYbMGjQICQkJHiOOBZOD8KpUL7//nvpD/pJ2TALX3OZrVy5EqNGjZLXCeV6PJcZD4df4O9A4HGMexRRZo12znGUKHiNmDmXmTfqXpmJsvSVHyJsk9KtWzeZFvPZUwyXhZ7LrBTGx3//+9+erdBgOzZ2FlCFBIHCNkah9lrk/fFdYvUc2ysZieRcZhR4TOvNTEd4bxRDnMuSz4qlwf7CmO814zbTNoYp07VQ0xpvvOcyKxFEVKR8AZmgNqxdA9+8+yLq1GRDMXfF2c1PTYCjvQtnXsviQwoTp0j9WTYTg7ULDmHx5+uQn25D3bRGGCgSFYfLjpkzpiM+zYp/jO6FVqekyXGIWE4k/zNgxNouPsq+ePE37FmVgzNFJty6XUf8+defWPP3KsQnWdHpzPo4f2RXWJJi5TxmbpzI2GbHJ/ctwOz3XkLT2rVkY2z685OZP+HZd6ZIQcSGx/y6CoQTRRDxOVFRm934mJHyiiuukOHgq1pMoSIkM2G+ML4GIQwV3uvcuXNlUaoi3IKIX+X8WmHJD7/G/X2ZeMP2Qyy5MRs+AyYaFCGBTmLJUg7OPs0Z3s1+Jr4EEefNmzx5ckjXUokbnzUFQaCo81h9bFaPHApPTk1gJJyCiO8c4x3bQzF8+RES6CSfCi2ISvn000/l4IZmxH0+B45jV1EoWFTP31DgPXIibHY0MRIpQUTxwZJwsz42VFrKcOF9vfTSS+WWvimY9nMqJJaYqXA14xkTn5O7EkYA9TIm16whu7HTmZcVSQ/aiS+W9B1HYM+zwekQ4oONh8Q9ssTmpIEN8H/PD8Qpl7WFLTET38ybhu/nf4O6bWpi6N2noOUpdcRxDliFMYddiKAiDszIc4VAqmXBsNtPQdvT6+GPjb/ji68/wY70dWjdsy4uuu1kDL6pF6yJQniJr0HOX8YCIkchsH9bFuoLFZ+WUoOGPP60ICW5Jm9BkhDv+4v6RGbHjh1SDKkIZga0xdIQljyVJYaIui4jMzOKiibggcD74yCHkYD3y/GqeO8s9aIgClQMEXZLNRtem42LmbgHKoZI586dZcKh2jaFG2NVYahQ1FBcBrrs3btXrs3snhypOEdYItSrVy855Q7H4GLJFN8ls8KzOsLnZ1b4sUGxd5wLZDFrGBTaYNrCUtDKgB+8FF+h3odCPRd++HDsvEDFEGGTBX6MqTaD4aS0IYhAFcknxcfJKTeEzhAB4vZAn+6dkL4xG79O3YtDWwpRnOWUgyxyjjIKm8Q6Dpx1TTuMfOEsDH/6NFwz9jRc+2w/ND+5lhRD0pjTgv0bsrF+yUE4bCzn4QVcqNHQisvu74XrnuuHK588FTe8MADDHz8NHfoLhR5bLIUOvWEXQih7vwMbFx3EillbMaD3yZC6Tcgh+dhEYDEzUI8wLs6crrnRgIoIfEkYSc2MGLTF4tmKihtWrzFRDweRmECQRbcUgvxKoBBSYrAiiUA4Jo3k82CpU0WHjaC/+TwuuOAC0xIyf/ALkgPghYqKx2bG52CJ1ASgfM9Y1cfecqwiMxLu51aVoSAxK/yCjY9mxmc2X+GUHpVBOEr+aa9Pnz7o0KGDZ0/gUECxxIrP12x/GTlGEKm6PGYMpRHLffEzenfFkFP7YOuPezFj3HIs+XQbDmwoRH56MYoyHSjKF4tNfK3F21GveQ2kNk+CJVFWrjEkxH8nsvc5MeetNVjwwXps/ysHjmJxLYoqp8iIrA6kNIxDg1YpiKtlQYG9CIVFwmaODQVHnMjc5sSaufsx9fllWPrRNrSIScPIKy6WU4BwhnvlT2MJhzHcynpRgnEL5ByuWQ3Ah6kWfvkbt8vbz0W5EVYRGCNEKP5TcJsNhtVvX/jaT38wA67ItRRlnUMyMzM9v44lGHv+3NhOgO1GfL2ggdoz+jMYPxBvN253797ds+Ubf/b4TFgN4yvRMMt/hIk1q2/9Ecy1zPQfqeg5qhraLHsK5abWfLZse2XsmOBNMNcK5hxipr3K9APfRRXvzbBnpDLs8bdxbrNQ7XlTlhtLiOjunY4Ea0/FdbaPM1IReyzsCNfzVfh8I40vqjIRByceuPUavPPMvbjl4otQvMmJH1//C9//dzV++XgH1sw8jI3zs7BzRQb2/p2F9M0FyNhRhBwuO+1IX2fHnPdWok1yE1wy4Ews+mgtdv6egYw9BcjeXYiMnYVy/KIDG3Kxb2UOti7JwPofjmL5F/vww8S1mDVhOTbPPoBBnfvgxbtH4rWn/oNm9TiTvYN36vakEEVWdjXzwK9Yha8MQhGMW3nnMPC5vv/+++XIqWphw1Hjdnn7udCN42AQVV2mHm6w/jPC4nvVaLii9lq2bFmhayn87Vf35W86koraI/7cunbtWtJOwPtlCdQei8gVwfiBeLtxm41qg7Gn4p0vgrFHfLmVNxJwMNcy03+kIucw3JTAM8OeEeXGNa/DtkJce8c5I8FcK5hziC83Zj7GIR68F39u3vuP/UAN7z0Z0wwz7BmpDHv8zao7Raj2vCnLjfmMcjfG02DtseqPdphfGKmoPfXe+DsvWP8pjhFESkAkxMe5A4HnSxvuHwlCbLRvWQ/XX3Y+PnrhIbxx313495lD0KNmW9TYHY/MpblYM3kPlry2CXPHrcGssX/hm6dXYubYFZj7yl/oXKMFxo0ZiTEjL8PVZ5yFPydtx9d0f3qFWK/C98+txs8vr8Uf723D7lnpsP1VhFaFjTH0pAF45saRmDL+ETx8yxXo37sLatdIBGfLt7hiZHUaq+5EcMlSLvX8jIIo0qjAZwkRS3hCXVT1id1ul7YDebiBwOfMEgX5vCsIz2EpSzgw6/78Qb8Hc8/ehCuOsUuqGf4LFyoeVhV4L5EI70hdJxTovyFDhsghN0JdmHZFCsbJqkZlxZVAhVhFoB2ma6ESznTnGEFUquY9FzQ8C9mrzOIQ4sMKqzMGibEudG3TGJed3xf3jLgML4y5Ce8+cy++fO1pzJj4DKb990l8Ou4hfPTsg3j/qfvx2UuP4MX7bkaTtDpI5KSxwy/G5688jneevB8fjL0Pnzz/EL4Y/7g8d+obz+Djlx/FG0/chcdGX4Mbhp2D07t3RJoQQVYhgGKE+GFjbvYsk4MZKf/C6VGi7q0Yw9dJVcHsyEB7jPzB2jW+OGZAfzARMH5ZRjNlVXsEC+8/nC+9GUR7pq4JjTPOOEP2Og114XhKkYJxsirFy8q8F5Wume2HymokHijHpOaqUXVRUTGcngTZU/AiEBkUS2PY3kcIIxccQn5YxZrjSAtXp0MurFqrEWdFWnICmtRLQYuGddCmUQM0SU0RR4uvaWHQGcNu+w6kCIHTrmld4d4QzeuloVHtGqgVH4N4q0vY4kSu7FnGptdOcR0u/EUc4qq0xQyUflAPzSIyaJsIdPfvJEO37aoCxywx88WnHXatDGYyRGba4ZgpnHY5QN2JgL+xgUKB9x/tc2sxHmqqJmaK8UgKezUooiZ0mP4ybzA7PNV4baFgtkgzcowgUpmQjaJCBISsiqLqELDLO39xpntZPSXEEV3lEdJNBJ5HmJQEojiO57EUh3LGjVArJee7f7PBtfghxY60wWvL493XdF+Pe9S+GOG/0tKskiuLgCpp0yF2JAnBVdVgkaMMbxXGJmC32+WgZsHAIebNhhE+mDFAKgOOmRQOOKZQsM84ElXFbCsSjtIxTeUTzgwnnLDN0onqd1+YmcZXFKa/6vpmhSntqJHEg4HpWrjD5JgUjYkcyS0oFKJI1ccKUeP5RfwFzvH7ue2WKpwdn+U8HtlyDIHbK+U4N7HJYKJPD2dkyt9sS2TMrCpkz4Ap/jMQqj22JTJuh2pPRbCffvqpzDp4X/bYJdTfXFaKivpP7eew7b6oqD0SjFug57ANldoO5jrEl9vvv/9eZvGyP3tsWMo5iHy5m+k/fjyV1X4smGuZ6T+i7ZUSKXuV6QfjwJ5m2DNS3eyp9Nf7mGDtEeY1HFzR2MwiEHs8jx0eWBvBfdz2d14g9sriGEGkGu5m5+WjIL9ICAu3zJArD/4U2vH7uU2Pc+WWQ+59xxK4vVK83bgpy5tcFuzdf0juS06ugeSapYKoIvaMmOE/I6HaYyt9Y/1uqPYUHJF3w4YNfkWR9zksieOM+xRFFb0WKescjtPCCRN9EYw9s/1ndDMOFhbMdYgvtwULFmDTpk0BPw/CrvCcJXvZsmWePcdipv8Ix3BiHPSV0FTEHs9nnGbPJn7EsNej90I3X/u5+HOr6DncR/z5PZgwItXJXmX6gWmG2heqPcZJxgcVH82KY2oJ1J6xFDZQvxsJ5hzCXq5sx8ljjMcFa0/BNM34sReIPYohDgI7f/58uU38nReq/0qm7iAceZijpsaLZzDlpcfQvbPIlITIcFdmla+uFIxMssrNs+0e71qY8sgi0xEXYrQpKHLilkfGY+m6LejQsQM2rN/gdg+AcE3dwdGPA50+JBAYkTiFhfd4RGZAscVRRDm7MxMCNS6VEWbQHBuDGfbzzz8fluoZzm/DUZqNmD11B+Mor8NxiEKBbX047YKZ4UC/8dmyhw5ndee8akwoud8X/OLiM5kxY4aMb4wjZscNX1N3fP7553IIfuXfUGDp9MUXXyzjnRn2goEZEAdMNBKOqTs4Kvr//d//ebZCIxxTdzD8+f4NGDDAsyd4OB0KJ2w2E/rP19Qd3333HZ544gnT4s6wYcP8zmEYCXifV1555TGl0JGcy4w9DZnumv0uNm3aFC+//LJcq7ZKvmC6xratv/76K1544YWwDFLpdy4z8sknn8gXleLi+Vuvw7Ah/WC1xMEpe3JVAHGDBw8fhSXGilo1k5DAhsDCqBw/MUyw59meA4dx1Z1P4GC+XSSuF+Kbb771uJbPiSKIyFNPPSXu7RvPlnkwYvKLhHOlcYJVzm3HrwTu50vBTJ8jSHOyvZ9//llmvMrNLCjCmBjzJTUSrYKI905/mdkIWiUQtE2hwNmfOfo020i4h5VwhznFKb+eWEXG0jrO3RcufAmiAwcOyHjC6TNCiQfqfocPHy4nfDRmAOGE/uWivsL52/u6WhCFRiQFEefwu/zyy8us+q8IfK85jhyHJYkETE+JsVTIm0gKonvuuackTwz23fYFnx+F5rXXXov+/fvLDxE2iOd98zoUQkxTOE3Vjz/+iFmzZpW8q2bjdy4zwknXYoRn+Vg27dyDvMwCsLu9SOrEHq8Eipt+0iz2DPt23hLcN+5tfP3TMmzYeQAHj+QgO78AhUU2FIsIWywy12K7Aza7EwVFduGWjyIHy5CObbMUEOIEW1Extm7dhYx8Dq7mwkldurjdqiAULGW9NMHCCEfRM2fOHNx8880YOXIk7rvvPpno8uVg4nbrrbfKokuzxZDKiFhU62+m/WiE/uYUJgp1H6HCcKUtDpD27rvvypKLBx54QH5ZTZw4UQo5PhdOuUIxbxRDZvmhPFiCxfnTSLDxgH7luVymTJkivwQ5Sq7KHMIBRWRWVhZ27twZ8EjjmuiHVWb+qtorCuPC7Nmz8dprr8meUeGMj0xzWfrBudgoeKIFpmvq3TQbfuBSdPMjiJOEs6SZgw9zwmiKUO7nh8O3334bNj/44phclZGppqch8rptu5CTnQOHzd0ASqUVJYkG/WfwozExYSPqk7t3w+oNO/DE65Nx3T1P455n38TEL77HzMUrsGjlOixfuwG/rF6HhSvW4OsFv+Gtz2Zh976DiFEz2peROKlrlVxTCKmco5nYsG0PHFJOWdDJSxAZ/edNMG6VaY8lTmowRTPsGVFujIAsAeDXHetv2evJu/hU/Q7mWt77la1zzz3XFHtGwmmP/lbTl3Axho+RQO0R7zDmwsbS7AnIaoGpU6fKryY2UGRVmb9relMRPxjx58b9ffv2LfltJFB73n7nFyGFHjMHipZAxrkq61rMbPi1SWHJ4SUYp5cuXSoTXgp8X5Pz+rMX6D15U53sVbYfTjvtNLkO1R7jJbe//vprWQ3HefsoVhiXAn3fvOF5jI9sf8n4SDHONJVpLMXAiBEjypxgOFC/GwnmHAWnc/IeDy5Ye0Y3FX5cszSPbVfnzp2LadOmyZoPhgeryngOj/EV3v6uFaz/FMcIIrbS79Cho/y9afd+5OQVIPdwFpx24SGPn5TneCJnrFd4e7pHx1Y4tVt7xMRYkFdkx4oN2/HR1Ll4asIk3Pn0W7j5sTdw25MTcffYiRj7+sdY+sda1E6pLcSUCAB6/FhzJfC64gg2bZJr1uYVZuehKL8Aa7fvBrv3x8XFi0yqt/sED74CVRGMW2XaY6NjVX1khj0jlWmPMyGz9KssKtN/CqMbXzImwuXNVG6mH7i/rMSiovZIMG7czyJvX+O/BGNP3RMTxBtvvBFvvfUWfvnlF9m7hFWSzJCYifBrmkKQC39zH8UT12xbx2MpfDgj/vr166XImjRpkqxqvv766+UXKBNef2LSn/+CuSdSnexVth9YDa4aA/siGD+wJy2rONlmklWorMoxxkfGPWN85LaKjxThLGFifOTkwex2zirOjz/+WJaGsiSecZ1iIJqmwyHsNOE9/Emw9sryn3rviVG0BGvPH2W5KY5pQ0QefPAhvPTii0J4uPD0qKtwVrfOSKyVgJQ6qbDEiohG/0pPixsRZ/q6hLg98deFzfsycO+zr2Pn/sMotJUO9qhg9VxiQjwa1U3F2DtvEAKqnRRE7ik5KHeOh8NAyjGN6AeHU4qh7KOZyMgtwqhxb+JQVi46duyMVatXyoQ6UE6kNkSEMzuzDpYvnjFCnajwHgYNGoRnn33Ws+dYorUNkeK2227z27vLTIwJBonUc/fVhkjBdj9qHCuz4qK6T9pig3I2wGzSpIlshMntkjHTbDa58EuTX+98H5hRceFv7jfi7b933nkHvXsf+/FkRLchCo1ItiEiLIFhdQtL/kKJh97xRG1zzeYK7IDC6n0OzMoPOcZHtu9T8VEtFDkqPlIccZ83Rtv8CDj11FM9LsdDO5FqQ0RYcsWPiVDC0h/GMDb+jiRltiEiw6+6Csm1kjkONH5YthqFQi8V5IiHmn4UjsJiOZaiUDbyWP/eFzdnsaJVo1S88tBoXHJOH7RuXB91OOFfzWSkJNdE/dRa6NyiEYYPHog3n7gLfbq2lSLMKmy7xdCxCb/CXSok/trsyD2aJcWQ02nBkr834bAQQxZLDK677hrE+eghVZVg5sCh8avK6KzsXcQ2SycqbMvDxJEvdjjhszYu0QDbN5k9Yrfx/pipbN68GQsXLpTt26ZPn45PP/1UNiRn9SFLe1iVyJIgdullI3OWFHmLIRItYaYJDywdYikgS2xDwTueqG2uKbpYtcWetqzqYbUae1xOnjxZdjjh0Bdsf8S2luwhxVJKlhD5EkMkmuMkO02wYwfTNbPTNuN9R0sYHCeIevTsgWuuvhrWWCt+XbcJa7ayjt0Ke34RjhxIR86RTNgLxYOV1Wg+bkKGmTvgDhzKQM34ONx709V49/kxeOzW4Rg9fBDuvPZiPHfvCHz08qN48KYr0L5pPTilQhQLpwgRqEk6ShDXYmGW3eZAfk4ejh44hPxMIYCcMcjKK8QXPywUZ8SgcZOmuOLqqyg5PSdWXfjis57XV/f4EwmKOn7V+friO1FgQ3B+uXnXuVcHzjrrLPmVqXqJmI1KiL0TZV5LLWYn1poTF3YXP/vssytUQxAsvuIm11UlbnKARg4/oO6pqnOcICJPPvkk2rdrB5vTgUnfzEeGEEPiccPldCIvO0eIkcPIOpSJorwCOIsdJSVGPMb9w4UYEXhs+Ltl9278uXq9+GJLR7cOLTH8orNx/dDzMLB3V6QmxYnjnLLNEKVQyT8GvjQj/vKHwwl7gQ15Qoxl7E1H1pGjsBfbZRumYiGIZixahp3pRxEXH4vHHnsEbVuduBlrRWB3RdZDszfAifrS0d8sImbp0In8wlEMsGqlQ4cOcvtETgQrCu+VvRHZ6ywc963ihcpgfFEdEmtNYPCj5PHHHy9pqhDOd9E7bqrFiPf2iQY/vBs2bFgt0jSfgqi+SNhGjRyFuNh4rN21F3N/W4l8Byd0ZUWWOMUJIYbykXXwKI7uP4S8jGwU5whxJESLUFFwicUuxFNSYhx6dO2MeqkpyM/Lw84dO7Bvz14poFxicYh4woV/LPzB/UL8wC6uVexCcaEdeZm5QoAdkdcpzMoVxxbD6hBf4c44FIsHtPHAPnz581LxsGLkVyrbM/h6cGU9zGDcosUeizPHjBlzXK+zYO35cwuXPTbaYyNXfs2pfaHY80Wk7LFty6hRo2SbAiaCxuMi5QdSGfYohm655RZ57yRUe95oe6VEs71o8ANhFS5FunE6DxIt/ivLzR+V5T/On0lRpMZA80cwbtFiT+FTEPG0kaP+jZ69elJu47M587F8/TY5ErSVAsYlBEuMSPCpYWwO5GbmyDZGhw+k44gQLpnid96RLNiEUIotsqFto4bo0a4DenbuimYNG8NWUARbfhGK8wtQnFeAgpw85AmxkyuOzxLnHt2fjsN7DyFj/2HkHc2CXRzPhtb0roM3JRaHEEa70zPxxpRvkFtkR926dfHYY4/5rbIoS6UH4xYt9viQWdXEcYI4oJ06Nlh7/tzMtkf4zJhosXGiMbJGg/+CPYcNUVl15l1cHyk/kMqyN3jwYDnaNBuYmmHPiLZXSjTbiwY/KNjw+a677jpmYMVo8V9Zbv6oTP/985//lJ0PymoSUJn+UwRrT+FbEIkTU1NTMPHtiWjbujWyix14cfI0zF6+Codz8mET25xxnuaZjVEYqdIdh80uxU5BVr4UMzmHjiL7wBFkpx9B7uEMZB08LIROOjIOiLXYn3HwCLLE/hxxbH5GDmy5BbLxtoulRBz8T/iF15CXED+c4hpZBYVYs+MAxk76HGt37UNa7VQphgYOHCiOqn5QTLAXEEtaWOLC6ptA1HCkUH5Ra369sdfQww8/bHqPicqE98ew5wCKKvGIpucQbni/FLgURRTnDAvCMKhO4aCJDhjnGBcpilhSpOKhjosVh2k2m9KwzSpLgatqGPoURG4FYkGvk3vggw8/QMeOnZDvcOH1qbMw9uPpWLB6E45k5SHfLgSQ+4xjEeezQMcJq3vxhJ1ViJsYp7ioUDfGhYJKLu5TJe7xiNwLz7eJ87LyirB25yG8//3PeOy9ydi6/zDqNaiPMQ8+IEdQru4Rnd3WOfdVayFiy5ojJtJQmSu/cPqJM844Qw5HUFUFLKvO+Bx69Oghe7tUxnOorGfPYnUKc2ZC/EJnQsrnH8jXmUYTDoYOHYpHHnlE9sxV8VFTcTjdxquvvirHimMaVxmEO13zLYiELJGDI4p1/9P7Y+q0qThzwECkpNbBiq3b8ewnU/Hku1Pw4++rsOPgERzOLUR2oQ2FNru7fbVY2FiaTaNphfOMxXgcKJSkWJKLRS5uGcTFvY+dZTmtR1GBDVm5Rdh7JBfLNm7Hm0KQjXnzA0xb9Bvslhi0a99OPKDXZBuasoryqhN9+vTBG2+8IbtLsoeAUc1HIpP0dQ3uo0Dj3GhsZ8IBztjmpCrDL1IOR0/RxyEFVKmd2c9A2VR2uWYVQXkjmYcTvovMhBgP2duHbRCMPSGNfoq0/yojPDSVD99DZuYcCZ8Zu6rSVu9IZcaLEylO8gOPtTFXXXWVfK9VvqvuwYx78WWD+1j7Ee6eg34EkfCA+iM80qljR0yb/hWeHvs0unTpguSU2lizex/Gf/4t7vrve3ju42n4eO5i/PD7GqzfdQAHMnORnlOArPxCZBUWIsdWjDy7HQXFdhQVO1AoliKbWIv9BUJI5RYJQVVQgCNCWB3KzMeOA0ex7O+tmL70L0yY+j3uff19PPHOp5i7Yj2csXEyo7/u+usx67vv5LhJJ1KEigQNGjSQ88Nwziu262DmzAxZldSEM7yMpUGEGSHbCrHo+u2335YvUnURrywNY0kRRSDFIF/mcH2d0i7DldPvsLSUg41xX7iuFwgUvc8884xMQLt27Sp7RRLjvFCR9h+vp+In46aq1tNUfVhyztHKORgfp5xhhxT1jlTWe8K4qOIk42O0p430J/3IgWj5XjNMVbqm7iVUlA31nvIdZfr56KOPyjQ1nPhMDZRHjDDyMKFdtHCRLJFp3749UkVGm+8A/ti0DV/9tBQvfykE0ivv4vbx/8PYD7/EGzPn4NMfFmHGouWYvWwVfvhjLeav3ICfxDJvxVrM/m01Zv3yJ6bM/xXvfD0f4ybPwD2vvYebX3wTj33wOd76Zi7m//k3DmbnISk5BY2bNZWzGXNgNn59tmnTxuO7Unz5nfjbT4Jxi2Z7KnIyEjHSMhFgw2uWGhi/1H0Rqv/Ub5YIUQh169YNzz33nGxXYywVCtSeN/7cosGer/1MPDjGEidoZVUhX2jvRC8UP6hnzfezo/hwYakUB+z0lbAGYs8X/twCOYdrjlNEcc5wYPddxkNfVYmB2POFPzdf9nldltixlKB79+6yGsWbQO0ZCcatKtqLBj8QX24qo6U45yTJnDaDz5/vDtPFyvAf31N+KPCjlcMEsG2lPyrDf94YBQ9H+ufkt3yPGIaqFNwXweynPdrlUCZM19TI6XSrqD1SlpviuKk7AoGBsnv3bjka55zZc/H3ujXIy8+XI3EW24phLy6Gw+6Aw8EqNJFgGwLRG7pw4c1z4QjTsUJxxoiIEh8X765qadoE511wPi68aAh69ehVbqYeDGzgy0kfzYaTSLIhWqRRGaWC8+xw5FSO9stRfznNAZ8X13a7/ZiIrs5T+4x2jMcp+Nz4YrN+ngsjMccWYvE0Jz71lTlXFM4dxJ4O9IsvP1QU2qFA4ThOkYITlXL2Zo5sy3mNOGErw58j3/rD+Cy8nwszd9blM3PnYHQcQE19QXFKEl7HrPBi+zS+I6Gya9cuOXovZ+fnpI6c6JILw4YlR+o+y1p7w/1Eualt9cXNOMnfTEuYuDJOMhHnXE3lxU2+M/yoMAv6jR+WnHbHDDidCv1oNuPGjZODjYbK6NGj5fxdZsIw5HQSLJ0IlYMHD8oRzpkucs48pomMj1yX9176iotG1DHG+MiFJSpc+P6yRJdtDVlixY9HpqVlwfnR+J6Xd+2KwGuHkg4yHWMhxc8//yznD1TpGsPQGAZGP/sKPxVOfE+ZrvEDmiXdl1xySUm6xqYgHIXeDHg9luBT2CmCEkRG2BMs/XA6tu/YgS0io92yeYtM9Hbv2SU8fhTZ2TnuxI43LxZ3GIgA4kp4yBJjQaw1Tqpk9kxhqUbz5i3QuHEjtGvbFp27dEHLli3cIojnusPMdJioUOSZDausoqW9jIqYnGmZs9evWrUKa9eulfP+8Blx4TFMCFTmZDyPcM1MhGv1cvPFbtWqlXyhmdFwzUzITDhpIou6zYQZIqfciDQMX879RQHOGes5TxvDnvspThn2KjHmbyaSDG8uDG+GLcOc/r/gggvkl5Ma/0dB0bFx40bPVuiwhNGMua2MMDPiVBurV6+WflXTbShxpMKCC+FahYNaiBLkamG8ZBjxvWOG065dO1l6xlLtijYG5TxcnI7BTPjMKMbNgNNHcLJRs+HHDMMuVDilCj9mzIYfR2zDYib8SGFcZLq4adMmuc330BgfmRYa46RKG5WQUe8q4yDXKj7yvWVTD9ZqMD4yveTvit4DxQbncTMTlkqVN6l2oHBKkyVLlsj3mr8pihhuDEdj3qJgeHFRIpGltxTi/ABjSZ4KVwXvnWFgFhRc7PyhCFkQ+catXHjjNlsxcvNyxU0Uwl5sg63IJsSRE/EyI01AXHwcaqXUcn/FWb1LfgxeUz89iaAmNIwih2qek8XyC4mTB1J8cP4oLnTjc+SLzWfEDIULxSszHApYNnaj+4mE8f4rE/qDgoiJBwUCMw8KA05MmpeXJ79W+cXEDwYuTEjZjo8ZfEUz92iH98svTH5QqbBgySbjIRNBhgXDi/FQLRSCDBdWz7KkjO3nWA3CtRlxMlriieZYwvFcvG0y7u3cuVOmi3wnmTayhIZxkXGVa57DjxPGQ2N8ZPyj2GFVGOMj00q6VycYZmoeNzXBLdM1LhSZDCemYUzfmK517txZpm3eH3fhQj1v4zMPgyByi6FwED7LGo1Go9FoqhtGQRSGLhbhkyxaDGk0Go1GowkHAfcyU/hzC+Ycou250fZKOVHtRYMfiLbnRtsrJVL2osEPRNtzo+2VUpabIkxtiDQajUaj0WiiG6NQCkOVmUaj0Wg0Gs2JhRZEGo1Go9Foqj1aEGk0Go1Go6n2WFzsjK/RaDQajUZTjdElRBqNRqPRaKo9WhBpNBqNRqOp9mhBpNFoNBqNptqjBZFGo9FoNJpqjxZEGo1Go9Foqj1aEGk0Go1Go6n2aEGk0Wg0Go2m2qMFkUaj0Wg0mmqPFkQajUaj0WiqPVoQaTQajUajqfZoQaTRaDQajabaowWRRqPRaDSaao8WRBqNRqPRaKo9WhBpNBqNRqOp9mhBpNFoNBqNptqjBZFGo9FoNJpqDvD/1G5GtfEt5woAAAAASUVORK5CYII=">
	</div>
	<div class="columns">
		<div class="column-left">
			<div class="adress">Honovia GmbH – Salierstraße 51 – 75177 Pforzheim</div>
			<div class="textcontent">
                <?php
                $billing = $order->get_address('billing');
                echo $billing['first_name'] . ' ' . $billing['last_name'] . '<br />';
                echo $billing['address_1'] . ' ' . $billing['address_2'] . '<br />';
                echo $billing['postcode'] . ' ' . $billing['city'];
                ?>
				<?php
				if ($order->get_billing_country()) {
					$countries = WC()->countries->get_countries();
					$billing_country_name = isset( $countries[ $order->get_billing_country() ] ) ? $countries[ $order->get_billing_country() ] : $order->get_billing_country();
					echo '<br>' . $billing_country_name;
				}
				?>
			</div>
		</div>
		<div class="column-right">
			<strong>Rechnungsdatum:</strong> <?php echo get_post_meta($order_id, 'custom_field_98', true);?><br>
			<strong>Rechnungsnummer:</strong> <?php echo get_post_meta($order_id, 'custom_invoice_id_new', true);?><br>
			Energieberater: Marius Hoheisen<br>
            Bearbeiter: Mandy Pietschmann<br>
			E-Mail: <a href="mailto:info@foerderheld.com">info@foerderheld.com</a><br>
			<p>Zahlbar innerhalb von 14 Tagen ohne Abzug</p>
		</div>
	</div>
    <br />
    <br />
	<h3 style="font-size: 18px;">Rechnung für Ihren individuellen Sanierungsfahrplan (iSFP)</h3>

	<p class="i" style="
    clear: both;
    padding-top: 20px;
">Für unsere Dienstleistung berechnen wir Ihnen wie folgt:</p>

	<table border="1" cellpadding="10" style="width: 100%">
		<tr>
			<th>Pos.</th>
			<th>Bezeichnung</th>
			<th width="140px">Preis</th>
		</tr>
		<?php $index = 1; ?>
		<?php foreach ($order->get_items() as $item): ?>
			<?php if ( $item instanceof WC_Order_Item_Product ): ?>
				<tr>
					<td><?php echo esc_html($index); ?></td>
					<td>
                        <?php echo esc_html($item->get_name()); ?>
                        <?php foreach ($item->get_meta_data() as $meta_datum): ?>
                            <br /><?php echo $meta_datum->key; ?>: <?php echo $meta_datum->value; ?>
                        <?php endforeach; ?>
                    </td>
					<td><?php echo wc_price($item->get_subtotal()); ?></td>
				</tr>
				<?php $index++; ?>
			<?php endif; ?>
		<?php endforeach; ?>
		<?php foreach ($order->get_taxes() as $tax): ?>
			<tr>
				<td><?php echo esc_html($index); ?></td>
				<td>zuzüglich <?php echo $tax->get_rate_percent(); ?>% gesetzliche Mehrwertsteuer</td>
				<td><?php echo wc_price($tax->get_tax_total()); ?></td>
			</tr>
			<?php $index++; ?>
		<?php endforeach; ?>
		<?php foreach( $order->get_items('fee') as $fee ): ?>
        <?php if ($fee->get_total() + $fee->get_total_tax() > 0): ?>
            <tr>
                <td><?php echo esc_html($index); ?></td>
                <td><?php echo esc_html($fee->get_name()); ?></td>
                <td><?php echo wc_price($fee->get_total() + $fee->get_total_tax()); ?></td>
            </tr>
				<?php $index++; ?>
        <?php endif; ?>
		<?php endforeach; ?>

		<tr>
			<td colspan="2">Endbetrag</td>
			<td><?php echo wc_price($order->get_total() + $discount); ?></td>
		</tr>
	</table>
    <?php if ($discount > 0): ?>
        <table border="0" cellpadding="10" style="width: 100%">
            <tr style="border: unset">
                <td style="border: unset" colspan="2">Umlagen und Abzüge auf Gesamtsumme <?php echo wc_price($order->get_total() + $discount); ?><br/>
                    Zuschuss BAFA</td>
                <td style="border: unset; vertical-align: bottom;" width="140px"><?php echo wc_price($discount * -1); ?></td>
            </tr>
            <tr>
                <td colspan="2">Eigenanteil nach Abzug BAFA Zuschuss</td>
                <td><?php echo wc_price($order->get_total()); ?></td>
            </tr>
        </table>
    <?php endif; ?>
    <br />
    <br />
    <div class="border">
		<p>
            Bitte überweisen Sie ihren Eigenanteil von 600€ an das unten genannte Konto. Die Rechnung für die
            Umsetzung ihrer BEG-Einzelmaßnahme erhalten Sie, sobald der Zuwendungsbescheid des BAFA
            eintrifft. <b>Ihre Gesamtkosten für Sanierungsfahrplan und BEG-Einzelmaßnahme belaufen sich
                somit auf 850€.</b><br/>
            Davon entfallen 600€ auf den Sanierungsfahrplan (diese Rechnung) und 250€ auf die BEG
            Einzelmaßnahme.
        </p>
	</div>

	<p>Ihr Team von FörderHeld</p>

</div>

</body>
</html>