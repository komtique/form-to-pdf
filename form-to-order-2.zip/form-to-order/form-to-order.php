<?php
/**
* Plugin Name: Form to Woo Order
* Plugin URI: mailto:viktoryshapran@gmail.com
* Description: Form to Woo Order.
* Version: 0.1
* Author: Viktoriia
* Author URI: mailto:viktoryshapran@gmail.com
**/

require_once plugin_dir_path( __FILE__ ) . 'includes/create_orders.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/order_statuses.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/admin_order_page.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/emails_page.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/emails_send.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/generate_pdfs.php';

function my_plugin_path(){
    return untrailingslashit( plugin_dir_path( __FILE__ ) ); 
}

add_action('admin_footer', 'custom_generate_invoice_js');
function custom_generate_invoice_js() {
    ?>
    <script type="text/javascript">
        jQuery(document).ready(function($) {
			if ($('#order_status').val() === 'wc-bei-bafa' && $("input#festsetzungsbescheid_pdf").val() === '') {
				$('#order_status option[value="wc-abgeschlossen"]').prop('disabled', true);
				$('div#order_data h2').before('<p class="error notice" style="color:red;">Festsetzungsbescheid nicht hochgeladen!</p>');
			}
			if ($('#order_status').val() === 'wc-forderantrag' && $("input#zuwendungsbescheid_pdf").val() === '') {
				$('#order_status option').prop('disabled', true);
				$('#order_status option[value="wc-forderantrag"]').prop('disabled', false);
				$('div#order_data h2').before('<p class="error notice" style="color:red;">Zuwendungsbescheid nicht hochgeladen!</p>');
			}
			
			
			if ($('#order_status').val() === 'wc-ht-bei-bafa' && $("input#festsetzungsbescheid_pdf").val() === '') {
				$('#order_status option[value="wc-ht-abgeschlossen"]').prop('disabled', true);
				$('div#order_data h2').before('<p class="error notice" style="color:red;">Festsetzungsbescheid nicht hochgeladen!</p>');
			}
			if ($('#order_status').val() === 'wc-ht-forderantrag' && $("input#zuwendungsbescheid_pdf").val() === '') {
				$('#order_status option').prop('disabled', true);
				$('#order_status option[value="wc-ht-forderantrag"]').prop('disabled', false);
				$('div#order_data h2').before('<p class="error notice" style="color:red;">Zuwendungsbescheid nicht hochgeladen!</p>');
			}
			
			if ($('#order_status').val() === 'wc-hf-bei-bafa' && $("input#festsetzungsbescheid_pdf").val() === '') {
				$('#order_status option[value="wc-hf-abgeschlossen"]').prop('disabled', true);
				$('div#order_data h2').before('<p class="error notice" style="color:red;">Festsetzungsbescheid nicht hochgeladen!</p>');
			}
			if ($('#order_status').val() === 'wc-hf-forderantrag' && $("input#zuwendungsbescheid_pdf").val() === '') {
				$('#order_status option').prop('disabled', true);
				$('#order_status option[value="wc-hf-forderantrag"]').prop('disabled', false);
				$('div#order_data h2').before('<p class="error notice" style="color:red;">Zuwendungsbescheid nicht hochgeladen!</p>');
			}
			
			if ($('#order_status').val() === 'wc-ut-bei-bafa' && $("input#festsetzungsbescheid_pdf").val() === '') {
				$('#order_status option[value="wc-ut-abgeschlossen"]').prop('disabled', true);
				$('div#order_data h2').before('<p class="error notice" style="color:red;">Festsetzungsbescheid nicht hochgeladen!</p>');
			}
			if ($('#order_status').val() === 'wc-ut-forderantrag' && $("input#zuwendungsbescheid_pdf").val() === '') {
				$('#order_status option').prop('disabled', true);
				$('#order_status option[value="wc-ut-forderantrag"]').prop('disabled', false);
				$('div#order_data h2').before('<p class="error notice" style="color:red;">Zuwendungsbescheid nicht hochgeladen!</p>');
			}
			
			if ($('#order_status').val() === 'wc-uf-bei-bafa' && $("input#festsetzungsbescheid_pdf").val() === '') {
				$('#order_status option[value="wc-uf-abgeschlossen"]').prop('disabled', true);
				$('div#order_data h2').before('<p class="error notice" style="color:red;">Festsetzungsbescheid nicht hochgeladen!</p>');
			}
			if ($('#order_status').val() === 'wc-uf-forderantrag' && $("input#zuwendungsbescheid_pdf").val() === '') {
				$('#order_status option').prop('disabled', true);
				$('#order_status option[value="wc-uf-forderantrag"]').prop('disabled', false);
				$('div#order_data h2').before('<p class="error notice" style="color:red;">Zuwendungsbescheid nicht hochgeladen!</p>');
			}

            const params = new Proxy(new URLSearchParams(window.location.search), {
                get: (searchParams, prop) => searchParams.get(prop),
            });

            const order_status_groups = [
                [
                    'wc-auftrag', 'wc-forderantrag', 'wc-erhalten', 'wc-ausgefuhrt', 'wc-vollstandig', 'wc-bei-bafa',
                    'wc-abgeschlossen',
                ],
                [
                    'wc-ht-auftrag', 'wc-ht-forderantrag', 'wc-ht-erhalten', 'wc-ht-ausgefuhrt', 'wc-ht-vollstandig',
                    'wc-ht-bei-bafa', 'wc-ht-abgeschlossen',
                ],
                [
                    'wc-hf-auftrag', 'wc-hf-forderantrag', 'wc-hf-erhalten', 'wc-hf-ausgefuhrt', 'wc-hf-vollstandig',
                    'wc-hf-bei-bafa', 'wc-hf-abgeschlossen',
                ],
                [
                    'wc-ut-auftrag', 'wc-ut-forderantrag', 'wc-ut-erhalten', 'wc-ut-ausgefuhrt', 'wc-ut-vollstandig',
                    'wc-ut-bei-bafa', 'wc-ut-abgeschlossen',
                ],
                [
                    'wc-uf-auftrag', 'wc-uf-forderantrag', 'wc-uf-erhalten', 'wc-uf-ausgefuhrt', 'wc-uf-vollstandig',
                    'wc-uf-bei-bafa', 'wc-uf-abgeschlossen',
                ],
                [
                    'wc-custom-created', 'wc-custom-paid', 'wc-checkout-draft',
                ]
            ];

            if (params.action !== 'new') {
                const current_order_status = $('[name="order_status"]').val();
                for (const allowed_statuses of order_status_groups) {
                    if (allowed_statuses.includes(current_order_status)) {
                        jQuery('#order_status option').each((key, select) => {
                            const $select = $(select);
                            if (!allowed_statuses.includes($select.val())) {
                                $select.remove();
                            }
                        });
                        break;
                    }
                }
            }

            /*
			if ($('.wc-order-item-name').text() === 'FörderheldStandard'){
				$('#order_status option[value="wc-ht-auftrag"]').remove();
				$('#order_status option[value="wc-ht-forderantrag"]').remove();
				$('#order_status option[value="wc-ht-erhalten"]').remove();
				$('#order_status option[value="wc-ht-ausgefuhrt"]').remove();
				$('#order_status option[value="wc-ht-vollstandig"]').remove();
				$('#order_status option[value="wc-ht-bei-bafa"]').remove();
				$('#order_status option[value="wc-ht-abgeschlossen"]').remove();
				
				$('#order_status option[value="wc-hf-auftrag"]').remove();
				$('#order_status option[value="wc-hf-forderantrag"]').remove();
				$('#order_status option[value="wc-hf-erhalten"]').remove();
				$('#order_status option[value="wc-hf-ausgefuhrt"]').remove();
				$('#order_status option[value="wc-hf-vollstandig"]').remove();
				$('#order_status option[value="wc-hf-bei-bafa"]').remove();
				$('#order_status option[value="wc-hf-abgeschlossen"]').remove();
				
				$('#order_status option[value="wc-ut-auftrag"]').remove();
				$('#order_status option[value="wc-ut-forderantrag"]').remove();
				$('#order_status option[value="wc-ut-erhalten"]').remove();
				$('#order_status option[value="wc-ut-ausgefuhrt"]').remove();
				$('#order_status option[value="wc-ut-vollstandig"]').remove();
				$('#order_status option[value="wc-ut-bei-bafa"]').remove();
				$('#order_status option[value="wc-ut-abgeschlossen"]').remove();
				
				$('#order_status option[value="wc-uf-auftrag"]').remove();
				$('#order_status option[value="wc-uf-forderantrag"]').remove();
				$('#order_status option[value="wc-uf-erhalten"]').remove();
				$('#order_status option[value="wc-uf-ausgefuhrt"]').remove();
				$('#order_status option[value="wc-uf-vollstandig"]').remove();
				$('#order_status option[value="wc-uf-bei-bafa"]').remove();
				$('#order_status option[value="wc-uf-abgeschlossen"]').remove();
			}

			if ($('.wc-order-item-name').text() === 'HBI 15 % - Einzelförderung (BEG)'){
				$('#order_status option[value="wc-ht-auftrag"]').remove();
				$('#order_status option[value="wc-ht-forderantrag"]').remove();
				$('#order_status option[value="wc-ht-erhalten"]').remove();
				$('#order_status option[value="wc-ht-ausgefuhrt"]').remove();
				$('#order_status option[value="wc-ht-vollstandig"]').remove();
				$('#order_status option[value="wc-ht-bei-bafa"]').remove();
				$('#order_status option[value="wc-ht-abgeschlossen"]').remove();
				
				$('#order_status option[value="wc-auftrag"]').remove();
				$('#order_status option[value="wc-forderantrag"]').remove();
				$('#order_status option[value="wc-erhalten"]').remove();
				$('#order_status option[value="wc-ausgefuhrt"]').remove();
				$('#order_status option[value="wc-vollstandig"]').remove();
				$('#order_status option[value="wc-bei-bafa"]').remove();
				$('#order_status option[value="wc-abgeschlossen"]').remove();
				
				$('#order_status option[value="wc-ut-auftrag"]').remove();
				$('#order_status option[value="wc-ut-forderantrag"]').remove();
				$('#order_status option[value="wc-ut-erhalten"]').remove();
				$('#order_status option[value="wc-ut-ausgefuhrt"]').remove();
				$('#order_status option[value="wc-ut-vollstandig"]').remove();
				$('#order_status option[value="wc-ut-bei-bafa"]').remove();
				$('#order_status option[value="wc-ut-abgeschlossen"]').remove();
				
				$('#order_status option[value="wc-uf-auftrag"]').remove();
				$('#order_status option[value="wc-uf-forderantrag"]').remove();
				$('#order_status option[value="wc-uf-erhalten"]').remove();
				$('#order_status option[value="wc-uf-ausgefuhrt"]').remove();
				$('#order_status option[value="wc-uf-vollstandig"]').remove();
				$('#order_status option[value="wc-uf-bei-bafa"]').remove();
				$('#order_status option[value="wc-uf-abgeschlossen"]').remove();
			}
			
			if ($('.wc-order-item-name').text() === 'HBI 20 % – Förderung (BEG & iSFP)'){
				$('#order_status option[value="wc-hf-auftrag"]').remove();
				$('#order_status option[value="wc-hf-forderantrag"]').remove();
				$('#order_status option[value="wc-hf-erhalten"]').remove();
				$('#order_status option[value="wc-hf-ausgefuhrt"]').remove();
				$('#order_status option[value="wc-hf-vollstandig"]').remove();
				$('#order_status option[value="wc-hf-bei-bafa"]').remove();
				$('#order_status option[value="wc-hf-abgeschlossen"]').remove();
				
				$('#order_status option[value="wc-auftrag"]').remove();
				$('#order_status option[value="wc-forderantrag"]').remove();
				$('#order_status option[value="wc-erhalten"]').remove();
				$('#order_status option[value="wc-ausgefuhrt"]').remove();
				$('#order_status option[value="wc-vollstandig"]').remove();
				$('#order_status option[value="wc-bei-bafa"]').remove();
				$('#order_status option[value="wc-abgeschlossen"]').remove();
				
				$('#order_status option[value="wc-ut-auftrag"]').remove();
				$('#order_status option[value="wc-ut-forderantrag"]').remove();
				$('#order_status option[value="wc-ut-erhalten"]').remove();
				$('#order_status option[value="wc-ut-ausgefuhrt"]').remove();
				$('#order_status option[value="wc-ut-vollstandig"]').remove();
				$('#order_status option[value="wc-ut-bei-bafa"]').remove();
				$('#order_status option[value="wc-ut-abgeschlossen"]').remove();
				
				$('#order_status option[value="wc-uf-auftrag"]').remove();
				$('#order_status option[value="wc-uf-forderantrag"]').remove();
				$('#order_status option[value="wc-uf-erhalten"]').remove();
				$('#order_status option[value="wc-uf-ausgefuhrt"]').remove();
				$('#order_status option[value="wc-uf-vollstandig"]').remove();
				$('#order_status option[value="wc-uf-bei-bafa"]').remove();
				$('#order_status option[value="wc-uf-abgeschlossen"]').remove();
			}
			
			if ($('.wc-order-item-name').text() === 'UNILUX 15 % - Einzelförderung (BEG)'){
				
				$('#order_status option[value="wc-hf-auftrag"]').remove();
				$('#order_status option[value="wc-hf-forderantrag"]').remove();
				$('#order_status option[value="wc-hf-erhalten"]').remove();
				$('#order_status option[value="wc-hf-ausgefuhrt"]').remove();
				$('#order_status option[value="wc-hf-vollstandig"]').remove();
				$('#order_status option[value="wc-hf-bei-bafa"]').remove();
				$('#order_status option[value="wc-hf-abgeschlossen"]').remove();
				
				$('#order_status option[value="wc-ht-auftrag"]').remove();
				$('#order_status option[value="wc-ht-forderantrag"]').remove();
				$('#order_status option[value="wc-ht-erhalten"]').remove();
				$('#order_status option[value="wc-ht-ausgefuhrt"]').remove();
				$('#order_status option[value="wc-ht-vollstandig"]').remove();
				$('#order_status option[value="wc-ht-bei-bafa"]').remove();
				$('#order_status option[value="wc-ht-abgeschlossen"]').remove();
				
				$('#order_status option[value="wc-auftrag"]').remove();
				$('#order_status option[value="wc-forderantrag"]').remove();
				$('#order_status option[value="wc-erhalten"]').remove();
				$('#order_status option[value="wc-ausgefuhrt"]').remove();
				$('#order_status option[value="wc-vollstandig"]').remove();
				$('#order_status option[value="wc-bei-bafa"]').remove();
				$('#order_status option[value="wc-abgeschlossen"]').remove();
				
				$('#order_status option[value="wc-ut-auftrag"]').remove();
				$('#order_status option[value="wc-ut-forderantrag"]').remove();
				$('#order_status option[value="wc-ut-erhalten"]').remove();
				$('#order_status option[value="wc-ut-ausgefuhrt"]').remove();
				$('#order_status option[value="wc-ut-vollstandig"]').remove();
				$('#order_status option[value="wc-ut-bei-bafa"]').remove();
				$('#order_status option[value="wc-ut-abgeschlossen"]').remove();
			}
			
			if ($('.wc-order-item-name').text() === 'UNILUX 20 % – Förderung (BEG & iSFP)'){
				$('#order_status option[value="wc-hf-auftrag"]').remove();
				$('#order_status option[value="wc-hf-forderantrag"]').remove();
				$('#order_status option[value="wc-hf-erhalten"]').remove();
				$('#order_status option[value="wc-hf-ausgefuhrt"]').remove();
				$('#order_status option[value="wc-hf-vollstandig"]').remove();
				$('#order_status option[value="wc-hf-bei-bafa"]').remove();
				$('#order_status option[value="wc-hf-abgeschlossen"]').remove();
				
				$('#order_status option[value="wc-ht-auftrag"]').remove();
				$('#order_status option[value="wc-ht-forderantrag"]').remove();
				$('#order_status option[value="wc-ht-erhalten"]').remove();
				$('#order_status option[value="wc-ht-ausgefuhrt"]').remove();
				$('#order_status option[value="wc-ht-vollstandig"]').remove();
				$('#order_status option[value="wc-ht-bei-bafa"]').remove();
				$('#order_status option[value="wc-ht-abgeschlossen"]').remove();
				
				$('#order_status option[value="wc-auftrag"]').remove();
				$('#order_status option[value="wc-forderantrag"]').remove();
				$('#order_status option[value="wc-erhalten"]').remove();
				$('#order_status option[value="wc-ausgefuhrt"]').remove();
				$('#order_status option[value="wc-vollstandig"]').remove();
				$('#order_status option[value="wc-bei-bafa"]').remove();
				$('#order_status option[value="wc-abgeschlossen"]').remove();
				
				$('#order_status option[value="wc-uf-auftrag"]').remove();
				$('#order_status option[value="wc-uf-forderantrag"]').remove();
				$('#order_status option[value="wc-uf-erhalten"]').remove();
				$('#order_status option[value="wc-uf-ausgefuhrt"]').remove();
				$('#order_status option[value="wc-uf-vollstandig"]').remove();
				$('#order_status option[value="wc-uf-bei-bafa"]').remove();
				$('#order_status option[value="wc-uf-abgeschlossen"]').remove();
			}
			*/
            $('#generate_invoice_button').on('click', function() {
                var order_id = $(this).data('order-id');

                // Make an AJAX request to generate the invoice
                $.ajax({
                    url: ajaxurl, // AJAX handler in WordPress admin
                    method: 'POST',
                    data: {
                        action: 'generate_invoice',
                        order_id: order_id
                    },
                    beforeSend: function() {
                        // Optionally show a loading spinner or message
                        $('#generate_invoice_button').text('Generating...').prop('disabled', true);
                    },
                    success: function(response) {
                        if (response.success) {
                            // Update the page with the new invoice link
                            $('#generate_invoice_button').replaceWith('<a href="' + response.data.invoice_url + '" target="_blank" id="_invoice_pdf" style="display:block;margin-top:10px;">View PDF</a>');
                        } else {
                            alert('Error: ' + response.data);
                        }
                    },
                    error: function() {
                        alert('AJAX error: Unable to generate the invoice.');
                    },
                    complete: function() {
                        $('#generate_invoice_button').text('Generate Invoice').prop('disabled', false);
                    }
                });
            });
        });
    </script>
    <?php
}


add_action('admin_enqueue_scripts', 'custom_enqueue_media_uploader');
function custom_enqueue_media_uploader($hook) {
    global $post;
        wp_enqueue_media(); 
        wp_enqueue_script('media-uploader-script', plugin_dir_url(__FILE__) .'js/media-uploader.js?v=7998996', array('jquery'), null, true);
}


add_filter( 'woocommerce_order_number', 'wc_set_order_number', 10, 2 );
function wc_set_order_number( $order_id, $order ) {
    $order_number = $order->get_meta('_custom_field_146_new');
    return empty($order_number) ? $order_id : $order_number;
}


add_action( 'admin_menu', 'custom_order_number_admin_menu' );

function custom_order_number_admin_menu() {
    add_menu_page(
        'Invoice Number Settings',
        'Invoice Number Settings',
        'manage_options',
        'order-number-settings',
        'render_order_number_settings_page',
        'dashicons-admin-generic',
        56
    );
}

function render_order_number_settings_page() {
    $prefix = get_option( 'custom_order_number_prefix', '' );
    $next = get_option( 'custom_order_number_counter', 1 );
	$next_uni = get_option( 'custom_counter_uni', 1 );
	$next_fn = get_option( 'custom_counter_fn', 1 );
	$next_hbi = get_option( 'custom_counter_hbi', 1 );

    ?>
    <div class="wrap">
        <h1>Order Number Settings</h1>
        <form method="post" action="">
            <?php wp_nonce_field( 'update_order_number_settings' ); ?>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="order_prefix">Invoice Prefix</label>
                    </th>
                    <td>
                        <input type="text" name="order_prefix" id="order_prefix" value="<?php echo esc_attr( $prefix ); ?>" />
                        <p class="description">Set the prefix for custom order numbers (e.g., "24-" or "xyz-").</p>
                    </td>
                </tr>
				<tr>
                    <th scope="row">
                        <label for="order_prefix">Next Order Invoice Number</label>
                    </th>
                    <td>
                        <input type="text" name="next_order_number" id="next_order_number" value="<?php echo esc_attr( $next ); ?>" />
                        <p class="description">Only numbers</p>
                    </td>
                </tr>
				
				
				<tr>
                    <th scope="row">
                        <label for="order_prefix">Next FH- Number</label>
                    </th>
                    <td>
                        <input type="text" name="next_fn_number" id="next_fn_number" value="<?php echo esc_attr( $next_fn ); ?>" />
                        <p class="description">Only numbers</p>
                    </td>
                </tr>
				
				<tr>
                    <th scope="row">
                        <label for="order_prefix">Next UNI- Number</label>
                    </th>
                    <td>
                        <input type="text" name="next_uni_number" id="next_uni_number" value="<?php echo esc_attr( $next_uni ); ?>" />
                        <p class="description">Only numbers</p>
                    </td>
                </tr>
				
				<tr>
                    <th scope="row">
                        <label for="order_prefix">Next HBI- Number</label>
                    </th>
                    <td>
                        <input type="text" name="next_hbi_number" id="next_hbi_number" value="<?php echo esc_attr( $next_hbi ); ?>" />
                        <p class="description">Only numbers</p>
                    </td>
                </tr>
            </table>
            <button type="submit" name="save_order_settings" class="button-primary">Save Settings</button>
        </form>
    </div>
    <?php
    // Handle form submissions
    handle_order_number_settings_submission();
}

function handle_order_number_settings_submission() {
    if ( ! isset( $_POST['save_order_settings'] ) && ! isset( $_POST['reset_order_counter'] ) ) {
        return;
    }

    // Verify nonce
    if ( ! wp_verify_nonce( $_POST['_wpnonce'], 'update_order_number_settings' ) ) {
        return;
    }

    if ( isset( $_POST['save_order_settings'] ) ) {
        // Save the new prefix
        $prefix = sanitize_text_field( $_POST['order_prefix'] );
        update_option( 'custom_order_number_prefix', $prefix );
		
        $next = sanitize_text_field( $_POST['next_order_number'] );
        update_option( 'custom_order_number_counter', $next );
		
		$hbi = sanitize_text_field( $_POST['next_hbi_number'] );
        update_option( 'custom_counter_hbi', $hbi );
		
		$fb = sanitize_text_field( $_POST['next_fn_number'] );
        update_option( 'custom_counter_fn', $fb );
		
		$uni = sanitize_text_field( $_POST['next_uni_number'] );
        update_option( 'custom_counter_uni', $uni );
    }

    // Refresh the page to apply changes
    wp_redirect( admin_url( 'admin.php?page=order-number-settings' ) );
    exit;
}
