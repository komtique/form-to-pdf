<?php

function custom_register_order_statuses() {
    $statuses = array(
        'wc-auftrag'         => 'FH - Auftrag eingegangen',
        'wc-forderantrag'     => 'FH - Förderantrag in Prüfung',
        'wc-erhalten' => 'FH - Zuwendungsbescheid erhalten',
        'wc-ausgefuhrt'     => 'FH - Montage wird ausgeführt',
        'wc-vollstandig'      => 'FH - Unterlagen vollständig',
        'wc-bei-bafa'         => 'FH - Unterlagen bei Bafa',
        'wc-abgeschlossen'       => 'FH - Auftrag abgeschlossen',
		'wc-ht-auftrag'         => 'HBI 20 - Auftrag eingegangen',
        'wc-ht-forderantrag'     => 'HBI 20 - Förderantrag in Prüfung',
        'wc-ht-erhalten' => 'HBI 20 - Zuwendungsbescheid erhalten',
        'wc-ht-ausgefuhrt'     => 'HBI 20 - Montage wird ausgeführt',
        'wc-ht-vollstandig'      => 'HBI 20 - Unterlagen vollständig',
        'wc-ht-bei-bafa'         => 'HBI 20 - Unterlagen bei Bafa',
        'wc-ht-abgeschlossen'       => 'HBI 20 - Auftrag abgeschlossen',
		'wc-hf-auftrag'         => 'HBI 15 - Auftrag eingegangen',
        'wc-hf-forderantrag'     => 'HBI 15 - Förderantrag in Prüfung',
        'wc-hf-erhalten' => 'HBI 15 - Zuwendungsbescheid erhalten',
        'wc-hf-ausgefuhrt'     => 'HBI 15 - Montage wird ausgeführt',
        'wc-hf-vollstandig'      => 'HBI 15 - Unterlagen vollständig',
        'wc-hf-bei-bafa'         => 'HBI 15 - Unterlagen bei Bafa',
        'wc-hf-abgeschlossen'       => 'HBI 15 - Auftrag abgeschlossen',
		'wc-ut-auftrag'         => 'UNILUX 20 - Auftrag eingegangen',
        'wc-ut-forderantrag'     => 'UNILUX 20 - Förderantrag in Prüfung',
        'wc-ut-erhalten' => 'UNILUX 20 - Zuwendungsbescheid erhalten',
        'wc-ut-ausgefuhrt'     => 'UNILUX 20 - Montage wird ausgeführt',
        'wc-ut-vollstandig'      => 'UNILUX 20 - Unterlagen vollständig',
        'wc-ut-bei-bafa'         => 'UNILUX 20 - Unterlagen bei Bafa',
        'wc-ut-abgeschlossen'       => 'UNILUX 20 - Auftrag abgeschlossen',
		'wc-uf-auftrag'         => 'UNILUX 15 - Auftrag eingegangen',
        'wc-uf-forderantrag'     => 'UNILUX 15 - Förderantrag in Prüfung',
        'wc-uf-erhalten' => 'UNILUX 15 - Zuwendungsbescheid erhalten',
        'wc-uf-ausgefuhrt'     => 'UNILUX 15 - Montage wird ausgeführt',
        'wc-uf-vollstandig'      => 'UNILUX 15 - Unterlagen vollständig',
        'wc-uf-bei-bafa'         => 'UNILUX 15 - Unterlagen bei Bafa',
        'wc-uf-abgeschlossen'       => 'UNILUX 15 - Auftrag abgeschlossen',
	    'wc-custom-created' => 'Erstellt',
	    'wc-custom-paid' => 'Bezahlt',
    );

    foreach ( $statuses as $status => $label ) {
        register_post_status( $status, array(
            'label'                     => $label,
            'public'                    => true,
            'show_in_admin_status_list'  => true,
            'label_count'               => _n_noop( "$label (%s)", "$label (%s)" ),
        ) );
    }
}


add_action( 'init', 'custom_register_order_statuses' );

add_filter( 'wc_order_statuses', 'custom_add_status_to_list' );

function custom_add_status_to_list( $order_statuses ) {
    $new_statuses = array(
        'wc-auftrag'         => 'FH - Auftrag eingegangen',
        'wc-forderantrag'     => 'FH - Förderantrag in Prüfung',
        'wc-erhalten' => 'FH - Zuwendungsbescheid erhalten',
        'wc-ausgefuhrt'     => 'FH - Montage wird ausgeführt',
        'wc-vollstandig'      => 'FH - Unterlagen vollständig',
        'wc-bei-bafa'         => 'FH - Unterlagen bei Bafa',
        'wc-abgeschlossen'       => 'FH - Auftrag abgeschlossen',
		'wc-ht-auftrag'         => 'HBI 20 - Auftrag eingegangen',
        'wc-ht-forderantrag'     => 'HBI 20 - Förderantrag in Prüfung',
        'wc-ht-erhalten' => 'HBI 20 - Zuwendungsbescheid erhalten',
        'wc-ht-ausgefuhrt'     => 'HBI 20 - Montage wird ausgeführt',
        'wc-ht-vollstandig'      => 'HBI 20 - Unterlagen vollständig',
        'wc-ht-bei-bafa'         => 'HBI 20 - Unterlagen bei Bafa',
        'wc-ht-abgeschlossen'       => 'HBI 20 - Auftrag abgeschlossen',
		'wc-hf-auftrag'         => 'HBI 15 - Auftrag eingegangen',
        'wc-hf-forderantrag'     => 'HBI 15 - Förderantrag in Prüfung',
        'wc-hf-erhalten' => 'HBI 15 - Zuwendungsbescheid erhalten',
        'wc-hf-ausgefuhrt'     => 'HBI 15 - Montage wird ausgeführt',
        'wc-hf-vollstandig'      => 'HBI 15 - Unterlagen vollständig',
        'wc-hf-bei-bafa'         => 'HBI 15 - Unterlagen bei Bafa',
        'wc-hf-abgeschlossen'       => 'HBI 15 - Auftrag abgeschlossen',
		'wc-ut-auftrag'         => 'UNILUX 20 - Auftrag eingegangen',
        'wc-ut-forderantrag'     => 'UNILUX 20 - Förderantrag in Prüfung',
        'wc-ut-erhalten' => 'UNILUX 20 - Zuwendungsbescheid erhalten',
        'wc-ut-ausgefuhrt'     => 'UNILUX 20 - Montage wird ausgeführt',
        'wc-ut-vollstandig'      => 'UNILUX 20 - Unterlagen vollständig',
        'wc-ut-bei-bafa'         => 'UNILUX 20 - Unterlagen bei Bafa',
        'wc-ut-abgeschlossen'       => 'UNILUX 20 - Auftrag abgeschlossen',
		'wc-uf-auftrag'         => 'UNILUX 15 - Auftrag eingegangen',
        'wc-uf-forderantrag'     => 'UNILUX 15 - Förderantrag in Prüfung',
        'wc-uf-erhalten' => 'UNILUX 15 - Zuwendungsbescheid erhalten',
        'wc-uf-ausgefuhrt'     => 'UNILUX 15 - Montage wird ausgeführt',
        'wc-uf-vollstandig'      => 'UNILUX 15 - Unterlagen vollständig',
        'wc-uf-bei-bafa'         => 'UNILUX 15 - Unterlagen bei Bafa',
        'wc-uf-abgeschlossen'       => 'UNILUX 15 - Auftrag abgeschlossen',
        'wc-custom-created' => 'Erstellt',
        'wc-custom-paid' => 'Bezahlt',
    );
    return $new_statuses;
}

add_filter( 'bulk_actions-woocommerce_page_wc-orders', 'custom_register_bulk_actions' );

function custom_register_bulk_actions( $bulk_actions ) {
	unset( $bulk_actions['mark_processing'] );
	unset( $bulk_actions['mark_on-hold'] );
	unset( $bulk_actions['mark_completed'] );
	unset( $bulk_actions['mark_cancelled'] );
    $bulk_actions['mark_auftrag'] = 'FH - Auftrag eingegangen setzen';
    $bulk_actions['mark_forderantrag'] = 'FH - Förderantrag in Prüfung setzen';
    $bulk_actions['mark_erhalten'] = 'FH - Zuwendungsbescheid erhalten setzen';
    $bulk_actions['mark_ausgefuhrt'] = 'FH - Montage wird ausgeführt setzen';
    $bulk_actions['mark_vollstandig'] = 'FH - Unterlagen vollständig setzen';
    $bulk_actions['mark_bei-bafa'] = 'FH - Unterlagen bei Bafa setzen';
    $bulk_actions['mark_abgeschlossen'] = 'FH - Auftrag abgeschlossen setzen';
	
	$bulk_actions['mark_uni_f_auftrag'] = 'UNILUX 15 - Auftrag eingegangen setzen';
    $bulk_actions['mark_uni_f_forderantrag'] = 'UNILUX 15 - Förderantrag in Prüfung setzen';
    $bulk_actions['mark_uni_f_erhalten'] = 'UNILUX 15 - Zuwendungsbescheid erhalten setzen';
    $bulk_actions['mark_uni_f_ausgefuhrt'] = 'UNILUX 15 - Montage wird ausgeführt setzen';
    $bulk_actions['mark_uni_f_vollstandig'] = 'UNILUX 15 - Unterlagen vollständig setzen';
    $bulk_actions['mark_uni_f_bei-bafa'] = 'UNILUX 15 - Unterlagen bei Bafa setzen';
    $bulk_actions['mark_uni_f_abgeschlossen'] = 'UNILUX 15 - Auftrag abgeschlossen setzen';
	
	$bulk_actions['mark_uni_t_auftrag'] = 'UNILUX 20 - Auftrag eingegangen setzen';
    $bulk_actions['mark_uni_t_forderantrag'] = 'UNILUX 20 - Förderantrag in Prüfung setzen';
    $bulk_actions['mark_uni_t_erhalten'] = 'UNILUX 20 - Zuwendungsbescheid erhalten setzen';
    $bulk_actions['mark_uni_t_ausgefuhrt'] = 'UNILUX 20 - Montage wird ausgeführt setzen';
    $bulk_actions['mark_uni_t_vollstandig'] = 'UNILUX 20 - Unterlagen vollständig setzen';
    $bulk_actions['mark_uni_t_bei-bafa'] = 'UNILUX 20 - Unterlagen bei Bafa setzen';
    $bulk_actions['mark_uni_t_abgeschlossen'] = 'UNILUX 20 - Auftrag abgeschlossen setzen';

	$bulk_actions['mark_hbi_f_auftrag'] = 'HBI 15 - Auftrag eingegangen setzen';
    $bulk_actions['mark_hbi_f_forderantrag'] = 'HBI 15 - Förderantrag in Prüfung setzen';
    $bulk_actions['mark_hbi_f_erhalten'] = 'HBI 15 - Zuwendungsbescheid erhalten setzen';
    $bulk_actions['mark_hbi_f_ausgefuhrt'] = 'HBI 15 - Montage wird ausgeführt setzen';
    $bulk_actions['mark_hbi_f_vollstandig'] = 'HBI 15 - Unterlagen vollständig setzen';
    $bulk_actions['mark_hbi_f_bei-bafa'] = 'HBI 15 - Unterlagen bei Bafa setzen';
    $bulk_actions['mark_hbi_f_abgeschlossen'] = 'HBI 15 - Auftrag abgeschlossen setzen';
	
	$bulk_actions['mark_hbi_t_auftrag'] = 'HBI 20 - Auftrag eingegangen setzen';
    $bulk_actions['mark_hbi_t_forderantrag'] = 'HBI 20 - Förderantrag in Prüfung setzen';
    $bulk_actions['mark_hbi_t_erhalten'] = 'HBI 20 - Zuwendungsbescheid erhalten setzen';
    $bulk_actions['mark_hbi_t_ausgefuhrt'] = 'HBI 20 - Montage wird ausgeführt setzen';
    $bulk_actions['mark_hbi_t_vollstandig'] = 'HBI 20 - Unterlagen vollständig setzen';
    $bulk_actions['mark_hbi_t_bei-bafa'] = 'HBI 20 - Unterlagen bei Bafa setzen';
    $bulk_actions['mark_hbi_t_abgeschlossen'] = 'HBI 20 - Auftrag abgeschlossen setzen';
	$bulk_actions['mark_custom_created'] = 'Erstellt';
	$bulk_actions['mark_custom_paid'] = 'Bezahlt';
    return $bulk_actions;
}

add_action( 'handle_bulk_actions-edit-shop_order', 'custom_process_bulk_action', 20, 3 );

function custom_process_bulk_action( $redirect_to, $doaction, $post_ids ) {
    $custom_actions = array(
        'mark_auftrag'         => 'wc-auftrag',
        'mark_forderantrag'     => 'wc-forderantrag',
        'mark_erhalten' => 'wc-erhalten',
        'mark_ausgefuhrt'     => 'wc-ausgefuhrt',
        'mark_vollstandig'      => 'wc-vollstandig',
        'mark_bei-bafa'         => 'wc-bei-bafa',
        'mark_abgeschlossen'       => 'wc-abgeschlossen',
		
		'mark_hbi_t_auftrag'         => 'wc-ht-auftrag',
        'mark_hbi_t_forderantrag'     => 'wc-ht-forderantrag',
        'mark_hbi_t_erhalten' => 'wc-ht-erhalten',
        'mark_hbi_t_ausgefuhrt'     => 'wc-ht-ausgefuhrt',
        'mark_hbi_t_vollstandig'      => 'wc-ht-vollstandig',
        'mark_hbi_t_bei-bafa'         => 'wc-ht-bei-bafa',
        'mark_hbi_t_abgeschlossen'       => 'wc-ht-abgeschlossen',
		
		'mark_hbi_f_auftrag'         => 'wc-hf-auftrag',
        'mark_hbi_f_forderantrag'     => 'wc-hf-forderantrag',
        'mark_hbi_f_erhalten' => 'wc-hf-erhalten',
        'mark_hbi_f_ausgefuhrt'     => 'wc-hf-ausgefuhrt',
        'mark_hbi_f_vollstandig'      => 'wc-hf-vollstandig',
        'mark_hbi_f_bei-bafa'         => 'wc-hf-bei-bafa',
        'mark_hbi_f_abgeschlossen'       => 'wc-hf-abgeschlossen',
		
		
		'mark_uni_t_auftrag'         => 'wc-ht-auftrag',
        'mark_uni_t_forderantrag'     => 'wc-ht-forderantrag',
        'mark_uni_t_erhalten' => 'wc-ht-erhalten',
        'mark_uni_t_ausgefuhrt'     => 'wc-ht-ausgefuhrt',
        'mark_uni_t_vollstandig'      => 'wc-ht-vollstandig',
        'mark_uni_t_bei-bafa'         => 'wc-ht-bei-bafa',
        'mark_uni_t_abgeschlossen'       => 'wc-ht-abgeschlossen',
		
		'mark_uni_f_auftrag'         => 'wc-uf-auftrag',
        'mark_uni_f_forderantrag'     => 'wc-uf-forderantrag',
        'mark_uni_f_erhalten' => 'wc-uf-erhalten',
        'mark_uni_f_ausgefuhrt'     => 'wc-uf-ausgefuhrt',
        'mark_uni_f_vollstandig'      => 'wc-uf-vollstandig',
        'mark_uni_f_bei-bafa'         => 'wc-uf-bei-bafa',
        'mark_uni_f_abgeschlossen'       => 'wc-uf-abgeschlossen',

	    'mark_custom_created' => 'wc-custom-created',
	    'mark_custom_paid' => 'wc-custom-paid'
    );

    if ( isset( $custom_actions[$doaction] ) ) {
        foreach ( $post_ids as $post_id ) {
            $order = wc_get_order( $post_id );
            $order->update_status( $custom_actions[$doaction] );
        }
        $redirect_to = add_query_arg( 'marked_custom_status', count( $post_ids ), $redirect_to );
    }

    return $redirect_to;
}

add_action( 'admin_notices', 'custom_bulk_action_notice' );

function custom_bulk_action_notice() {
    if ( isset( $_REQUEST['marked_custom_status'] ) ) {
        $count = intval( $_REQUEST['marked_custom_status'] );
        printf( '<div class="updated notice is-dismissible"><p>%s Bestellungen wurden geändert.</p></div>', $count );
    }
}



add_filter( 'woocommerce_order_is_paid_statuses', 'bbloomer_paid_is_paid_status' );

function bbloomer_paid_is_paid_status( $statuses ) {
    $statuses[] = 'wc-ausgefuhrt';
	$statuses[] = 'wc-vollstandig';
	$statuses[] = 'wc-bei-bafa';
	$statuses[] = 'wc-abgeschlossen';
	$statuses[] = 'ausgefuhrt';
	$statuses[] = 'vollstandig';
	$statuses[] = 'bei-bafa';
	$statuses[] = 'abgeschlossen';
	
	$statuses[] = 'hf-ausgefuhrt';
	$statuses[] = 'hf-vollstandig';
	$statuses[] = 'hf-bei-bafa';
	$statuses[] = 'hf-abgeschlossen';
	
	$statuses[] = 'ht-ausgefuhrt';
	$statuses[] = 'ht-vollstandig';
	$statuses[] = 'ht-bei-bafa';
	$statuses[] = 'ht-abgeschlossen';
	
	$statuses[] = 'uf-ausgefuhrt';
	$statuses[] = 'uf-vollstandig';
	$statuses[] = 'uf-bei-bafa';
	$statuses[] = 'uf-abgeschlossen';
	
	$statuses[] = 'ut-ausgefuhrt';
	$statuses[] = 'ut-vollstandig';
	$statuses[] = 'ut-bei-bafa';
	$statuses[] = 'ut-abgeschlossen';
	$statuses[] = 'wc-custom-paid';
   return $statuses;
}


function wc_reports_get_order_custom_report_data_args( $args ) {
    $args['order_status'] = array( 'abgeschlossen', 'bei-bafa', 'ausgefuhrt', 'vollstandig', 'ht-abgeschlossen', 'ht-bei-bafa', 'ht-ausgefuhrt', 'ht-vollstandig', 'hf-abgeschlossen', 'hf-bei-bafa', 'hf-ausgefuhrt', 'hf-vollstandig', 'ut-abgeschlossen', 'ut-bei-bafa', 'ut-ausgefuhrt', 'ut-vollstandig', 'uf-abgeschlossen', 'uf-bei-bafa', 'uf-ausgefuhrt', 'uf-vollstandig' );
    return $args;
};
add_filter( 'woocommerce_reports_get_order_report_data_args', 'wc_reports_get_order_custom_report_data_args');


add_filter( 'wc_order_is_editable', 'bbloomer_custom_order_status_editable', 9999, 2 );

function bbloomer_custom_order_status_editable( $allow_edit, $order ) {

	$statuses = [
		'erhalten',
		'ausgefuhrt',
		'vollstandig',
		'bei-bafa',
		'abgeschlossen',
		
		'uf-erhalten',
		'uf-ausgefuhrt',
		'uf-vollstandig',
		'uf-bei-bafa',
		'uf-abgeschlossen',
		
		'ut-erhalten',
		'ut-ausgefuhrt',
		'ut-vollstandig',
		'ut-bei-bafa',
		'ut-abgeschlossen',
		
		'hf-erhalten',
		'hf-ausgefuhrt',
		'hf-vollstandig',
		'hf-bei-bafa',
		'hf-abgeschlossen',
		
		'ht-erhalten',
		'ht-ausgefuhrt',
		'ht-vollstandig',
		'ht-bei-bafa',
		'ht-abgeschlossen'
	];

	if ( in_array( $order->get_status(), $statuses ) ) {
		$boolean = false;
	} else {
		$boolean = true;
	}

	return $boolean;
}

add_action( 'woocommerce_order_status_changed', function ($id, $status_transition_from, $status_transition_to, $that) {
	$statuses = [
		'wc-erhalten', 'wc-ht-erhalten', 'wc-hf-erhalten', 'wc-ut-erhalten', 'wc-uf-erhalten',
	];
	if (in_array($status_transition_to, $statuses) && empty(get_post_meta($id, 'custom_invoice_id_new', true))) {
		$prefix = get_option( 'custom_order_number_prefix', '' );
		$counter = get_option( 'custom_order_number_counter', 1 );
		$custom_order_number = $prefix . sprintf( '%05d', $counter );
		update_option( 'custom_order_number_counter', $counter + 1 );

		update_post_meta($id, 'custom_invoice_id_new', $custom_order_number);
		update_post_meta($id, 'custom_field_98', date('d/m/Y'));
	}
}, 10, 4 );
