<?php
use Automattic\WooCommerce\Internal\DataStores\Orders\CustomOrdersTableController;

add_action('add_meta_boxes', 'add_custom_order_metabox');

function add_custom_order_metabox() {
	$screen = class_exists( '\Automattic\WooCommerce\Internal\DataStores\Orders\CustomOrdersTableController' ) && wc_get_container()->get( CustomOrdersTableController::class )->custom_orders_table_usage_is_enabled()
        ? wc_get_page_screen_id( 'shop-order' )
        : 'shop_order';

	 add_meta_box(
        'custom-order-metabox',
        __('Antragsdetails', 'your-textdomain'),
        'display_antragsdetails_order_meta',
        $screen,
        'normal',
        'default'
    );
}


add_action('wpforms_process_complete', 'create_wc_order_from_wpforms', 10, 4);

add_action( 'woocommerce_admin_order_data_after_billing_address', 'add_admin_order_editable_billing_date' );
function add_admin_order_editable_billing_date( $order ){
    $billing_date    = get_post_meta( $order->get_id(), 'custom_field_162', true );

    printf('<div class="address"><p%s><strong>%s:</strong> %s</p></div>
        <div class="edit_address">', 
        !$billing_date ? ' class="none_set"' : '',
        __('Date of Birth', 'woocommerce'),
        $billing_date ? $billing_date : __('Not set.', 'woocommerce') 
    );

    woocommerce_wp_text_input( array(
        'id'            => 'custom_field_162',
        'label'         => 'Date of Birth',
        'wrapper_class' => 'form-field-wide',
        'class'         => 'text',
        'style'         => 'width:100%',
        'value'         => $billing_date,
    ) );

    echo '</div>';
}

add_action( 'woocommerce_process_shop_order_meta', 'save_admin_order_billing_date' );
function save_admin_order_billing_date( $order_id ){
    if ( isset($_POST[ 'custom_field_162' ]) ) {
		update_post_meta( $order_id, 'custom_field_162', sanitize_text_field( $_POST['custom_field_162'] ) );
    }
}



function display_antragsdetails_order_meta( $post ) {
	$order = wc_get_order( $post->ID ); // Get the WC_Order object from the WP_Post object.
    if ( ! $order ) {
        return; // Handle the case where the order is not found.
    }
	wp_nonce_field( 'custom_order_meta_nonce', 'custom_order_meta_nonce_field' );
    ?>
    <div class="order_data_column">
        <h3><a href="#" class="edit_antragsdetails"><?php _e( 'Edit' ); ?></a></h3>
        <div class="antragsdetails_display">
            <p><strong><?php _e( 'Wie viele Wohneinheiten hat die Immobilie:' ); ?></strong> <?php echo get_post_meta( $order->get_id(), 'custom_field_4', true ); ?></p>
			<p><strong><?php _e( 'Skizze zur Lage Ihrer Wohneinheit hochladen' ); ?></strong> <?php echo get_post_meta( $order->get_id(), 'custom_field_138', true ); ?></p>
            <p><strong><?php _e( 'Wie viele Wohneinheiten sind im Gebäude insgesamt vorhanden?:' ); ?></strong> <?php echo get_post_meta( $order->get_id(), 'custom_field_85', true ); ?></p>
            <p><strong><?php _e( 'Wie viele Wohneinheiten sind von der energetischen Sanierungsmaßnahme betroffen?:' ); ?></strong> <?php echo get_post_meta( $order->get_id(), 'custom_field_100', true ); ?></p>
            <p><strong><?php _e( 'In welchem Jahr wurde die Immobilie gebaut?:' ); ?></strong> <?php echo get_post_meta( $order->get_id(), 'custom_field_64', true ); ?></p>
			<p><strong><?php _e( 'Wohnfläche in m² (ggf. Schätzung):' ); ?></strong> <?php echo get_post_meta( $order->get_id(), 'custom_field_86', true ); ?></p>
            <p><strong><?php _e( 'Ich bin Eigentümer des Gebäudes/der Wohneinheit in dem die Sanierungsmaßnahme durchgeführt wird.:' ); ?></strong> <?php echo get_post_meta( $order->get_id(), 'custom_field_115', true ); ?></p>
			<p><strong><?php _e( 'Erklärung zur Antragsberechtigung: Ich erkläre, dass auch der Eigentümer des Gebäudes grundsätzlich antragsberechtigt ist und dem Investitionsvorhaben zustimmt:' ); ?></strong> <?php echo get_post_meta( $order->get_id(), 'custom_field_91', true ); ?></p>
            <p><strong><?php _e( 'Nutzen Sie Ihre Immobilie selbst?:' ); ?></strong> <?php echo get_post_meta( $order->get_id(), 'custom_field_13', true ); ?></p>
			<p><strong><?php _e( 'Anzahl der selbst genutzten Wohneinheiten:' ); ?></strong> <?php echo get_post_meta( $order->get_id(), 'custom_field_120', true ); ?></p>
            <p><strong><?php _e( 'Steht das Gebäude unter Denkmalschutz?:' ); ?></strong> <?php echo get_post_meta( $order->get_id(), 'custom_field_101', true ); ?></p>
			<p><strong><?php _e( 'Liegt Ihnen bereits ein beauftragtes Angebot / Auftrag des Handwerkers vor?:' ); ?></strong> <?php echo get_post_meta( $order->get_id(), 'custom_field_10', true ); ?></p>
            <p><strong><?php _e( 'Liegt ggf. ein individueller Sanierungsfahrplan eines Energieberaters (iSFP) vor?:' ); ?></strong> <?php echo get_post_meta( $order->get_id(), 'custom_field_87', true ); ?></p>
			<p><strong><?php _e( 'Bitte laden Sie die PDF bzw. das Dokument Ihres Sanierungsfahrplans hoch' ); ?></strong> <?php echo get_post_meta( $order->get_id(), 'custom_field_123', true ); ?></p>
			<p><strong><?php _e( 'Wie hoch ist die Auftragssumme Ihrer energetischen Sanierungsmaßnahme?:' ); ?></strong> <?php echo get_post_meta( $order->get_id(), 'custom_field_11', true ); ?></p>
            <p><strong><?php _e( '1. Investitionsstandort (Wo findet die Sanierungsmaßnahme statt?):' ); ?></strong> <?php echo get_post_meta( $order->get_id(), 'custom_field_139', true ); ?></p>
			<p><strong><?php _e( 'Postleitzahl (PLZ):' ); ?></strong> <?php echo get_post_meta( $order->get_id(), 'custom_field_140', true ); ?></p>
            <p><strong><?php _e( 'Ort:' ); ?></strong> <?php echo get_post_meta( $order->get_id(), 'custom_field_141', true ); ?></p>
            <p><strong><?php _e( 'Bestätigung zur Vollmacht: Ich bestelle die oben genannte bevollmächtigte Person gegenüber dem Bundesamt für Wirtschaft und Ausfuhrkontrolle (im Folgenden: BAFA); Frankfurter Straße 29 - 35; 65760 Eschborn als Bevollmächtigten gemäß § 14 Verwaltungsverfahrensgesetz. Die Vollmacht ermächtigt zu allen das Verwaltungs- verfahren betreffenden Verfahrenshandlungen. Ich nehme zur Kenntnis und erkläre mich damit einverstanden, dass das BAFA sämtlichen Schriftverkehr an die von mir bevollmächtigte Person/Organisation versenden wird. Mir ist bekannt, dass ich dennoch Verfahrensbeteiligter im Sinne des Verwaltungs- verfahrensgesetzes bin und bleibe und dass die bevollmächtigte Person/Organisation in meinem Namen handelt und ich die Rechtsfolgen ihrer Handlungen trage:' ); ?></strong> <?php echo get_post_meta( $order->get_id(), 'custom_field_97', true ); ?></p>
			<p><strong><?php _e( 'Ihre IBAN (für die Erstattung Ihres Zuschusses vom BAFA):' ); ?></strong> <?php echo get_post_meta( $order->get_id(), 'custom_field_63', true ); ?></p>
            <p><strong><?php _e( 'Alter der zu sanierenden Immobilie / Ausführung der Fördermaßnahmen: Ich bestätige, dass das zu renovierende Objekt älter als 5 Jahre ist und dass die Sanierungsmaßnahmen binnen 36 Monaten nach der Förderzusage ausgeführt werden:' ); ?></strong> <?php echo get_post_meta( $order->get_id(), 'custom_field_75', true ); ?></p>
			<p><strong><?php _e( 'Doppelte Förderung: Ich erkläre, dass kein Antrag bei der KfW oder dem Finanzamt (§35c EStG) auf Förderung derselben Kosten gestellt wurde oder gestellt wird. Ich verstehe, dass eine doppelte Antragstellung ausgeschlossen ist:' ); ?></strong> <?php echo get_post_meta( $order->get_id(), 'custom_field_76', true ); ?></p>
            <p><strong><?php _e( 'Warheitsgemäße Angaben: Hiermit versichere ich, dass meine Angaben wahrheitsgemäß, richtig und vollständig sind. Ich habe verstanden, dass falsche Angaben die Ablehnung meines Antrages zur Folge haben könnten:' ); ?></strong> <?php echo get_post_meta( $order->get_id(), 'custom_field_99', true ); ?></p>
			<p><strong><?php _e( 'Sofortiger Beginn der Sanierungsmaßnahmen: Ich bestätige, dass mit der Ausführung meiner Sanierungsmaßnahmen (z.B. der Bestellung von Materialien) begonnen werden soll, bevor ein Zuwendungsbescheid vorliegt - andernfalls sind Wartezeiten von bis zu 8 Wochen möglich:' ); ?></strong> <?php echo get_post_meta( $order->get_id(), 'custom_field_119', true ); ?></p>
            <p><strong><?php _e( 'Datenverarbeitung / AGB: Ja, ich nehme zur Kenntnis, dass meine Daten mittels der <a href="https://www.bafa.de/SharedDocs/Downloads/DE/Energie/beg_formular_beg_vm.pdf?__blob=publicationFile&v=2" target="_blank">BAFA Vollmacht</a> im Rahmen des Zuschussantrags von Förderheld.com sowie vom BAFA verarbeitet werden. Die <a target="_blank" href="https://förderheld.com/agb"> AGB</a> und die <a target="_blank" href="https://förderheld.com/datenschutz"> Förderheld-Datenschutzhinweise</a> sowie die <a target="_blank" href="https://www.bafa.de/DE/Service/Datenschutzerklaerung/datenschutzerklaerung_node.html"> Datenschutzhinweise des BAFA</a> habe ich zur Kenntnis genommen:' ); ?></strong> <?php echo get_post_meta( $order->get_id(), 'custom_field_77', true ); ?></p>
		
        </div>

        <div class="antragsdetails_edit" style="display:none;">
            <p><strong><?php _e( 'Wie viele Wohneinheiten hat die Immobilie?:' ); ?></strong> <input type="text" name="custom_field_4" value="<?php echo get_post_meta( $order->get_id(), 'custom_field_4', true ); ?>"></p>
			
            <p><strong><?php _e( 'Wie viele Wohneinheiten sind im Gebäude insgesamt vorhanden?:' ); ?></strong> <input type="text" name="custom_field_85" value="<?php echo get_post_meta( $order->get_id(), 'custom_field_85', true ); ?>"></p>
            <p><strong><?php _e( 'Wie viele Wohneinheiten sind von der energetischen Sanierungsmaßnahme betroffen?:' ); ?></strong> <input type="text" name="custom_field_100" value="<?php echo get_post_meta( $order->get_id(), 'custom_field_100', true ); ?>"></p>
            <p><strong><?php _e( 'In welchem Jahr wurde die Immobilie gebaut?:' ); ?></strong> <input type="text" name="custom_field_64" value="<?php echo get_post_meta( $order->get_id(), 'custom_field_64', true ); ?>"></p>
			<p><strong><?php _e( 'Wohnfläche in m² (ggf. Schätzung):' ); ?></strong> <input type="text" name="custom_field_86" value="<?php echo get_post_meta( $order->get_id(), 'custom_field_86', true ); ?>"></p>
            <p><strong><?php _e( 'Ich bin Eigentümer des Gebäudes/der Wohneinheit in dem die Sanierungsmaßnahme durchgeführt wird.:' ); ?></strong> <input type="text" name="custom_field_115" value="<?php echo get_post_meta( $order->get_id(), 'custom_field_115', true ); ?>"></p>
			<p><strong><?php _e( 'Erklärung zur Antragsberechtigung: Ich erkläre, dass auch der Eigentümer des Gebäudes grundsätzlich antragsberechtigt ist und dem Investitionsvorhaben zustimmt.:' ); ?></strong> <input type="text" name="custom_field_91" value="<?php echo get_post_meta( $order->get_id(), 'custom_field_91', true ); ?>"></p>
            <p><strong><?php _e( 'Nutzen Sie Ihre Immobilie selbst?:' ); ?></strong> <input type="text" name="custom_field_13" value="<?php echo get_post_meta( $order->get_id(), 'custom_field_13', true ); ?>"></p>
			<p><strong><?php _e( 'Anzahl der selbst genutzten Wohneinheiten:' ); ?></strong> <input type="text" name="custom_field_120" value="<?php echo get_post_meta( $order->get_id(), 'custom_field_120', true ); ?>"></p>
            <p><strong><?php _e( 'Steht das Gebäude unter Denkmalschutz?:' ); ?></strong> <input type="text" name="custom_field_101" value="<?php echo get_post_meta( $order->get_id(), 'custom_field_101', true ); ?>"></p>
			<p><strong><?php _e( 'Liegt Ihnen bereits ein beauftragtes Angebot / Auftrag des Handwerkers vor?:' ); ?></strong> <input type="text" name="custom_field_10" value="<?php echo get_post_meta( $order->get_id(), 'custom_field_10', true ); ?>"></p>
            <p><strong><?php _e( 'Liegt ggf. ein individueller Sanierungsfahrplan eines Energieberaters (iSFP) vor?:' ); ?></strong> <input type="text" name="custom_field_87" value="<?php echo get_post_meta( $order->get_id(), 'custom_field_87', true ); ?>"></p>
			<p><strong><?php _e( 'Wie hoch ist die Auftragssumme Ihrer energetischen Sanierungsmaßnahme?:' ); ?></strong> <input type="text" name="custom_field_11" value="<?php echo get_post_meta( $order->get_id(), 'custom_field_11', true ); ?>"></p>
            <p><strong><?php _e( '1. Investitionsstandort (Wo findet die Sanierungsmaßnahme statt?):' ); ?></strong> <input type="text" name="custom_field_139" value="<?php echo get_post_meta( $order->get_id(), 'custom_field_139', true ); ?>"></p>
			<p><strong><?php _e( 'Postleitzahl (PLZ):' ); ?></strong> <input type="text" name="custom_field_140" value="<?php echo get_post_meta( $order->get_id(), 'custom_field_140', true ); ?>"></p>
            <p><strong><?php _e( 'Ort:' ); ?></strong> <input type="text" name="custom_field_141" value="<?php echo get_post_meta( $order->get_id(), 'custom_field_141', true ); ?>"></p>
            <p><strong><?php _e( 'Bestätigung zur Vollmacht: Ich bestelle die oben genannte bevollmächtigte Person gegenüber dem Bundesamt für Wirtschaft und Ausfuhrkontrolle (im Folgenden: BAFA); Frankfurter Straße 29 - 35; 65760 Eschborn als Bevollmächtigten gemäß § 14 Verwaltungsverfahrensgesetz. Die Vollmacht ermächtigt zu allen das Verwaltungs- verfahren betreffenden Verfahrenshandlungen. Ich nehme zur Kenntnis und erkläre mich damit einverstanden, dass das BAFA sämtlichen Schriftverkehr an die von mir bevollmächtigte Person/Organisation versenden wird. Mir ist bekannt, dass ich dennoch Verfahrensbeteiligter im Sinne des Verwaltungs- verfahrensgesetzes bin und bleibe und dass die bevollmächtigte Person/Organisation in meinem Namen handelt und ich die Rechtsfolgen ihrer Handlungen trage:' ); ?></strong> <input type="text" name="custom_field_97" value="<?php echo get_post_meta( $order->get_id(), 'custom_field_97', true ); ?>"></p>
			<p><strong><?php _e( 'Ihre IBAN (für die Erstattung Ihres Zuschusses vom BAFA):' ); ?></strong> <input type="text" name="custom_field_63" value="<?php echo get_post_meta( $order->get_id(), 'custom_field_63', true ); ?>"></p>
            <p><strong><?php _e( 'Alter der zu sanierenden Immobilie / Ausführung der Fördermaßnahmen: Ich bestätige, dass das zu renovierende Objekt älter als 5 Jahre ist und dass die Sanierungsmaßnahmen binnen 36 Monaten nach der Förderzusage ausgeführt werden:' ); ?></strong> <input type="text" name="custom_field_75" value="<?php echo get_post_meta( $order->get_id(), 'custom_field_75', true ); ?>"></p>
			<p><strong><?php _e( 'Doppelte Förderung: Ich erkläre, dass kein Antrag bei der KfW oder dem Finanzamt (§35c EStG) auf Förderung derselben Kosten gestellt wurde oder gestellt wird. Ich verstehe, dass eine doppelte Antragstellung ausgeschlossen ist:' ); ?></strong> <input type="text" name="custom_field_76" value="<?php echo get_post_meta( $order->get_id(), 'custom_field_76', true ); ?>"></p>
            <p><strong><?php _e( 'Warheitsgemäße Angaben: Hiermit versichere ich, dass meine Angaben wahrheitsgemäß, richtig und vollständig sind. Ich habe verstanden, dass falsche Angaben die Ablehnung meines Antrages zur Folge haben könnten:' ); ?></strong> <input type="text" name="custom_field_99" value="<?php echo get_post_meta( $order->get_id(), 'custom_field_99', true ); ?>"></p>
			<p><strong><?php _e( 'Sofortiger Beginn der Sanierungsmaßnahmen: Ich bestätige, dass mit der Ausführung meiner Sanierungsmaßnahmen (z.B. der Bestellung von Materialien) begonnen werden soll, bevor ein Zuwendungsbescheid vorliegt - andernfalls sind Wartezeiten von bis zu 8 Wochen möglich:' ); ?></strong> <input type="text" name="custom_field_119" value="<?php echo get_post_meta( $order->get_id(), 'custom_field_119', true ); ?>"></p>
            <p><strong><?php _e( 'Datenverarbeitung / AGB: Ja, ich nehme zur Kenntnis, dass meine Daten mittels der <a href="https://www.bafa.de/SharedDocs/Downloads/DE/Energie/beg_formular_beg_vm.pdf?__blob=publicationFile&v=2" target="_blank">BAFA Vollmacht</a> im Rahmen des Zuschussantrags von Förderheld.com sowie vom BAFA verarbeitet werden. Die <a target="_blank" href="https://förderheld.com/agb"> AGB</a> und die <a target="_blank" href="https://förderheld.com/datenschutz"> Förderheld-Datenschutzhinweise</a> sowie die <a target="_blank" href="https://www.bafa.de/DE/Service/Datenschutzerklaerung/datenschutzerklaerung_node.html"> Datenschutzhinweise des BAFA</a> habe ich zur Kenntnis genommen:' ); ?></strong> <input type="text" name="custom_field_77" value="<?php echo get_post_meta( $order->get_id(), 'custom_field_77', true ); ?>"></p>
        </div>
    </div>
	<style>
		div#postcustomstuff{
			display:none;
		}
		a.edit_antragsdetails:after {
			font-family: Dashicons;
			content: "\f464";
			font-size: 20px;
		}

		a.edit_antragsdetails {
			font-size: 0;
			text-decoration: none;
			position: absolute;
			right: 10px;
			top: -6px;
		}

		.antragsdetails_edit strong, .antragsdetails_display strong {
			display: block;
		}

		.antragsdetails_display p {
			border-bottom: 1px solid #8080803d;
			padding-bottom: 10px;
		}

		.antragsdetails_edit p {border-bottom: 1px solid #8080803d;
			padding-bottom: 10px;
		}

		.antragsdetails_edit input[type="text"], .antragsdetails_edit textarea {
			width: 100%;
		}

		.antragsdetails_edit strong {
			padding-bottom: 10px;
		}	
	</style>
    <?php
}

add_action( 'admin_footer', 'custom_antragsdetails_edit_script' );
function custom_antragsdetails_edit_script() {
    ?>
    <script type="text/javascript">
        jQuery(document).ready(function($){
            $('.edit_antragsdetails').on('click', function(e) {
                e.preventDefault();
                $('.antragsdetails_display').hide();
                $('.antragsdetails_edit').show();
				$('.edit_antragsdetails').hide();
            });
        });
    </script>
    <?php
}
add_action( 'woocommerce_process_shop_order_meta', 'save_custom_antragsdetails_admin_fields');
function save_custom_antragsdetails_admin_fields( $order_id ) {
    if ( isset( $_POST['custom_field_4'] ) ) {
        update_post_meta( $order_id, 'custom_field_4', sanitize_text_field( $_POST['custom_field_4'] ) );
    }
    if ( isset( $_POST['custom_field_85'] ) ) {
        update_post_meta( $order_id, 'custom_field_85', sanitize_text_field( $_POST['custom_field_85'] ) );
    }
    if ( isset( $_POST['custom_field_100'] ) ) {
        update_post_meta( $order_id, 'custom_field_100', sanitize_text_field( $_POST['custom_field_100'] ) );
    }
    if ( isset( $_POST['custom_field_64'] ) ) {
        update_post_meta( $order_id, 'custom_field_64', sanitize_text_field( $_POST['custom_field_64'] ) );
    }
	if ( isset( $_POST['custom_field_86'] ) ) {
        update_post_meta( $order_id, 'custom_field_86', sanitize_text_field( $_POST['custom_field_86'] ) );
    }
    if ( isset( $_POST['custom_field_115'] ) ) {
        update_post_meta( $order_id, 'custom_field_115', sanitize_text_field( $_POST['custom_field_115'] ) );
    }
    if ( isset( $_POST['custom_field_91'] ) ) {
        update_post_meta( $order_id, 'custom_field_91', sanitize_text_field( $_POST['custom_field_91'] ) );
    }
    if ( isset( $_POST['custom_field_13'] ) ) {
        update_post_meta( $order_id, 'custom_field_13', sanitize_text_field( $_POST['custom_field_13'] ) );
    }
	if ( isset( $_POST['custom_field_120'] ) ) {
        update_post_meta( $order_id, 'custom_field_120', sanitize_text_field( $_POST['custom_field_120'] ) );
    }
    if ( isset( $_POST['custom_field_101'] ) ) {
        update_post_meta( $order_id, 'custom_field_101', sanitize_text_field( $_POST['custom_field_101'] ) );
    }
    if ( isset( $_POST['custom_field_10'] ) ) {
        update_post_meta( $order_id, 'custom_field_10', sanitize_text_field( $_POST['custom_field_10'] ) );
    }
    if ( isset( $_POST['custom_field_87'] ) ) {
        update_post_meta( $order_id, 'custom_field_87', sanitize_text_field( $_POST['custom_field_87'] ) );
    }
	if ( isset( $_POST['custom_field_11'] ) ) {
        update_post_meta( $order_id, 'custom_field_11', sanitize_text_field( $_POST['custom_field_11'] ) );
    }
    if ( isset( $_POST['custom_field_139'] ) ) {
        update_post_meta( $order_id, 'custom_field_139', sanitize_text_field( $_POST['custom_field_139'] ) );
    }
    if ( isset( $_POST['custom_field_140'] ) ) {
        update_post_meta( $order_id, 'custom_field_140', sanitize_text_field( $_POST['custom_field_140'] ) );
    }
    if ( isset( $_POST['custom_field_141'] ) ) {
        update_post_meta( $order_id, 'custom_field_141', sanitize_text_field( $_POST['custom_field_141'] ) );
    }
	if ( isset( $_POST['custom_field_97'] ) ) {
        update_post_meta( $order_id, 'custom_field_97', sanitize_text_field( $_POST['custom_field_97'] ) );
    }
	if ( isset( $_POST['custom_field_63'] ) ) {
        update_post_meta( $order_id, 'custom_field_63', sanitize_text_field( $_POST['custom_field_63'] ) );
    }
	if ( isset( $_POST['custom_field_75'] ) ) {
        update_post_meta( $order_id, 'custom_field_75', sanitize_text_field( $_POST['custom_field_75'] ) );
    }
	if ( isset( $_POST['custom_field_76'] ) ) {
        update_post_meta( $order_id, 'custom_field_76', sanitize_text_field( $_POST['custom_field_76'] ) );
    }
	if ( isset( $_POST['custom_field_99'] ) ) {
        update_post_meta( $order_id, 'custom_field_99', sanitize_text_field( $_POST['custom_field_99'] ) );
    }
	if ( isset( $_POST['custom_field_119'] ) ) {
        update_post_meta( $order_id, 'custom_field_119', sanitize_text_field( $_POST['custom_field_119'] ) );
    }
	if ( isset( $_POST['custom_field_77'] ) ) {
        update_post_meta( $order_id, 'custom_field_77', sanitize_text_field( $_POST['custom_field_77'] ) );
	}
}



add_action('woocommerce_admin_order_data_after_billing_address', 'add_handwerkerinfos_to_order_edit_page');

function add_handwerkerinfos_to_order_edit_page($order) {
    $columns = [
        [
            'custom_field_40' => 'Name des Handwerksbetriebs, der die Sanierungsarbeiten durchführt',
            'custom_field_59' => '<h3>Adresse des Handwerksbetriebs</h3><br>Adresse Zeile 1',
			'custom_field_59_address2' => 'Anschrift Zusatz',
			'custom_field_59_city' => 'Ort',
			'custom_field_59_state' => 'Bundesland',
			'custom_field_59_postal' => 'Zip/Postal Code',
			'custom_field_59_country' => 'Land',
            'custom_field_44' => 'E-Mail-Adresse des Handwerksbetriebs',
            'custom_field_133' => 'Telefonnummer des Handwerksbetriebs',
            'custom_field_60' => 'Sind weitere Handwerksbetriebe involviert?',
        ],
        [
            'custom_field_61' => 'Name des zweiten Handwerksbetriebs',
			'custom_field_62' => '<h3>Adresse des zweiten Handwerksbetriebs</h3><br>Adresse Zeile 1',
			'custom_field_62_address2' => 'Anschrift Zusatz',
			'custom_field_62_city' => 'Ort',
			'custom_field_62_state' => 'Bundesland',
			'custom_field_62_postal' => 'Zip/Postal Code',
			'custom_field_62_country' => 'Land',
            'custom_field_111' => 'E-Mail-Adresse des zweiten Handwersbetriebs',
            'custom_field_134' => 'Telefonnummer des zweiten Handwerksbetriebs',
            'custom_field_65' => 'Sind darüber hinaus noch weitere Handwerksbetriebe involviert?',
        ],
        [
            'custom_field_66' => 'Name des dritten Handwerksbetriebs',
			'custom_field_67' => '<h3>Adresse des dritten Handwerksbetriebs</h3><br>Adresse Zeile 1',
			'custom_field_67_address2' => 'Anschrift Zusatz',
			'custom_field_67_city' => 'Ort',
			'custom_field_67_state' => 'Bundesland',
			'custom_field_67_postal' => 'Zip/Postal Code',
			'custom_field_67_country' => 'Land',
            'custom_field_113' => 'E-Mail-Adresse des dritten Handwersbetriebs',
            'custom_field_135' => 'Telefonnummer des dritten Handwerksbetriebs',
            'custom_field_46' => 'Sonstige Anmerkungen',
        ],
    ];

    echo '<div class="handwerkerinfos"><h3>' . __('Handwerkerinfos', 'woocommerce') . '</h3>'; // Section title

    echo '<div class="custom-handwerkerinfos-columns" style="display: flex; flex-wrap: wrap;">';

    foreach ($columns as $column) {
        echo '<div class="handwerkerinfo-column" style="flex: 1 0 33%; padding: 10px; box-sizing: border-box;">';
        foreach ($column as $meta_key => $label) {
            $value = get_post_meta($order->get_id(), $meta_key, true);
            echo '<p><strong>' . $label . ':</strong> <span class="edit-handwerkerinfo" data-meta-key="'. esc_attr($meta_key) .'">' . esc_html($value) . '</span></p>';
        }
        echo '</div>';
    }

    echo '</div>'; 

    echo '<button id="edit-handwerkerinfos" type="button" class="button">' . __('Edit Handwerkerinfos', 'woocommerce') . '</button></div>';

    ?>
    <script type="text/javascript">
    jQuery(document).ready(function($) {
        $('#edit-handwerkerinfos').on('click', function() {
            $('.edit-handwerkerinfo').each(function() {
                var metaKey = $(this).data('meta-key');
                var value = $(this).text();
                $(this).replaceWith('<input type="text" name="handwerkerinfos[' + metaKey + ']" value="' + value + '">');
            });
            $(this).hide();
        });
    });
    </script>
	<style>
		
		table.display_meta th {
    display: none;
}
	@media(min-width:1280px){

.order_custom_field .cols {
    display: flex;
    width: 120%;
    margin-top: 26px;
}

.order_custom_field .cols .col-one {
    width: 100%;
}

.order_custom_field .cols .col-one:first-child {display: flex;flex-direction: column;}

.order_custom_field .cols .col-one a img {
    max-height: 30px;
    width: auto!important;
}
		.handwerkerinfos {
		margin-left: -105%;
		margin-right: -100%;
	}
	.handwerkerinfos {
		margin-top: 300px;
	}

	.order_custom_field {
		display: inline-block;
	}
		a#zuwendungsbescheid_pdf_link {
			width: 33%;
			float: left;
			line-height: 29px;
			margin-top: 0!important;
			text-align: center;
		}

		button.button.remove_pdf_button {
			width: 33%;
			margin-top: 0!important;
		}

		.order_custom_field {width: 200%;z-index: 999;position: relative;}

		button.button.upload_pdf_button {
			width: 33%;
			float: left;
		}

		.order_custom_field a {
			width: 33%;
			float: left;
			line-height: 29px;
			margin-top: 0 !important;
			text-align: center;
		}
		.order_custom_field p {
			clear: both;
		}
		.edit_address {
			position: relative;
			z-index: 9999;
			background: white;
			min-height: 291px;
		}
	.edit_address:nth-child(5) {
    min-height: auto;
}
		.handwerkerinfo-column {padding-left: 0!important;}
		button#generate_invoice_button {
    max-width: 140px;
    margin-bottom: 9px;
}
		}
	</style>
    <?php
}

add_action('woocommerce_process_shop_order_meta', 'save_handwerkerinfos_custom_fields');

function save_handwerkerinfos_custom_fields($order_id) {
    if (isset($_POST['handwerkerinfos'])) {
        foreach ($_POST['handwerkerinfos'] as $meta_key => $value) {
            update_post_meta($order_id, $meta_key, sanitize_text_field($value));
        }
    }
}

add_action('woocommerce_admin_order_data_after_order_details', 'custom_add_pdf_media_library_fields');
function custom_add_pdf_media_library_fields($order) {
    $zuwendungsbescheid_pdf = get_post_meta($order->get_id(), '_zuwendungsbescheid_pdf', true);
    $festsetzungsbescheid_pdf = get_post_meta($order->get_id(), '_festsetzungsbescheid_pdf', true);
	$invoice_pdf = get_post_meta($order->get_id(), '_invoice_pdf', true);
	$confirmation_pdf = get_post_meta($order->get_id(), '_confirmation_pdf', true);
	$authorisation_pdf = get_post_meta($order->get_id(), '_authorisation_pdf', true);
    $authorisation_manual_pdf = get_post_meta($order->get_id(), '_authorisation_manual_pdf', true);; // Vollmacht Manuell PDF

    echo '<div class="order_custom_field"><div class="cols"><div class="col-one">';
    echo '<h3>' . __('Upload PDFs', 'your-textdomain') . '</h3>';
	echo '<p><strong>' . __('PDF Invoice', 'your-textdomain') . '</strong></p>';
	if ($invoice_pdf) {
        echo '<a href="' . esc_url($invoice_pdf) . '" target="_blank" id="_invoice_pdf" style="display:block;margin-top:10px;">' . __('View PDF', 'your-textdomain') . '</a>';
    } else {
        echo '<button type="button" class="button" id="generate_invoice_button" style="margin-top:0px;margin-bottom:0px;" data-order-id="'.$order->get_id().'">' . __('Generate Invoice', 'your-textdomain') . '</button>';
    }
	echo '<p><strong>' . __('Vollmacht Automatisiert PDF', 'your-textdomain') . '</strong></p>';
	echo '<a href="'.esc_url($authorisation_pdf).'" target="_blank">View PDF</a>';
	
	echo '<p><strong>' . __('AB Allgemein PDF', 'your-textdomain') . '</strong></p>';
	echo '<a href="'.esc_url($confirmation_pdf).'" target="_blank">View PDF</a>';
	
    echo '</div><div class="col-one"><h3 style="color:white">' . __('Upload PDFs', 'your-textdomain') . '</h3><p><strong>' . __('Zuwendungsbescheid PDF', 'your-textdomain') . '</strong></p>';
    echo '<input type="hidden" id="zuwendungsbescheid_pdf" name="_zuwendungsbescheid_pdf" value="' . esc_attr($zuwendungsbescheid_pdf) . '" />';
    echo '<button type="button" class="button upload_pdf_button" data-target="#zuwendungsbescheid_pdf" data-pdf-container="#zuwendungsbescheid_pdf_container">' . __('Upload/Select PDF', 'your-textdomain') . '</button>';
    if ($zuwendungsbescheid_pdf) {
        echo '<a href="' . esc_url($zuwendungsbescheid_pdf) . '" target="_blank" id="zuwendungsbescheid_pdf_link" style="display:block;margin-top:10px;">' . __('View PDF', 'your-textdomain') . '</a>';
		echo '<button type="button" class="button remove_pdf_button" data-target="#zuwendungsbescheid_pdf" data-target-link="#zuwendungsbescheid_pdf_link" style="margin-top: 10px;">' . __('Delete', 'your-textdomain') . '</button>';

    }
	
 	echo '<div id="zuwendungsbescheid_pdf_container" style="margin-top: 10px;margin-bottom: 30px;"></div>';
    // Festsetzungsbescheid Media Library Field
    echo '<p ><strong>' . __('Festsetzungsbescheid PDF', 'your-textdomain') . '</strong></p>';
    echo '<input type="hidden" id="festsetzungsbescheid_pdf" name="_festsetzungsbescheid_pdf" value="' . esc_attr($festsetzungsbescheid_pdf) . '" />';
    echo '<button type="button" class="button upload_pdf_button" data-target="#festsetzungsbescheid_pdf" data-pdf-container="#festsetzungsbescheid_pdf_container">' . __('Upload/Select PDF', 'your-textdomain') . '</button>';
    if ($festsetzungsbescheid_pdf) {
        echo '<a href="' . esc_url($festsetzungsbescheid_pdf) . '" target="_blank" id="festsetzungsbescheid_pdf_link" style="display:block;margin-top:10px;">' . __('View PDF', 'your-textdomain') . '</a>';
		echo '<button type="button" class="button remove_pdf_button" data-target="#festsetzungsbescheid_pdf"  data-target-link="#festsetzungsbescheid_pdf_link" style="margin-top: 10px;">' . __('Delete', 'your-textdomain') . '</button>';

    }

    echo '<div id="festsetzungsbescheid_pdf_container" style="margin-top: 10px;"></div>';

	// $authorisation_manual_pdf

	echo '<p ><strong>' . __('Vollmacht Manuell PDF', 'your-textdomain') . '</strong></p>';
	echo '<input type="hidden" id="_authorisation_manual_pdf" name="_authorisation_manual_pdf" value="' . esc_attr($authorisation_manual_pdf) . '" />';
	echo '<button type="button" class="button upload_pdf_button" data-target="#_authorisation_manual_pdf" data-pdf-container="#_authorisation_manual_pdf_container">' . __('Upload/Select PDF', 'your-textdomain') . '</button>';
	if ($authorisation_manual_pdf) {
		echo '<a href="' . esc_url($authorisation_manual_pdf) . '" target="_blank" id="_authorisation_manual_pdf_link" style="display:block;margin-top:10px;">' . __('View PDF', 'your-textdomain') . '</a>';
		echo '<button type="button" class="button remove_pdf_button" data-target="#_authorisation_manual_pdf"  data-target-link="#_authorisation_manual_pdf_link" style="margin-top: 10px;">' . __('Delete', 'your-textdomain') . '</button>';

	}
	echo '<div id="_authorisation_manual_pdf_container" style="margin-top: 10px;"></div>';

    echo '</div></div></div>';

}

add_action('woocommerce_process_shop_order_meta', 'custom_save_pdf_media_library_fields', 45, 2);
function custom_save_pdf_media_library_fields($order_id, $post) {
    if (isset($_POST['_zuwendungsbescheid_pdf'])) {
        update_post_meta($order_id, '_zuwendungsbescheid_pdf', sanitize_text_field($_POST['_zuwendungsbescheid_pdf']));
    }
    if (isset($_POST['_festsetzungsbescheid_pdf'])) {
        update_post_meta($order_id, '_festsetzungsbescheid_pdf', sanitize_text_field($_POST['_festsetzungsbescheid_pdf']));
    }
    if (isset($_REQUEST['_authorisation_manual_pdf'])) {
        update_post_meta($order_id, '_authorisation_manual_pdf', sanitize_text_field($_REQUEST['_authorisation_manual_pdf']));
    }
}


add_action( 'woocommerce_order_list_table_restrict_manage_orders', 'add_product_filter_to_orders', 10 );

function add_product_filter_to_orders( $order_list ) {
    $products = wc_get_products( array(
        'limit' => -1,
        'status' => 'publish',
    ));

    echo '<select name="product_filter" style="width: 150px;">';
    echo '<option value="">' . __( 'Filter by Product', 'woocommerce' ) . '</option>';

    foreach ( $products as $product ) {
        $selected = ( isset( $_GET['product_filter'] ) && $_GET['product_filter'] == $product->get_id() ) ? ' selected' : '';
        echo '<option value="' . esc_attr( $product->get_id() ) . '"' . $selected . '>' . esc_html( $product->get_name() ) . '</option>';
    }

    echo '</select>';
}

add_filter( 'woocommerce_order_query_args', 'filter_orders_by_selected_product' );

function filter_orders_by_selected_product( $query_args ) {
    if ( isset( $_GET['product_filter'] ) && $_GET['product_filter'] !== '' ) {
        global $wpdb;
        $product_id = absint( $_GET['product_filter'] );

        // Custom query to get order IDs with the specified product in their line items
        $order_ids = $wpdb->get_col( $wpdb->prepare(
            "
            SELECT order_id
            FROM {$wpdb->prefix}woocommerce_order_items AS items
            INNER JOIN {$wpdb->prefix}woocommerce_order_itemmeta AS itemmeta ON items.order_item_id = itemmeta.order_item_id
            WHERE items.order_item_type = 'line_item'
            AND itemmeta.meta_key = '_product_id'
            AND itemmeta.meta_value = %d
            ",
            $product_id
        ));

        // If we have matching order IDs, modify the query arguments
        if ( ! empty( $order_ids ) ) {
            $query_args['post__in'] = $order_ids;
        } else {
            // If no orders found with this product, prevent any results from showing
            $query_args['post__in'] = array( 0 );
        }
    }

    return $query_args;
}

