<?php
add_action('admin_menu', 'custom_email_settings_page');
function custom_email_settings_page() {
    add_menu_page(
        'Order Status Emails',
        'Order Status Emails',
        'manage_options',
        'order-status-emails',
        'render_email_settings_page',
        'dashicons-email-alt',
        56
    );
}

// Render the settings page with tabs
function render_email_settings_page() {
    ?>
    <div class="wrap">
        <h1><?php echo esc_html__('Order Status Emails Settings', 'your-textdomain'); ?></h1>

        <!-- Tabs Navigation -->
        <h2 class="nav-tab-wrapper">
            <a href="#tab-fh" class="nav-tab nav-tab-active">FH</a>
            <a href="#tab-hbi-f" class="nav-tab">HBI 15%</a>
            <a href="#tab-hbi-t" class="nav-tab">HBI 20%</a>
            <a href="#tab-uni-f" class="nav-tab">UNIX 15%</a>
            <a href="#tab-uni-t" class="nav-tab">UNIX 20%</a>
        </h2>

        <form method="post" action="options.php">
            <?php
            settings_fields('order_status_email_settings');
            do_settings_sections('order-status-emails');
            submit_button();
            ?>
        </form>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const tabs = document.querySelectorAll('.nav-tab');
            tabs.forEach(tab => {
                tab.addEventListener('click', function(event) {
                    event.preventDefault();
                    document.querySelectorAll('.nav-tab').forEach(t => t.classList.remove('nav-tab-active'));
                    document.querySelectorAll('.tab-content').forEach(content => content.style.display = 'none');

                    this.classList.add('nav-tab-active');
                    document.querySelector(this.getAttribute('href')).style.display = 'block';
                });
            });
            // Show the first tab content by default
            document.querySelector('#tab-fh').style.display = 'block';
        });
    </script>
    <?php
}

// Register the settings with tabs
add_action('admin_init', 'custom_register_email_settings');
function custom_register_email_settings() {
    $groups = [
        'fh' => ['auftrag', 'forderantrag', 'erhalten', 'ausgefuhrt', 'vollstandig', 'bei-bafa', 'abgeschlossen'],
        'hbi-f' => ['hf-auftrag', 'hf-forderantrag', 'hf-erhalten', 'hf-ausgefuhrt', 'hf-vollstandig', 'hf-bei-bafa', 'hf-abgeschlossen'],
        'hbi-t' => ['ht-auftrag', 'ht-forderantrag', 'ht-erhalten', 'ht-ausgefuhrt', 'ht-vollstandig', 'ht-bei-bafa', 'ht-abgeschlossen'],
        'uni-f' => ['uf-auftrag', 'uf-forderantrag', 'uf-erhalten', 'uf-ausgefuhrt', 'uf-vollstandig', 'uf-bei-bafa', 'uf-abgeschlossen'],
        'uni-t' => ['ut-auftrag', 'ut-forderantrag', 'ut-erhalten', 'ut-ausgefuhrt', 'ut-vollstandig', 'ut-bei-bafa', 'ut-abgeschlossen']
    ];

    foreach ($groups as $tab => $statuses) {
        add_settings_section(
            "email_settings_section_$tab",
            __("", 'your-textdomain'),
            function () use ($tab) {
                echo "<div id='tab-$tab' class='tab-content' style='display:none;'>";
            },
            'order-status-emails'
        );

        foreach ($statuses as $status) {
            register_setting('order_status_email_settings', "email_subject_$status");
            register_setting('order_status_email_settings', "email_subject_additional_$status");
            register_setting('order_status_email_settings', "email_body_client_$status");
            register_setting('order_status_email_settings', "email_body_recipient_$status");
			$statustitle = $status;
			$statustitle = str_replace("ht-", "HBI 20% ", $statustitle);
			$statustitle = str_replace("hf-", "HBI 15% ", $statustitle);
			$statustitle = str_replace("ut-", "UNIX 20% ", $statustitle);
			$statustitle = str_replace("uf-", "UNIX 15% ", $statustitle);

	        register_setting('order_status_email_settings', "email_smtp_$tab");
	        add_settings_field(
		        "email_smtp_$status",
		        'SMTP From Adress<br><a href="https://bb3y8nd.myrdbx.io/wp-admin/options-general.php?page=fluent-mail#/connections" target="_blank">SAME AS HERE (SET IT BEFORE)</a>',
		        'custom_email_smtp_field_callback',
		        'order-status-emails',
		        "email_settings_section_$tab",
		        array('tab' => $tab)
	        );

	        register_setting('order_status_email_settings', "email_smtp_name_$tab");
	        add_settings_field(
		        "email_smtp_name_$status",
		        'SMTP From Adress Name',
		        'custom_email_smtp_name_field_callback',
		        'order-status-emails',
		        "email_settings_section_$tab",
		        array('tab' => $tab)
	        );

            add_settings_field(
                "email_subject_$status",
                sprintf(__('Email Subject for %s', 'your-textdomain'), $statustitle),
                'custom_email_subject_field_callback',
                'order-status-emails',
                "email_settings_section_$tab",
                array('status' => $status)
            );
            add_settings_field(
                "email_subject_additional_$status",
                sprintf(__('Email Subject for Additional Recipient - %s', 'your-textdomain'), $statustitle),
                'custom_email_subject_field_new_callback',
                'order-status-emails',
                "email_settings_section_$tab",
                array('status' => $status)
            );
            add_settings_field(
                "email_body_client_$status",
                sprintf(__('Email Body for Client - %s', 'your-textdomain'), $statustitle),
                'custom_email_body_client_field_callback',
                'order-status-emails',
                "email_settings_section_$tab",
                array('status' => $status)
            );
            add_settings_field(
                "email_body_recipient_$status",
                sprintf(__('Email Body for Additional Recipient - %s', 'your-textdomain'), $statustitle),
                'custom_email_body_recipient_field_callback',
                'order-status-emails',
                "email_settings_section_$tab",
                array('status' => $status)
            );
        }
        add_settings_section(
            "email_settings_section__new$tab",
            __("", 'your-textdomain'),
            function () use ($tab) {
                echo "</div>";
            },
            'order-status-emails'
        );
    }
}


// Callbacks for settings fields
function custom_email_smtp_field_callback($args) {
    $tab = $args['tab'];
    $option = get_option("email_smtp_$tab");
    echo "<input type='text' name='email_smtp_$tab' value='" . esc_attr($option) . "' class='regular-text'>";
}

function custom_email_smtp_name_field_callback($args) {
    $tab = $args['tab'];
    $option = get_option("email_smtp_name_$tab");
    echo "<input type='text' name='email_smtp_name_$tab' value='" . esc_attr($option) . "' class='regular-text'>";
}

function custom_email_subject_field_callback($args) {
    $status = $args['status'];
    $option = get_option("email_subject_$status");
    echo "<input type='text' name='email_subject_$status' value='" . esc_attr($option) . "' class='regular-text'>";
}
function custom_email_subject_field_new_callback($args) {
    $status = $args['status'];
    $option = get_option("email_subject_additional_$status");
    echo "<input type='text' name='email_subject_additional_$status' value='" . esc_attr($option) . "' class='regular-text'>";
}

function custom_email_body_client_field_callback($args) {
    $status = $args['status'];
    $option = get_option("email_body_client_$status");
    wp_editor($option, "email_body_client_$status", array(
        'textarea_name' => "email_body_client_$status",
        'media_buttons' => false,
        'textarea_rows' => 10,
        'teeny' => true, // Set to true to show a simplified editor
    ));
}

function custom_email_body_recipient_field_callback($args) {
    $status = $args['status'];
    $option = get_option("email_body_recipient_$status");
    wp_editor($option, "email_body_recipient_$status", array(
        'textarea_name' => "email_body_recipient_$status",
        'media_buttons' => false,
        'textarea_rows' => 10,
        'teeny' => true, // Set to true to show a simplified editor
    ));
}

function custom_enable_follow_up_email_field_callback() {
    $option = get_option('enable_follow_up_email');
    echo "<input type='checkbox' name='enable_follow_up_email' value='1' " . checked(1, $option, false) . ">";
}