<?php
    
function create_wc_order_from_wpforms($fields, $entry, $form_data, $entry_id) {
    $target_form_id = array(5000, 5653, 6107); 
    if (!in_array($form_data['id'], $target_form_id)) {
        return;
    }
    $customer_first_name = !empty($fields[24]['value']) ? sanitize_text_field($fields[24]['value']) : 'Gast';
    $customer_last_name  = !empty($fields[27]['value']) ? sanitize_text_field($fields[27]['value']) : 'Gast';
    $customer_email      = !empty($fields[34]['value']) ? sanitize_email($fields[34]['value']) : 'no-email@example.com';
	
	if($form_data['id'] == 5000){
		$product_id = 6269; 
		$total_order = ((float)$fields[11]['value']) * 0.09;
		$counter_fn = get_option( 'custom_counter_fn', 1 );
		$custom_count = 'FH-' . sprintf( '%05d', $counter_fn );
		update_option( 'custom_counter_fn', $counter_fn + 1 );
	}
	if($form_data['id'] == 5653){
		$product_id = 6294; 
		$total_order = 500;
		$counter_uni = get_option( 'custom_counter_uni', 1 );
		$custom_count = 'UNI-' . sprintf( '%05d', $counter_uni );
		update_option( 'custom_counter_uni', $counter_uni + 1 );
	}
	if($form_data['id'] == 6107){
		$product_id = 6295; 
		$total_order = 500;
		$counter_hbi = get_option( 'custom_counter_hbi', 1 );
		$custom_count = 'HBI-' . sprintf( '%05d', $counter_hbi );
		update_option( 'custom_counter_hbi', $counter_hbi + 1 );
	}
    
    $order = wc_create_order();
    $product = wc_get_product($product_id);
	$vat = number_format($total_order * 0.19, 2);
	$total = number_format($total_order / 1.19, 2);
	
    $item_id = $order->add_product($product, 1, array(
		'subtotal' => $total, 
		'total' => $total, 
	));

	if ($item_id) {
		wc_add_order_item_meta($item_id, 'info', $fields[15]['value']);
		wc_add_order_item_meta($item_id, 'order_id', 'FörderHeld-Vorgangsnummer: '.$custom_count);
	}
	$order_items = $order->get_items();
    $order_item = end($order_items);
    $taxes = array(
        'total' => array($vat),
        'subtotal' => array($vat),
    );
    $order_item->set_taxes($taxes);
    $order_item->save();
    $order->set_address(array(
        'first_name' => $customer_first_name,
        'last_name'  => $customer_last_name,
        'email'      => $customer_email,
        'phone'      => $fields[136]['value'],
        'address_1'  => $fields[142]['value'], 
        'city'       => $fields[144]['value'],
        'postcode'   => $fields[143]['value'],
		'company'   => $fields[88]['value'],
        'country'    => 'DE',
    ), 'billing');
	
	update_post_meta($order->get_id(), 'entry_id', $entry_id);
	update_post_meta($order->get_id(), 'form_id', $form_data['id']);
	
//	$prefix = get_option( 'custom_order_number_prefix', '' );
//    $counter = get_option( 'custom_order_number_counter', 1 );

    // Generate the custom order number with leading zeros
//    $custom_order_number = $prefix . sprintf( '%05d', $counter );

    // Increment the counter for the next order
//    update_option( 'custom_order_number_counter', $counter + 1 );
	
	$order->update_meta_data( '_custom_field_146_new', $custom_count );
	
	
	if($form_data['id'] == 5000){
		update_post_meta($order->get_id(), 'custom_field_162', $fields[162]['value']);
		update_post_meta($order->get_id(), 'custom_field_77', $fields[77]['value']);
	}
	if($form_data['id'] == 5653){
		update_post_meta($order->get_id(), 'custom_field_162', $fields[153]['value']);
		update_post_meta($order->get_id(), 'custom_field_77', $fields[77]['value']);
	}
	if($form_data['id'] == 6107){
		update_post_meta($order->get_id(), 'custom_field_162', $fields[154]['value']);
		update_post_meta($order->get_id(), 'custom_field_77', $fields[152]['value']);
	}
	
	update_post_meta($order->get_id(), 'custom_field_24', $fields[24]['value']);
//	update_post_meta($order->get_id(), 'custom_invoice_id_new', $custom_order_number);
	update_post_meta($order->get_id(), 'custom_field_27', $fields[27]['value']);
	update_post_meta($order->get_id(), 'custom_field_34', $fields[34]['value']);
	
	update_post_meta($order->get_id(), 'custom_field_136', $fields[136]['value']);
	update_post_meta($order->get_id(), 'custom_field_142', $fields[142]['value']);
	update_post_meta($order->get_id(), 'custom_field_144', $fields[144]['value']);
	update_post_meta($order->get_id(), 'custom_field_143', $fields[143]['value']);
	update_post_meta($order->get_id(), 'custom_field_88', $fields[88]['value']);
	update_post_meta($order->get_id(), 'custom_order_id', $custom_count);
	update_post_meta($order->get_id(), 'custom_invoice_id', $fields[153]['value']);
	update_post_meta($order->get_id(), 'custom_field_151', $fields[151]['value']);
	update_post_meta($order->get_id(), 'custom_field_4', $fields[4]['value']);
	update_post_meta($order->get_id(), 'custom_field_85', $fields[85]['value']);
	update_post_meta($order->get_id(), 'custom_field_100', $fields[100]['value']);
	update_post_meta($order->get_id(), 'custom_field_64', $fields[64]['value']);
	update_post_meta($order->get_id(), 'custom_field_86', $fields[86]['value']);
	update_post_meta($order->get_id(), 'custom_field_115', $fields[115]['value']);
	update_post_meta($order->get_id(), 'custom_field_91', $fields[91]['value']);
	update_post_meta($order->get_id(), 'custom_field_13', $fields[13]['value']);
	update_post_meta($order->get_id(), 'custom_field_120', $fields[120]['value']);
	update_post_meta($order->get_id(), 'custom_field_101', $fields[101]['value']);
	update_post_meta($order->get_id(), 'custom_field_10', $fields[10]['value']);
	update_post_meta($order->get_id(), 'custom_field_87', $fields[87]['value']);
	update_post_meta($order->get_id(), 'custom_field_11', $fields[11]['value']);
	update_post_meta($order->get_id(), 'custom_field_139', $fields[139]['value']);
	update_post_meta($order->get_id(), 'custom_field_140', $fields[140]['value']);
	update_post_meta($order->get_id(), 'custom_field_141', $fields[141]['value']);
	update_post_meta($order->get_id(), 'custom_field_97', $fields[97]['value']);
	update_post_meta($order->get_id(), 'custom_field_63', $fields[63]['value']);
	update_post_meta($order->get_id(), 'custom_field_75', $fields[75]['value']);
	update_post_meta($order->get_id(), 'custom_field_76', $fields[76]['value']);
	update_post_meta($order->get_id(), 'custom_field_99', $fields[99]['value']);
	update_post_meta($order->get_id(), 'custom_field_119', $fields[119]['value']);
	update_post_meta($order->get_id(), 'custom_field_40', $fields[40]['value']);
	update_post_meta($order->get_id(), 'custom_field_59', $fields[59]['address1']);
	update_post_meta($order->get_id(), 'custom_field_59_address2', $fields[59]['address2']);
	update_post_meta($order->get_id(), 'custom_field_59_city', $fields[59]['city']);
	update_post_meta($order->get_id(), 'custom_field_59_state', $fields[59]['state']);
	update_post_meta($order->get_id(), 'custom_field_59_postal', $fields[59]['postal']);
	update_post_meta($order->get_id(), 'custom_field_59_country', $fields[59]['country']);
	update_post_meta($order->get_id(), 'custom_field_44', $fields[44]['value']);
	update_post_meta($order->get_id(), 'custom_field_133', $fields[133]['value']);
	update_post_meta($order->get_id(), 'custom_field_60', $fields[60]['value']);
	update_post_meta($order->get_id(), 'custom_field_61', $fields[61]['value']);
	update_post_meta($order->get_id(), 'custom_field_62', $fields[62]['address1']);
	update_post_meta($order->get_id(), 'custom_field_62_address2', $fields[62]['address2']);
	update_post_meta($order->get_id(), 'custom_field_62_city', $fields[62]['city']);
	update_post_meta($order->get_id(), 'custom_field_62_state', $fields[62]['state']);
	update_post_meta($order->get_id(), 'custom_field_62_postal', $fields[62]['postal']);
	update_post_meta($order->get_id(), 'custom_field_62_country', $fields[62]['country']);
	update_post_meta($order->get_id(), 'custom_field_111', $fields[111]['value']);
	update_post_meta($order->get_id(), 'custom_field_134', $fields[134]['value']);
	update_post_meta($order->get_id(), 'custom_field_65', $fields[65]['value']);
	update_post_meta($order->get_id(), 'custom_field_66', $fields[66]['value']);
	update_post_meta($order->get_id(), 'custom_field_67', $fields[67]['address1']);
	update_post_meta($order->get_id(), 'custom_field_67_address2', $fields[67]['address2']);
	update_post_meta($order->get_id(), 'custom_field_67_city', $fields[67]['city']);
	update_post_meta($order->get_id(), 'custom_field_67_state', $fields[67]['state']);
	update_post_meta($order->get_id(), 'custom_field_67_postal', $fields[67]['postal']);
	update_post_meta($order->get_id(), 'custom_field_67_country', $fields[67]['country']);
	update_post_meta($order->get_id(), 'custom_field_113', $fields[113]['value']);
	update_post_meta($order->get_id(), 'custom_field_135', $fields[135]['value']);
	update_post_meta($order->get_id(), 'custom_field_46', $fields[46]['value']);
	update_post_meta($order->get_id(), 'custom_field_29', $fields[29]['value']);
	update_post_meta($order->get_id(), 'custom_field_89', $fields[89]['value']);
	update_post_meta($order->get_id(), 'custom_field_98', $fields[98]['value']);
	update_post_meta($order->get_id(), 'custom_field_70', $fields[70]['value']);
	update_post_meta($order->get_id(), 'custom_field_138', $fields[138]['value']);
	update_post_meta($order->get_id(), 'custom_field_123', $fields[123]['value']);
	update_post_meta($order->get_id(), 'custom_field_146', $custom_count);
	update_post_meta($order->get_id(), 'custom_field_150', $fields[150]['value']);
	update_post_meta($order->get_id(), 'custom_field_154', $fields[154]['value']);
	update_post_meta($order->get_id(), 'custom_field_155', $fields[155]['value']);
	update_post_meta($order->get_id(), 'custom_field_15', $fields[15]['value']);
	update_post_meta($order->get_id(), 'custom_field_153', $fields[153]['value']);

	if($form_data['id'] == 5000){
		$order->set_status('wc-auftrag');
	}
	if($form_data['id'] == 5653){
		$order->set_status('wc-uf-auftrag');
	}
	if($form_data['id'] == 6107){
		$order->set_status('wc-hf-auftrag');
	}
	
    $order->calculate_totals();
    $order->save();
}


