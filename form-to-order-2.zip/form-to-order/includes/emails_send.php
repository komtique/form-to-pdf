<?php
function replace_dynamic_placeholders($body, $order) {
    $order_id = $order->get_id(); // Get order ID
    
    preg_match_all('/{field_id="(\d+)"}/', $body, $matches);

    foreach ($matches[1] as $field_id) {
        $field_value = get_post_meta($order_id, 'custom_field_' . $field_id, true);
        $body = str_replace('{field_id="' . $field_id . '"}', $field_value, $body);
    }
    
    return $body;
}

add_action('woocommerce_order_status_changed', 'send_custom_order_emails', 10, 4);
function send_custom_order_emails($order_id, $old_status, $new_status, $order) {
    $client_email = $order->get_billing_email();

    $additional_emails = [];
    foreach (['custom_field_111', 'custom_field_113', 'custom_field_44'] as $field) {
        $email = get_post_meta($order->get_id(), $field, true);
        if (!empty($email)) {
            $additional_emails[] = $email;
        }
    }
	
    switch ($new_status) {
        case 'auftrag':
		case 'uf-auftrag':
		case 'ut-auftrag':
		case 'hf-auftrag':
		case 'ht-auftrag':
			generate_confirmation_for_order($order->get_id());
			generate_authorisation_for_order($order->get_id());
            send_email_with_attachments($client_email, $new_status, $order);
            send_email_to_additional($additional_emails, $new_status, $order);
            break;

        case 'forderantrag':
		case 'uf-forderantrag':
		case 'ut-forderantrag':
		case 'hf-forderantrag':
		case 'ht-forderantrag':
            send_email_to_client($client_email, $new_status, $order);
            send_email_to_additional($additional_emails, $new_status, $order);
            if (get_option('enable_follow_up_email')) {
                wp_schedule_event(time() + WEEK_IN_SECONDS, 'send_follow_up_email', [$order_id]);
            }
            break;

        case 'erhalten':
		case 'uf-erhalten':
		case 'ut-erhalten':
		case 'hf-erhalten':
		case 'ht-erhalten':
			$invoice_pdf = get_post_meta($order->get_id(), '_invoice_pdf', true);
			if (!$invoice_pdf) {
			$invoice_pdf_url = generate_invoice_for_order($order->get_id());
			}
            send_email_with_attachments($client_email, $new_status, $order);
			
            send_email_to_additional($additional_emails, $new_status, $order);
            break;

        case 'ausgefuhrt':
		case 'uf-ausgefuhrt':
		case 'ut-ausgefuhrt':
		case 'hf-ausgefuhrt':
		case 'ht-ausgefuhrt':
			send_email_to_client($client_email, $new_status, $order);
            // Schedule bi-weekly reminders
            wp_schedule_event(time() + (WEEK_IN_SECONDS*2), 'send_biweekly_reminder_email', [$order_id]);
            break;

        case 'vollstandig':
		case 'uf-vollstandig':
		case 'ut-vollstandig':
		case 'hf-vollstandig':
		case 'ht-vollstandig':
            send_email_to_client($client_email, $new_status, $order);
            send_email_to_additional($additional_emails, $new_status, $order);
            break;

        case 'bei-bafa':
		case 'uf-bei-bafa':
		case 'ut-bei-bafa':
		case 'hf-bei-bafa':
		case 'ht-bei-bafa':
            send_email_to_client($client_email, $new_status, $order);
            break;

        case 'abgeschlossen':
		case 'uf-abgeschlossen':
		case 'ut-abgeschlossen':
		case 'hf-abgeschlossen':
		case 'ht-abgeschlossen':
            send_email_with_attachment($client_email, $new_status, $order);
			wp_schedule_single_event(time() + (WEEK_IN_SECONDS*4), 'send_follow_up_email_remind', [$order_id]);
            break;
    }
}


function send_email_to_client($client_email, $status, $order) {	
	$headers = "Content-Type: text/html\r\n";
	if (strpos($status, 'hf-') !== false) {
		$headers .= 'From: '.get_option("email_smtp_name_hbi-f").' <'.get_option("email_smtp_hbi-f").'>' . "\r\n"; 
	} elseif (strpos($status, 'ht-') !== false) {
		$headers .= 'From: '.get_option("email_smtp_name_hbi-t").' <'.get_option("email_smtp_hbi-t").'>' . "\r\n"; 
	} elseif (strpos($status, 'uf-') !== false) {
		$headers .= 'From: '.get_option("email_smtp_name_uni-f").' <'.get_option("email_smtp_uni-f").'>' . "\r\n"; 
	} elseif (strpos($status, 'ut-') !== false) {
		$headers .= 'From: '.get_option("email_smtp_name_uni-t").' <'.get_option("email_smtp_uni-t").'>' . "\r\n"; 
	} else {
		$headers .= 'From: '.get_option("email_smtp_name_fh").' <'.get_option("email_smtp_fh").'>' . "\r\n"; 
	}
	
	$subject = replace_dynamic_placeholders(get_option("email_subject_$status"), $order);
    $body = get_option("email_body_client_$status");
    $body = replace_dynamic_placeholders($body, $order);
	$body = wpautop($body);
	if (!empty($subject)){
		wp_mail( $client_email, $subject, $body, $headers );
	}
}

function send_email_to_additional($additional_emails, $status, $order) {
	$subject = replace_dynamic_placeholders(get_option("email_subject_additional_$status"), $order);
    $body = get_option("email_body_recipient_$status");
    $body = replace_dynamic_placeholders($body, $order);
	$body = wpautop($body);
	$headers = "Content-Type: text/html\r\n";
	if (strpos($status, 'hf-') !== false) {
		$headers .= 'From: '.get_option("email_smtp_name_hbi-f").' <'.get_option("email_smtp_hbi-f").'>' . "\r\n"; 
	} elseif (strpos($status, 'ht-') !== false) {
		$headers .= 'From: '.get_option("email_smtp_name_hbi-t").' <'.get_option("email_smtp_hbi-t").'>' . "\r\n"; 
	} elseif (strpos($status, 'uf-') !== false) {
		$headers .= 'From: '.get_option("email_smtp_name_uni-f").' <'.get_option("email_smtp_uni-f").'>' . "\r\n"; 
	} elseif (strpos($status, 'ut-') !== false) {
		$headers .= 'From: '.get_option("email_smtp_name_uni-t").' <'.get_option("email_smtp_uni-t").'>' . "\r\n"; 
	} else {
		$headers .= 'From: '.get_option("email_smtp_name_fh").' <'.get_option("email_smtp_fh").'>' . "\r\n"; 
	}
    foreach ($additional_emails as $email) {
		if (!empty($subject)){
			wp_mail( $email, $subject, $body, $headers );
		}
    }
}

function send_email_with_attachments($client_email, $status, $order) {
	$subject = replace_dynamic_placeholders(get_option("email_subject_$status"), $order);
    $body = get_option("email_body_client_$status");
    $body = replace_dynamic_placeholders($body, $order);

    $attachments = [];
	$upload_dir = wp_upload_dir();
	if (($status=='auftrag')||($status=='hf-auftrag')||($status=='ht-auftrag')||($status=='uf-auftrag')||($status=='ut-auftrag')){
		$zuwendungsbescheid_pdf = get_post_meta($order->get_id(), '_confirmation_pdf', true);
//		$invoice_pdf = get_post_meta($order->get_id(), '_authorisation_pdf', true);

		if ($zuwendungsbescheid_pdf) {
			$attachments[] = str_replace($upload_dir['baseurl'], $upload_dir['basedir'], $zuwendungsbescheid_pdf);
		}
//		if ($invoice_pdf) {
//			$attachments[] = str_replace($upload_dir['baseurl'], $upload_dir['basedir'], $invoice_pdf);
//		}
	} else {
		$zuwendungsbescheid_pdf = get_post_meta($order->get_id(), '_zuwendungsbescheid_pdf', true);
		$invoice_pdf = get_post_meta($order->get_id(), '_invoice_pdf', true);

		if ($zuwendungsbescheid_pdf) {
			$attachments[] = str_replace($upload_dir['baseurl'], $upload_dir['basedir'], $zuwendungsbescheid_pdf);
		}
		if ($invoice_pdf) {
			$attachments[] = str_replace($upload_dir['baseurl'], $upload_dir['basedir'], $invoice_pdf);
		}
	}
	$body = wpautop($body);
	$headers = "Content-Type: text/html\r\n";
	if (strpos($status, 'hf-') !== false) {
		$headers .= 'From: '.get_option("email_smtp_name_hbi-f").' <'.get_option("email_smtp_hbi-f").'>' . "\r\n"; 
	} elseif (strpos($status, 'ht-') !== false) {
		$headers .= 'From: '.get_option("email_smtp_name_hbi-t").' <'.get_option("email_smtp_hbi-t").'>' . "\r\n"; 
	} elseif (strpos($status, 'uf-') !== false) {
		$headers .= 'From: '.get_option("email_smtp_name_uni-f").' <'.get_option("email_smtp_uni-f").'>' . "\r\n"; 
	} elseif (strpos($status, 'ut-') !== false) {
		$headers .= 'From: '.get_option("email_smtp_name_uni-t").' <'.get_option("email_smtp_uni-t").'>' . "\r\n"; 
	} else {
		$headers .= 'From: '.get_option("email_smtp_name_fh").' <'.get_option("email_smtp_fh").'>' . "\r\n"; 
	}
	if (!empty($subject)){
		wp_mail( $client_email, $subject, $body, $headers, $attachments );
	}
}


function send_email_with_attachment($client_email, $status, $order) {
	$subject = replace_dynamic_placeholders(get_option("email_subject_$status"), $order);
    $body = get_option("email_body_client_$status");
    $body = replace_dynamic_placeholders($body, $order);
	$upload_dir = wp_upload_dir();
    $attachments = [];
	$festsetzungsbescheid_pdf = get_post_meta($order->get_id(), '_festsetzungsbescheid_pdf', true);

	if ($festsetzungsbescheid_pdf) {
		$attachments[] = str_replace($upload_dir['baseurl'], $upload_dir['basedir'], $festsetzungsbescheid_pdf);
	}
	$body = wpautop($body);
	$headers = "Content-Type: text/html\r\n";
	if (strpos($status, 'hf-') !== false) {
		$headers .= 'From: '.get_option("email_smtp_name_hbi-f").' <'.get_option("email_smtp_hbi-f").'>' . "\r\n"; 
	} elseif (strpos($status, 'ht-') !== false) {
		$headers .= 'From: '.get_option("email_smtp_name_hbi-t").' <'.get_option("email_smtp_hbi-t").'>' . "\r\n"; 
	} elseif (strpos($status, 'uf-') !== false) {
		$headers .= 'From: '.get_option("email_smtp_name_uni-f").' <'.get_option("email_smtp_uni-f").'>' . "\r\n"; 
	} elseif (strpos($status, 'ut-') !== false) {
		$headers .= 'From: '.get_option("email_smtp_name_uni-t").' <'.get_option("email_smtp_uni-t").'>' . "\r\n"; 
	} else {
		$headers .= 'From: '.get_option("email_smtp_name_fh").' <'.get_option("email_smtp_fh").'>' . "\r\n"; 
	}
	
	if (!empty($subject)){
		wp_mail( $client_email, $subject, $body, $headers, $attachments );
	}
}

function send_email_to_additional_with_attachments($additional_emails, $status, $order) {
	$subject = replace_dynamic_placeholders(get_option("email_subject_additional_$status"), $order);
    $body = get_option("email_body_recipient_$status");
    $body = replace_dynamic_placeholders($body, $order);
	$upload_dir = wp_upload_dir();
    $attachments = [];
	$zuwendungsbescheid_pdf = get_post_meta($order->get_id(), '_zuwendungsbescheid_pdf', true);
	$invoice_pdf = get_post_meta($order->get_id(), '_invoice_pdf', true);
	
	if ($zuwendungsbescheid_pdf) {
		$attachments[] = str_replace($upload_dir['baseurl'], $upload_dir['basedir'], $zuwendungsbescheid_pdf);
	}
	if ($invoice_pdf) {
		$attachments[] = str_replace($upload_dir['baseurl'], $upload_dir['basedir'], $invoice_pdf);
	}
	$body = wpautop($body);
	foreach ($additional_emails as $email) {
		$headers = "Content-Type: text/html\r\n";
		if (strpos($status, 'hf-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_hbi-f").' <'.get_option("email_smtp_hbi-f").'>' . "\r\n"; 
		} elseif (strpos($status, 'ht-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_hbi-t").' <'.get_option("email_smtp_hbi-t").'>' . "\r\n"; 
		} elseif (strpos($status, 'uf-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_uni-f").' <'.get_option("email_smtp_uni-f").'>' . "\r\n"; 
		} elseif (strpos($status, 'ut-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_uni-t").' <'.get_option("email_smtp_uni-t").'>' . "\r\n"; 
		} else {
			$headers .= 'From: '.get_option("email_smtp_name_fh").' <'.get_option("email_smtp_fh").'>' . "\r\n"; 
		}

		if (!empty($subject)){
			wp_mail( $email, $subject, $body, $headers, $attachments );
		}
    }
}

function send_email_to_additional_attachment($additional_emails, $status, $order) {
	$subject = replace_dynamic_placeholders(get_option("email_subject_additional_$status"), $order);
    $body = get_option("email_body_recipient_$status");
    $body = replace_dynamic_placeholders($body, $order);
	$upload_dir = wp_upload_dir();
    $attachments = [];
	$festsetzungsbescheid_pdf = get_post_meta($order->get_id(), '_festsetzungsbescheid_pdf', true);

	if ($festsetzungsbescheid_pdf) {
		$attachments[] = str_replace($upload_dir['baseurl'], $upload_dir['basedir'], $festsetzungsbescheid_pdf);
	}
	$body = wpautop($body);
	foreach ($additional_emails as $email) {
		$headers = "Content-Type: text/html\r\n";
		if (strpos($status, 'hf-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_hbi-f").' <'.get_option("email_smtp_hbi-f").'>' . "\r\n"; 
		} elseif (strpos($status, 'ht-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_hbi-t").' <'.get_option("email_smtp_hbi-t").'>' . "\r\n"; 
		} elseif (strpos($status, 'uf-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_uni-f").' <'.get_option("email_smtp_uni-f").'>' . "\r\n"; 
		} elseif (strpos($status, 'ut-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_uni-t").' <'.get_option("email_smtp_uni-t").'>' . "\r\n"; 
		} else {
			$headers .= 'From: '.get_option("email_smtp_name_fh").' <'.get_option("email_smtp_fh").'>' . "\r\n"; 
		}
		if (!empty($subject)){
			wp_mail( $email, $subject, $body, $headers, $attachments );
		}
    }
}


add_action('send_follow_up_email_remind', 'follow_up_email_remind_function', 10, 1);
function follow_up_email_remind_function($order_id) {
    $order = wc_get_order($order_id);
	if ($order->get_status()=='abgeschlossen'){
		$client_email = $order->get_billing_email();
		$subject = replace_dynamic_placeholders(get_option("email_subject_abgeschlossen_remind"), $order);
		$body = get_option("email_body_client_abgeschlossen_remind");
		$body = replace_dynamic_placeholders($body, $order);
		$headers = "Content-Type: text/html\r\n";
		if (strpos($status, 'hf-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_hbi-f").' <'.get_option("email_smtp_hbi-f").'>' . "\r\n"; 
		} elseif (strpos($status, 'ht-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_hbi-t").' <'.get_option("email_smtp_hbi-t").'>' . "\r\n"; 
		} elseif (strpos($status, 'uf-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_uni-f").' <'.get_option("email_smtp_uni-f").'>' . "\r\n"; 
		} elseif (strpos($status, 'ut-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_uni-t").' <'.get_option("email_smtp_uni-t").'>' . "\r\n"; 
		} else {
			$headers .= 'From: '.get_option("email_smtp_name_fh").' <'.get_option("email_smtp_fh").'>' . "\r\n"; 
		}
		$additional_emails = [];
		$subjectnew = replace_dynamic_placeholders(get_option("email_subject_additional_abgeschlossen_remind"), $order);
		$bodynew = get_option("email_body_client_additional_abgeschlossen_remind");
		$bodynew = wpautop($bodynew);
		$bodynew = replace_dynamic_placeholders($bodynew, $order);
		$body = wpautop($body);
		foreach (['custom_field_111', 'custom_field_113', 'custom_field_44'] as $field) {
			$email = get_post_meta($order_id, $field, true);
			if (!empty($email)) {
				if (!empty($subjectnew)){
					wp_mail( $email, $subjectnew, $bodynew, $headers );
				}
			}
		}
		
		if (!empty($subject)){
			wp_mail( $client_email, $subject, $body, $headers );
		}
	} elseif ($order->get_status()=='hf-abgeschlossen'){
		$client_email = $order->get_billing_email();
		$subject = replace_dynamic_placeholders(get_option("email_subject_hf-abgeschlossen_remind"), $order);
		$body = get_option("email_body_client_hf-abgeschlossen_remind");
		$body = replace_dynamic_placeholders($body, $order);
		$headers = "Content-Type: text/html\r\n";
		if (strpos($status, 'hf-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_hbi-f").' <'.get_option("email_smtp_hbi-f").'>' . "\r\n"; 
		} elseif (strpos($status, 'ht-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_hbi-t").' <'.get_option("email_smtp_hbi-t").'>' . "\r\n"; 
		} elseif (strpos($status, 'uf-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_uni-f").' <'.get_option("email_smtp_uni-f").'>' . "\r\n"; 
		} elseif (strpos($status, 'ut-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_uni-t").' <'.get_option("email_smtp_uni-t").'>' . "\r\n"; 
		} else {
			$headers .= 'From: '.get_option("email_smtp_name_fh").' <'.get_option("email_smtp_fh").'>' . "\r\n"; 
		}
		$additional_emails = [];
		$subjectnew = replace_dynamic_placeholders(get_option("email_subject_additional_hf-abgeschlossen_remind"), $order);
		$bodynew = get_option("email_body_client_additional_hf-abgeschlossen_remind");
		$bodynew = wpautop($bodynew);
		$bodynew = replace_dynamic_placeholders($bodynew, $order);
		$body = wpautop($body);
		foreach (['custom_field_111', 'custom_field_113', 'custom_field_44'] as $field) {
			$email = get_post_meta($order_id, $field, true);
			if (!empty($subjectnew)) {
				wp_mail( $email, $subjectnew, $bodynew, $headers );
			}
		}
		if (!empty($subject)){
			wp_mail( $client_email, $subject, $body, $headers );
		}
	} elseif ($order->get_status()=='ht-abgeschlossen'){
		$client_email = $order->get_billing_email();
		$subject = replace_dynamic_placeholders(get_option("email_subject_ht-abgeschlossen_remind"), $order);
		$body = get_option("email_body_client_ht-abgeschlossen_remind");
		$body = replace_dynamic_placeholders($body, $order);
		$headers = "Content-Type: text/html\r\n";
		if (strpos($status, 'hf-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_hbi-f").' <'.get_option("email_smtp_hbi-f").'>' . "\r\n"; 
		} elseif (strpos($status, 'ht-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_hbi-t").' <'.get_option("email_smtp_hbi-t").'>' . "\r\n"; 
		} elseif (strpos($status, 'uf-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_uni-f").' <'.get_option("email_smtp_uni-f").'>' . "\r\n"; 
		} elseif (strpos($status, 'ut-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_uni-t").' <'.get_option("email_smtp_uni-t").'>' . "\r\n"; 
		} else {
			$headers .= 'From: '.get_option("email_smtp_name_fh").' <'.get_option("email_smtp_fh").'>' . "\r\n"; 
		}
		$additional_emails = [];
		$subjectnew = replace_dynamic_placeholders(get_option("email_subject_additional_ht-abgeschlossen_remind"), $order);
		$bodynew = get_option("email_body_client_additional_ht-abgeschlossen_remind");
		$bodynew = wpautop($bodynew);
		$bodynew = replace_dynamic_placeholders($bodynew, $order);
		$body = wpautop($body);
		foreach (['custom_field_111', 'custom_field_113', 'custom_field_44'] as $field) {
			$email = get_post_meta($order_id, $field, true);
			if (!empty($subjectnew)) {
				wp_mail( $email, $subjectnew, $bodynew, $headers );
			}
		}
		if (!empty($subject)){
			wp_mail( $client_email, $subject, $body, $headers );
		}
	} elseif ($order->get_status()=='uf-abgeschlossen'){
		$client_email = $order->get_billing_email();
		$subject = replace_dynamic_placeholders(get_option("email_subject_uf-abgeschlossen_remind"), $order);
		$body = get_option("email_body_client_uf-abgeschlossen_remind");
		$body = replace_dynamic_placeholders($body, $order);
		$headers = "Content-Type: text/html\r\n";
		if (strpos($status, 'hf-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_hbi-f").' <'.get_option("email_smtp_hbi-f").'>' . "\r\n"; 
		} elseif (strpos($status, 'ht-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_hbi-t").' <'.get_option("email_smtp_hbi-t").'>' . "\r\n"; 
		} elseif (strpos($status, 'uf-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_uni-f").' <'.get_option("email_smtp_uni-f").'>' . "\r\n"; 
		} elseif (strpos($status, 'ut-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_uni-t").' <'.get_option("email_smtp_uni-t").'>' . "\r\n"; 
		} else {
			$headers .= 'From: '.get_option("email_smtp_name_fh").' <'.get_option("email_smtp_fh").'>' . "\r\n"; 
		}
		$additional_emails = [];
		$subjectnew = replace_dynamic_placeholders(get_option("email_subject_additional_uf-abgeschlossen_remind"), $order);
		$bodynew = get_option("email_body_client_additional_uf-abgeschlossen_remind");
		$bodynew = wpautop($bodynew);
		$bodynew = replace_dynamic_placeholders($bodynew, $order);
		$body = wpautop($body);
		foreach (['custom_field_111', 'custom_field_113', 'custom_field_44'] as $field) {
			$email = get_post_meta($order_id, $field, true);
			if (!empty($subjectnew)) {
				wp_mail( $email, $subjectnew, $bodynew, $headers );
			}
		}
		if (!empty($subject)){
			wp_mail( $client_email, $subject, $body, $headers );
		}
	} elseif ($order->get_status()=='ut-abgeschlossen'){
		$client_email = $order->get_billing_email();
		$subject = replace_dynamic_placeholders(get_option("email_subject_ut-abgeschlossen_remind"), $order);
		$body = get_option("email_body_client_ut-abgeschlossen_remind");
		$body = replace_dynamic_placeholders($body, $order);
		$headers = "Content-Type: text/html\r\n";
		if (strpos($status, 'hf-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_hbi-f").' <'.get_option("email_smtp_hbi-f").'>' . "\r\n"; 
		} elseif (strpos($status, 'ht-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_hbi-t").' <'.get_option("email_smtp_hbi-t").'>' . "\r\n"; 
		} elseif (strpos($status, 'uf-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_uni-f").' <'.get_option("email_smtp_uni-f").'>' . "\r\n"; 
		} elseif (strpos($status, 'ut-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_uni-t").' <'.get_option("email_smtp_uni-t").'>' . "\r\n"; 
		} else {
			$headers .= 'From: '.get_option("email_smtp_name_fh").' <'.get_option("email_smtp_fh").'>' . "\r\n"; 
		}
		$additional_emails = [];
		$subjectnew = replace_dynamic_placeholders(get_option("email_subject_additional_ut-abgeschlossen_remind"), $order);
		$bodynew = get_option("email_body_client_additional_ut-abgeschlossen_remind");
		$bodynew = wpautop($bodynew);
		$bodynew = replace_dynamic_placeholders($bodynew, $order);
		$body = wpautop($body);
		foreach (['custom_field_111', 'custom_field_113', 'custom_field_44'] as $field) {
			$email = get_post_meta($order_id, $field, true);
			if (!empty($subjectnew)) {
				wp_mail( $email, $subjectnew, $bodynew, $headers );
			}
		}
		if (!empty($subject)){
			wp_mail( $client_email, $subject, $body, $headers );
		}
	}
}


add_action('send_follow_up_email', 'follow_up_email_function', 10, 1);
function follow_up_email_function($order_id) {
    $order = wc_get_order($order_id);
	
	if ($order->get_status()=='forderantrag'){
		$client_email = $order->get_billing_email();
		$subject = replace_dynamic_placeholders(get_option("email_subject_forderantrag_new"), $order);
		$body = get_option("email_body_client_forderantrag_new");
		$body = replace_dynamic_placeholders($body, $order);
		$body = wpautop($body);
		$headers = "Content-Type: text/html\r\n";
		if (strpos($status, 'hf-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_hbi-f").' <'.get_option("email_smtp_hbi-f").'>' . "\r\n"; 
		} elseif (strpos($status, 'ht-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_hbi-t").' <'.get_option("email_smtp_hbi-t").'>' . "\r\n"; 
		} elseif (strpos($status, 'uf-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_uni-f").' <'.get_option("email_smtp_uni-f").'>' . "\r\n"; 
		} elseif (strpos($status, 'ut-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_uni-t").' <'.get_option("email_smtp_uni-t").'>' . "\r\n"; 
		} else {
			$headers .= 'From: '.get_option("email_smtp_name_fh").' <'.get_option("email_smtp_fh").'>' . "\r\n"; 
		}
		if (!empty($subject)){
			wp_mail( $client_email, $subject, $body, $headers );
		}
		
		$subjectnew = replace_dynamic_placeholders(get_option("email_subject_additional_forderantrag_new"), $order);
		$bodynew = get_option("email_body_client_additional_forderantrag_new");
		$bodynew = replace_dynamic_placeholders($body, $order);
		$bodynew = wpautop($body);
		foreach (['custom_field_111', 'custom_field_113', 'custom_field_44'] as $field) {
			$email = get_post_meta($order_id, $field, true);
			if (!empty($subjectnew)) {
				wp_mail( $email, $subjectnew, $bodynew, $headers );
			}
		}
	} elseif ($order->get_status()=='ht-forderantrag'){
		$client_email = $order->get_billing_email();
		$subject = replace_dynamic_placeholders(get_option("email_subject_ht-forderantrag_new"), $order);
		$body = get_option("email_body_client_ht-forderantrag_new");
		$body = replace_dynamic_placeholders($body, $order);
		$body = wpautop($body);
		$headers = "Content-Type: text/html\r\n";
		if (strpos($status, 'hf-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_hbi-f").' <'.get_option("email_smtp_hbi-f").'>' . "\r\n"; 
		} elseif (strpos($status, 'ht-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_hbi-t").' <'.get_option("email_smtp_hbi-t").'>' . "\r\n"; 
		} elseif (strpos($status, 'uf-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_uni-f").' <'.get_option("email_smtp_uni-f").'>' . "\r\n"; 
		} elseif (strpos($status, 'ut-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_uni-t").' <'.get_option("email_smtp_uni-t").'>' . "\r\n"; 
		} else {
			$headers .= 'From: '.get_option("email_smtp_name_fh").' <'.get_option("email_smtp_fh").'>' . "\r\n"; 
		}
		if (!empty($subject)){
			wp_mail( $client_email, $subject, $body, $headers );
		}
		
		$subjectnew = replace_dynamic_placeholders(get_option("email_subject_additional_ht-forderantrag_new"), $order);
		$bodynew = get_option("email_body_client_additional_ht-forderantrag_new");
		$bodynew = replace_dynamic_placeholders($body, $order);
		$bodynew = wpautop($body);
		foreach (['custom_field_111', 'custom_field_113', 'custom_field_44'] as $field) {
			$email = get_post_meta($order_id, $field, true);
			if (!empty($subjectnew)) {
				wp_mail( $email, $subjectnew, $bodynew, $headers );
			}
		}
	} elseif ($order->get_status()=='hf-forderantrag'){
		$client_email = $order->get_billing_email();
		$subject = replace_dynamic_placeholders(get_option("email_subject_hf-forderantrag_new"), $order);
		$body = get_option("email_body_client_hf-forderantrag_new");
		$body = replace_dynamic_placeholders($body, $order);
		$body = wpautop($body);
		$headers = "Content-Type: text/html\r\n";
		if (strpos($status, 'hf-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_hbi-f").' <'.get_option("email_smtp_hbi-f").'>' . "\r\n"; 
		} elseif (strpos($status, 'ht-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_hbi-t").' <'.get_option("email_smtp_hbi-t").'>' . "\r\n"; 
		} elseif (strpos($status, 'uf-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_uni-f").' <'.get_option("email_smtp_uni-f").'>' . "\r\n"; 
		} elseif (strpos($status, 'ut-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_uni-t").' <'.get_option("email_smtp_uni-t").'>' . "\r\n"; 
		} else {
			$headers .= 'From: '.get_option("email_smtp_name_fh").' <'.get_option("email_smtp_fh").'>' . "\r\n"; 
		}
		if (!empty($subject)){
			wp_mail( $client_email, $subject, $body, $headers );
		}
		
		$subjectnew = replace_dynamic_placeholders(get_option("email_subject_additional_hf-forderantrag_new"), $order);
		$bodynew = get_option("email_body_client_additional_hf-forderantrag_new");
		$bodynew = replace_dynamic_placeholders($body, $order);
		$bodynew = wpautop($body);
		foreach (['custom_field_111', 'custom_field_113', 'custom_field_44'] as $field) {
			$email = get_post_meta($order_id, $field, true);
			if (!empty($subjectnew)) {
				wp_mail( $email, $subjectnew, $bodynew, $headers );
			}
		}
	} elseif ($order->get_status()=='ut-forderantrag'){
		$client_email = $order->get_billing_email();
		$subject = replace_dynamic_placeholders(get_option("email_subject_ut-forderantrag_new"), $order);
		$body = get_option("email_body_client_ut-forderantrag_new");
		$body = replace_dynamic_placeholders($body, $order);
		$body = wpautop($body);
		$headers = "Content-Type: text/html\r\n";
		if (strpos($status, 'hf-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_hbi-f").' <'.get_option("email_smtp_hbi-f").'>' . "\r\n"; 
		} elseif (strpos($status, 'ht-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_hbi-t").' <'.get_option("email_smtp_hbi-t").'>' . "\r\n"; 
		} elseif (strpos($status, 'uf-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_uni-f").' <'.get_option("email_smtp_uni-f").'>' . "\r\n"; 
		} elseif (strpos($status, 'ut-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_uni-t").' <'.get_option("email_smtp_uni-t").'>' . "\r\n"; 
		} else {
			$headers .= 'From: '.get_option("email_smtp_name_fh").' <'.get_option("email_smtp_fh").'>' . "\r\n"; 
		}
		if (!empty($subject)){
			wp_mail( $client_email, $subject, $body, $headers );
		}
		
		$subjectnew = replace_dynamic_placeholders(get_option("email_subject_additional_ut-forderantrag_new"), $order);
		$bodynew = get_option("email_body_client_additional_ut-forderantrag_new");
		$bodynew = replace_dynamic_placeholders($body, $order);
		$bodynew = wpautop($body);
		foreach (['custom_field_111', 'custom_field_113', 'custom_field_44'] as $field) {
			$email = get_post_meta($order_id, $field, true);
			if (!empty($subjectnew)) {
				wp_mail( $email, $subjectnew, $bodynew, $headers );
			}
		}
	} elseif ($order->get_status()=='uf-forderantrag'){
		$client_email = $order->get_billing_email();
		$subject = replace_dynamic_placeholders(get_option("email_subject_uf-forderantrag_new"), $order);
		$body = get_option("email_body_client_uf-forderantrag_new");
		$body = replace_dynamic_placeholders($body, $order);
		$body = wpautop($body);
		$headers = "Content-Type: text/html\r\n";
		if (strpos($status, 'hf-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_hbi-f").' <'.get_option("email_smtp_hbi-f").'>' . "\r\n"; 
		} elseif (strpos($status, 'ht-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_hbi-t").' <'.get_option("email_smtp_hbi-t").'>' . "\r\n"; 
		} elseif (strpos($status, 'uf-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_uni-f").' <'.get_option("email_smtp_uni-f").'>' . "\r\n"; 
		} elseif (strpos($status, 'ut-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_uni-t").' <'.get_option("email_smtp_uni-t").'>' . "\r\n"; 
		} else {
			$headers .= 'From: '.get_option("email_smtp_name_fh").' <'.get_option("email_smtp_fh").'>' . "\r\n"; 
		}
		if (!empty($subject)){
			wp_mail( $client_email, $subject, $body, $headers );
		}
		
		$subjectnew = replace_dynamic_placeholders(get_option("email_subject_additional_uf-forderantrag_new"), $order);
		$bodynew = get_option("email_body_client_additional_uf-forderantrag_new");
		$bodynew = replace_dynamic_placeholders($body, $order);
		$bodynew = wpautop($body);
		foreach (['custom_field_111', 'custom_field_113', 'custom_field_44'] as $field) {
			$email = get_post_meta($order_id, $field, true);
			if (!empty($subjectnew)) {
				wp_mail( $email, $subjectnew, $bodynew, $headers );
			}
		}
	}
}

add_action('send_biweekly_reminder_email', 'biweekly_reminder_email_function', 10, 1);
function biweekly_reminder_email_function($order_id) {
    $order = wc_get_order($order_id);
	if ($order->get_status()=='ausgefuhrt'){
		$client_email = $order->get_billing_email();
		$subject = replace_dynamic_placeholders(get_option("email_subject_ausgefuhrt"), $order);
		$body = get_option("email_body_client_ausgefuhrt");
		$body = replace_dynamic_placeholders($body, $order);
		$body = wpautop($body);
		$headers = "Content-Type: text/html\r\n";
		if (strpos($status, 'hf-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_hbi-f").' <'.get_option("email_smtp_hbi-f").'>' . "\r\n"; 
		} elseif (strpos($status, 'ht-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_hbi-t").' <'.get_option("email_smtp_hbi-t").'>' . "\r\n"; 
		} elseif (strpos($status, 'uf-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_uni-f").' <'.get_option("email_smtp_uni-f").'>' . "\r\n"; 
		} elseif (strpos($status, 'ut-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_uni-t").' <'.get_option("email_smtp_uni-t").'>' . "\r\n"; 
		} else {
			$headers .= 'From: '.get_option("email_smtp_name_fh").' <'.get_option("email_smtp_fh").'>' . "\r\n"; 
		}
		if (!empty($subject)){
			wp_mail( $client_email, $subject, $body, $headers );
		}
		
	} elseif ($order->get_status()=='hf-ausgefuhrt'){
		$client_email = $order->get_billing_email();
		$subject = replace_dynamic_placeholders(get_option("email_subject_hf-ausgefuhrt"), $order);
		$body = get_option("email_body_client_hf-ausgefuhrt");
		$body = replace_dynamic_placeholders($body, $order);
		$body = wpautop($body);
		$headers = "Content-Type: text/html\r\n";
		if (strpos($status, 'hf-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_hbi-f").' <'.get_option("email_smtp_hbi-f").'>' . "\r\n"; 
		} elseif (strpos($status, 'ht-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_hbi-t").' <'.get_option("email_smtp_hbi-t").'>' . "\r\n"; 
		} elseif (strpos($status, 'uf-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_uni-f").' <'.get_option("email_smtp_uni-f").'>' . "\r\n"; 
		} elseif (strpos($status, 'ut-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_uni-t").' <'.get_option("email_smtp_uni-t").'>' . "\r\n"; 
		} else {
			$headers .= 'From: '.get_option("email_smtp_name_fh").' <'.get_option("email_smtp_fh").'>' . "\r\n"; 
		}
		if (!empty($subject)){
			wp_mail( $client_email, $subject, $body, $headers );
		}
	} elseif ($order->get_status()=='ht-ausgefuhrt'){
		$client_email = $order->get_billing_email();
		$subject = replace_dynamic_placeholders(get_option("email_subject_ht-ausgefuhrt"), $order);
		$body = get_option("email_body_client_ht-ausgefuhrt");
		$body = replace_dynamic_placeholders($body, $order);
		$body = wpautop($body);
		$headers = "Content-Type: text/html\r\n";
		if (strpos($status, 'hf-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_hbi-f").' <'.get_option("email_smtp_hbi-f").'>' . "\r\n"; 
		} elseif (strpos($status, 'ht-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_hbi-t").' <'.get_option("email_smtp_hbi-t").'>' . "\r\n"; 
		} elseif (strpos($status, 'uf-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_uni-f").' <'.get_option("email_smtp_uni-f").'>' . "\r\n"; 
		} elseif (strpos($status, 'ut-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_uni-t").' <'.get_option("email_smtp_uni-t").'>' . "\r\n"; 
		} else {
			$headers .= 'From: '.get_option("email_smtp_name_fh").' <'.get_option("email_smtp_fh").'>' . "\r\n"; 
		}
		if (!empty($subject)){
			wp_mail( $client_email, $subject, $body, $headers );
		}
	} elseif ($order->get_status()=='ut-ausgefuhrt'){
		$client_email = $order->get_billing_email();
		$subject = replace_dynamic_placeholders(get_option("email_subject_ut-ausgefuhrt"), $order);
		$body = get_option("email_body_client_ut-ausgefuhrt");
		$body = replace_dynamic_placeholders($body, $order);
		$body = wpautop($body);
		$headers = "Content-Type: text/html\r\n";
		if (strpos($status, 'hf-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_hbi-f").' <'.get_option("email_smtp_hbi-f").'>' . "\r\n"; 
		} elseif (strpos($status, 'ht-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_hbi-t").' <'.get_option("email_smtp_hbi-t").'>' . "\r\n"; 
		} elseif (strpos($status, 'uf-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_uni-f").' <'.get_option("email_smtp_uni-f").'>' . "\r\n"; 
		} elseif (strpos($status, 'ut-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_uni-t").' <'.get_option("email_smtp_uni-t").'>' . "\r\n"; 
		} else {
			$headers .= 'From: '.get_option("email_smtp_name_fh").' <'.get_option("email_smtp_fh").'>' . "\r\n"; 
		}
		if (!empty($subject)){
			wp_mail( $client_email, $subject, $body, $headers );
		}
	} elseif ($order->get_status()=='uf-ausgefuhrt'){
		$client_email = $order->get_billing_email();
		$subject = replace_dynamic_placeholders(get_option("email_subject_uf-ausgefuhrt"), $order);
		$body = get_option("email_body_client_uf-ausgefuhrt");
		$body = replace_dynamic_placeholders($body, $order);
		$body = wpautop($body);
		$headers = "Content-Type: text/html\r\n";
		if (strpos($status, 'hf-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_hbi-f").' <'.get_option("email_smtp_hbi-f").'>' . "\r\n"; 
		} elseif (strpos($status, 'ht-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_hbi-t").' <'.get_option("email_smtp_hbi-t").'>' . "\r\n"; 
		} elseif (strpos($status, 'uf-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_uni-f").' <'.get_option("email_smtp_uni-f").'>' . "\r\n"; 
		} elseif (strpos($status, 'ut-') !== false) {
			$headers .= 'From: '.get_option("email_smtp_name_uni-t").' <'.get_option("email_smtp_uni-t").'>' . "\r\n"; 
		} else {
			$headers .= 'From: '.get_option("email_smtp_name_fh").' <'.get_option("email_smtp_fh").'>' . "\r\n"; 
		}
		if (!empty($subject)){
			wp_mail( $client_email, $subject, $body, $headers );
		}
	}
}